"use strict";
var Provision = (function () {
    function Provision(id, applicationName, systemName) {
        this.id = id;
        this.applicationName = applicationName;
        this.systemName = systemName;
    }
    return Provision;
}());
exports.Provision = Provision;
//# sourceMappingURL=Provision.js.map