export class SourceProduct {
   constructor(
    public source : string,
    public domain : string,
    public region : string,
    public frenquency : string,
   ){

   }
}
