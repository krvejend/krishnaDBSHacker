import { Component,OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'my-app',
  template: `<div>
           <p class="logo"> </p><h1 class="text-center text-aline" style="margin-bottom: 2%;">
  <label class="label label-danger"></label></h1></div>
  <div class="red-line" style="margin-top: 60px;"></div>
  <router-outlet></router-outlet>

  `,
})
export class AppComponent implements OnInit {
  constructor(
        private route: ActivatedRoute,
        private router: Router,
       ) { }

    ngOnInit(): void {
     this.router.navigate(['/login']);
    }

data= {};
formSubmit(){
console.log(this.data);
}
}
