"use strict";
var Availability = (function () {
    function Availability(id, applicationName, systemName) {
        this.id = id;
        this.applicationName = applicationName;
        this.systemName = systemName;
    }
    return Availability;
}());
exports.Availability = Availability;
//# sourceMappingURL=availability.js.map