import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import {TreeNode} from 'primeng/primeng';

@Component({
 templateUrl: './app/dataprovision/notify/notify.html'
})
export class NotifyComponent {

    projectid="10031";
    sourcename="ABONO A COMMERCIO ";
    dataasset="securities Lending Data Asset";
    showDialogProvision:boolean = false;
    onSubmit = function(){
      this.showDialogProvision = true;
    }
}
