"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var session_service_1 = require('../service/session.service');
var user_service_1 = require('../service/user.service');
var Product_1 = require('../Product');
var LoginComponent = (function () {
    function LoginComponent(router, userService, sessionService) {
        this.router = router;
        this.userService = userService;
        this.sessionService = sessionService;
        this.data = { username: '', password: '' };
        this.error = false;
    }
    LoginComponent.prototype.formSubmit = function () {
        var item = new Product_1.Product(10030, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "David A GRIMME", "Risk Profile Questionnaire", "Identify", "Customer Account", "Mexico");
        var item1 = new Product_1.Product(10031, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "David A GRIMME", "Securities Lending Admin MS", "Project", "Customer Account", "Mexico");
        var item2 = new Product_1.Product(10032, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "BCBS Global Risk Reporting", "Govern", "Customer Account", "Mexico");
        var item3 = new Product_1.Product(10033, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "David A GRIMME", "Premier Risk Profile", "Define", "Customer Account", "Mexico");
        var item4 = new Product_1.Product(10034, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "Catalyst", "Prepare", "Customer Account", "Mexico");
        var item5 = new Product_1.Product(10035, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "David A GRIMME", "CBT Risk Consolidation", "Enrich", "Customer Account", "Mexico");
        var item6 = new Product_1.Product(10036, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "CCIL Integrated Risk Info Sys", "Validate", "Customer Account", "Mexico");
        var item7 = new Product_1.Product(10037, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "David A GRIMME", "BCBS Global Risk Reporting", "Promote", "Customer Account", "Mexico");
        var item8 = new Product_1.Product(10038, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "BCBS Global Risk Reporting", "Define", "Customer Account", "Mexico");
        var item9 = new Product_1.Product(10039, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "BCBS Global Risk Reporting", "Identify", "Customer Account", "Mexico");
        var item10 = new Product_1.Product(10040, "ABONO A COMMERCIO", "RBWM", "ABONO A COMMERCIO", "Raul GOMEZ", "BCBS Global Risk Reporting", "Identify", "Customer Account", "Mexico");
        var productList = [];
        productList.push(item1);
        productList.push(item2);
        productList.push(item3);
        productList.push(item4);
        productList.push(item5);
        productList.push(item6);
        productList.push(item7);
        productList.push(item8);
        productList.push(item9);
        productList.push(item10);
        this.sessionService.setProductList(productList);
        this.router.navigate(['/landing']);
    };
    LoginComponent = __decorate([
        core_1.Component({
            templateUrl: './app/login/login.html',
            providers: [user_service_1.UserService],
        }), 
        __metadata('design:paramtypes', [router_1.Router, user_service_1.UserService, session_service_1.SessionService])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map