"use strict";
var Product = (function () {
    function Product(id, requestorname, lob, source, sourceowner, date, acqusitionstatus, ingestionstatus, propagationstatus) {
        this.id = id;
        this.requestorname = requestorname;
        this.lob = lob;
        this.source = source;
        this.sourceowner = sourceowner;
        this.date = date;
        this.acqusitionstatus = acqusitionstatus;
        this.ingestionstatus = ingestionstatus;
        this.propagationstatus = propagationstatus;
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=Product.js.map