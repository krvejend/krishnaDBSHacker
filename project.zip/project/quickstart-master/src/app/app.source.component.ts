import { Component, NgModule } from '@angular/core';
import {SourceProduct} from './sourceproduct';
import {sourceproductList} from './sourcedata';
@Component({
 selector: 'my-source',        
 template: `
   <div class="form-group">
         <label>Filter </label>
         <input  type="text"  id="inputName" [(ngModel)]="inputName"/>
         <input type="button" (click)="FilterByName()" value="Apply"/>
   </div>
   <div class='row'>
    <div class="panel">
    <!-- Default panel contents -->
    <!--<div class='panel-heading'>Product List</div> -->
    <div class='panel-body'>
         <table class="table table-bordered table-condensed table-hover table-striped"  >
            <thead>
               <th>Select</th>
               <th>Source</th>
               <th>Domain</th>
               <th>Region</th>
               <th>Frenquency</th>
            </thead>
            <tbody>
               <tr *ngFor="let item of items">
                  <td><input type="radio" name="radiogroup"></td>
                  <td>{{item.source}}</td>
                  <td>{{item.domain}}</td>
                  <td>{{item.region}}</td>
                  <td>{{item.frenquency}}</td>                 
               </tr>
            </tbody>
         </table>
         <div class="btn-toolbar" role="toolbar" style="margin: 0;">
          <div class="btn-group">
               <label style="margin-top:10px">Page {{currentIndex}}/{{pageNumber}}</label>
            </div>
            <div class="btn-group pull-right">
               <ul class="pagination" >
                  <li [ngClass]="{'disabled': (currentIndex == 1 || pageNumber == 0)}" ><a  (click)="prevPage()">Prev</a></li>
                     <li *ngFor="let page of pagesIndex"  [ngClass]="{'active': (currentIndex == page)}">
                        <a (click)="setPage(page)">{{page}}</a>
                     </li>
                  <li [ngClass]="{'disabled': (currentIndex == pageNumber || pageNumber == 0)}" ><a   (click)="nextPage()">Next</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
     
  `,
 styles: ['.pagination { margin: 0px !important; }']
})
export class SourcePagination {

   filteredItems : SourceProduct[];
   pages : number = 4;
  pageSize : number = 5;
   pageNumber : number = 0;
   currentIndex : number = 1;
   items: SourceProduct[];
   pagesIndex : Array<number>;
   pageStart : number = 1;
   inputName : string = '';
   
   
   
   constructor( ){
         this.filteredItems = sourceproductList;
       this.init();
   };
   init(){
         this.currentIndex = 1;
         this.pageStart = 1;
         this.pages = 4;

         this.pageNumber = parseInt(""+ (this.filteredItems.length / this.pageSize));
         if(this.filteredItems.length % this.pageSize != 0){
            this.pageNumber ++;
         }

         if(this.pageNumber  < this.pages){
               this.pages =  this.pageNumber;
         }
         this.refreshItems();
         console.log("this.pageNumber :  "+this.pageNumber);
   }
   FilterByName(){

      this.filteredItems = [];

      if(this.inputName != ""){

            sourceproductList.forEach(element => {
                  
                if(element.source.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                  this.filteredItems.push(element);
               }
               else if(element.domain.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                  this.filteredItems.push(element);
               }
               else if(element.region.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                  this.filteredItems.push(element);
               }
               else if(element.frenquency.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                  this.filteredItems.push(element);
               }
            });
      }else{
         this.filteredItems = sourceproductList;
      }
      console.log(this.filteredItems);
      this.init();
   }
   fillArray(): any{
      var obj = new Array();
      for(var index = this.pageStart; index< this.pageStart + this.pages; index ++) {

                  obj.push(index);

      }

      return obj;

   }

 refreshItems(){

               this.items = this.filteredItems.slice((this.currentIndex - 1)*this.pageSize, (this.currentIndex) * this.pageSize);

               this.pagesIndex =  this.fillArray();

   }

   prevPage(){
      if(this.currentIndex>1){
         this.currentIndex --;
      }
      if(this.currentIndex < this.pageStart){
         this.pageStart = this.currentIndex;
      }
      this.refreshItems();
   }

   nextPage(){
      if(this.currentIndex < this.pageNumber){
            this.currentIndex ++;
      }
      if(this.currentIndex >= (this.pageStart + this.pages)){
         this.pageStart = this.currentIndex - this.pages + 1;
      }

      this.refreshItems();
   }
    setPage(index : number){
         this.currentIndex = index;
         this.refreshItems();
    }

 }
