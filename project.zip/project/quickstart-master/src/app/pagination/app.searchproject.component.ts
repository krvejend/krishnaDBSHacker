import { Component, NgModule } from '@angular/core';
import { Http, HttpModule, Response } from '@angular/http';
import { Router } from "@angular/router";
import { Product } from "../Product";
import { UserTrack } from "../userTrack";
import { KeyValue } from "../keyvalue";
import { SessionService } from "../service/session.service";
import { UserService } from "../service/user.service";
import { Identify } from "../dataacquisition/identify/identify";
import { MyRecentProject } from "../dataacquisition/identify/searchproject";


@Component({
 selector: 'search-project',
 providers:[UserService],
 template: `

   <div class="form-group" style="float: right; padding-top: 10px; padding-left: 23px; margin-right: 20px;">
         <label>Search </label>
         <input  type="text"  id="inputName" [(ngModel)]="inputName"/>
         <a (click)="FilterByName()">
          <span class="glyphicon glyphicon-search"></span>
        </a>
   </div>

   <div class='row'>
    <div class="panel panal-table ">
    <div class='panel-body'>
         <table class="table table-bordered table-condensed table-hover table-striped">
            <thead>
               <th>Project Id</th>
               <th>Project Name</th>
               <th>Date Created</th>
               <th>Status</th>
            </thead>
            <tbody>
               <tr *ngFor="let item of items" >
                  <td><a (click)="clickItem(item)">{{item.projectId}}</a></td>
                  <td>{{item.projectName}}</td>
                  <td>{{item.dateCreated}}</td>
                  <td>{{item.Status}}</td>
               </tr>
            </tbody>
         </table>
         <div class="btn-toolbar " role="toolbar" style="margin: 0;">
          <div class="btn-group marginleft">
               <label style="margin-top:10px">Page {{currentIndex}}/{{pageNumber}}</label>
            </div>
            <div class="btn-group pull-right ">
               <ul class="pagination" >
                  <li [ngClass]="{'disabled': (currentIndex == 1 || pageNumber == 0)}" ><a  (click)="prevPage()">Prev</a></li>
                     <li *ngFor="let page of pagesIndex"  [ngClass]="{'active': (currentIndex == page)}">
                        <a (click)="setPage(page)">{{page}}</a>
                     </li>
                  <li [ngClass]="{'disabled': (currentIndex == pageNumber || pageNumber == 0)}" ><a   (click)="nextPage()">Next</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</div>
  `,
 styles: ['.pagination { margin: 0px !important; }']
})
export class SearchPagination {

   filteredItems : MyRecentProject[];
   pages : number = 4;
  pageSize : number = 5;
   pageNumber : number = 0;
   currentIndex : number = 1;
   items: MyRecentProject[];
   pagesIndex : Array<number>;
   pageStart : number = 1;
   inputName : string = '';
   showDialog:boolean = false;
  isNotApproved:boolean = false;
  isNotApprover:boolean =false;
  acquisitionId:string = "";
  showDialogApprove:boolean=false;
  showDialog1:boolean = false;
  jira;
  trackdata;
  trackdataDSAP;
 provisionItems:MyRecentProject[] = [];
      app_inst_ids = "10031";
      app_inst_names="ABONO A COMMERCIO MX"
      app_inst_short_names="ABACM";
      app_inst_descriptions="Instance Description";
      application_types="Business";
      app_inst_statuss="Active";
      app_inst_strategic_statuss="Non Strategic";
      app_inst_reviewer_emails="Raul GOMEZ/HBMX/HSBC";



  devices=['Rule1','Rule2','Rule3']

  userTrack:UserTrack[]=[];

  keyvalues:KeyValue[]=[];

   constructor( public sessionService:SessionService,private userService:UserService,private http:Http,private router: Router,){
        console.log("tttt", this.sessionService.getProductList());
         

        var item1 = new MyRecentProject("1417","Prj Name1","10-May-17","Prepare");
         var item2 = new MyRecentProject("1946","Prj Name7","6-May-17","Enrich");
         var item3 = new MyRecentProject("1403","Prj Name9","12-May-17","Govern");
         var item4= new MyRecentProject("1562","Prj Name8","1-May-17","Plan");

        this.provisionItems.push(item1);
        this.provisionItems.push(item2);
        this.provisionItems.push(item3);
        this.provisionItems.push(item4);
         this.filteredItems = this.provisionItems;
       this.init();
   };

  btnApprove= function () {
            this.router.navigate(['/approval']);
        }

        
   approveArray:MyRecentProject[]=[];
   
   init(){
         this.currentIndex = 1;
         this.pageStart = 1;
         this.pages = 4;
         if(this.sessionService.getRole()!="Approver"){
           this.isNotApprover = false;
         }else{
           this.isNotApprover = true;
         }

         this.pageNumber = parseInt(""+ (this.filteredItems.length / this.pageSize));
         if(this.filteredItems.length % this.pageSize != 0){
            this.pageNumber ++;
         }

         if(this.pageNumber  < this.pages){

               this.pages =  this.pageNumber;

         }
         this.refreshItems();
         console.log("this.pageNumber :  "+this.pageNumber);
   }



   FilterByName(){

      this.filteredItems = [];

      if(this.inputName != ""){

           this. provisionItems.forEach(element => {
              if(element.projectId){
                  if(element.projectId.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.projectName){
                   if(element.projectName.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.dateCreated.toString()){
                    if(element.dateCreated.toString().toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                if(element.Status){
                    if(element.Status.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

            });
      }else{
         this.filteredItems = this. provisionItems;
      }
      console.log(this.filteredItems);
      this.init();
   }
   fillArray(): any{
      var obj = new Array();
      for(var index = this.pageStart; index< this.pageStart + this.pages; index ++) {

                  obj.push(index);

      }

      return obj;

   }

 refreshItems(){
              console.log("test",this.filteredItems);
               this.items = this.filteredItems.slice((this.currentIndex - 1)*this.pageSize, (this.currentIndex) * this.pageSize);

               this.pagesIndex =  this.fillArray();

   }

   prevPage(){

      if(this.currentIndex>1){
         this.currentIndex --;
      }
      if(this.currentIndex < this.pageStart){

         this.pageStart = this.currentIndex;

      }

      this.refreshItems();

   }

   nextPage(){

      if(this.currentIndex < this.pageNumber){

            this.currentIndex ++;

      }

      if(this.currentIndex >= (this.pageStart + this.pages)){
         this.pageStart = this.currentIndex - this.pages + 1;
      }

      this.refreshItems();
   }
    setPage(index : number){
         this.currentIndex = index;
         this.refreshItems();
    }

 }
