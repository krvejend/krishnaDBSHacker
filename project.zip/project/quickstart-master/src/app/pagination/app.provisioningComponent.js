"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var user_service_1 = require("../service/user.service");
var Provision_1 = require("../Provision");
var userTrack_1 = require("../userTrack");
var keyvalue_1 = require("../keyvalue");
var session_service_1 = require("../service/session.service");
var http_1 = require("@angular/http");
var Product_1 = require("../Product");
var router_1 = require("@angular/router");
var availability_1 = require("../dataprovision/availability/availability");
var ProvisionPagination = (function () {
    function ProvisionPagination(sessionService, userService, http, router) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.http = http;
        this.router = router;
        this.pages = 4;
        this.pageSize = 5;
        this.pageNumber = 0;
        this.currentIndex = 1;
        this.pageStart = 1;
        this.inputName = '';
        this.showDialog = false;
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.acquisitionId = "";
        this.showDialogApprove = false;
        this.showDialog1 = false;
        this.provisionItems = [];
        this.app_inst_ids = "10031";
        this.app_inst_names = "ABONO A COMMERCIO MX";
        this.app_inst_short_names = "ABACM";
        this.app_inst_descriptions = "Instance Description";
        this.application_types = "Business";
        this.app_inst_statuss = "Active";
        this.app_inst_strategic_statuss = "Non Strategic";
        this.app_inst_reviewer_emails = "Raul GOMEZ/HBMX/HSBC";
        this.devices = ['Rule1', 'Rule2', 'Rule3'];
        this.userTrack = [];
        this.keyvalues = [];
        this.btnApprove = function () {
            this.router.navigate(['/pprepare']);
        };
        this.approveArray = [];
        var item1 = new Provision_1.Provision("10031", "ABONO A COMMERCIO", "Securities Lending Admin MS");
        var item2 = new Provision_1.Provision("10032", "ABONO A COMMERCIO", "BCBS Global Risk Reporting");
        this.provisionItems.push(item1);
        this.provisionItems.push(item2);
        this.filteredItems = this.provisionItems;
        this.init();
    }
    ;
    ProvisionPagination.prototype.updateChecked = function (option, event) {
        var approve = new availability_1.Availability(option.id, option.applicationName, option.systemName);
        if (event.target.checked) {
            this.approveArray.push(approve);
        }
        else if (!event.target.checked) {
            var indexx = this.approveArray.indexOf(approve);
            this.approveArray.splice(indexx, 1);
        }
        if (this.approveArray.length > 0) {
            this.isNotApproved = true;
        }
        else {
            this.isNotApproved = false;
        }
        console.log("checkbox-------------", this.approveArray);
    };
    ProvisionPagination.prototype.onClick = function (row) {
        if (row.acqusitionstatus != "Approved") {
            console.log(row.acqusitionstatus);
            this.acquisitionId = row.id;
        }
        else {
            console.log("false..");
        }
    };
    ProvisionPagination.prototype.scoreClass = function (item) {
        console.log("this is called...");
        if (item.acqusitionstatus != "Approved") {
            return "danger";
        }
        else {
            return "success";
        }
    };
    ProvisionPagination.prototype.btnClickNxt = function () {
        var _this = this;
        this.userService.postBulkApproval(this.approveArray).subscribe(function (data) {
            console.log("approve request", data);
            _this.http.get('/app/jiraid.json')
                .subscribe(function (res) { return _this.jira = res.json(); });
            _this.showDialogApprove = true;
            _this.isNotApproved = false;
            _this.userService.getTrackRequest(_this.sessionService.getUsername(), "requestorType").subscribe(function (data) {
                var productList = [];
                for (var i in data) {
                    var product = new Product_1.Product(data[i].data_acquisition_request_id, data[i].requested_user, data[i].app_inst_lvl_4_bus_org, data[i].app_inst_name, data[i].app_inst_lvl_4_bus_org_owner, data[i].stamp_created, data[i].status, "-", "-");
                    productList.push(product);
                }
                _this.sessionService.setProductList(productList);
                _this.filteredItems = _this.provisionItems;
            }, function () { return console.log("acq service called..."); });
        }, function () { return console.log("approve re id service called..."); });
    };
    ProvisionPagination.prototype.btnClickNxtSingle = function (status) {
        var _this = this;
        this.userService.postApproval(this.acquisitionId, status).subscribe(function (data) {
            console.log("approve request", data);
            _this.http.get('/app/jiraid.json')
                .subscribe(function (res) { return _this.jira = res.json(); });
            _this.showDialogApprove = true;
            _this.showDialog = false;
            _this.filteredItems = [];
            _this.userService.getTrackRequest(_this.sessionService.getUsername(), "requestorType").subscribe(function (data) {
                var productList = [];
                for (var i in data) {
                    var product = new Product_1.Product(data[i].data_acquisition_request_id, data[i].requested_user, data[i].app_inst_lvl_4_bus_org, data[i].app_inst_name, data[i].app_inst_lvl_4_bus_org_owner, data[i].stamp_created, data[i].status, "-", "-");
                    productList.push(product);
                }
                _this.sessionService.setProductList(productList);
                _this.filteredItems = _this.provisionItems;
            }, function () { return console.log("acq service called..."); });
        }, function () { return console.log("approve re id service called..."); });
    };
    ProvisionPagination.prototype.clickItem = function (item) {
        var _this = this;
        console.log(item.id);
        this.acquisitionId = item.id;
        this.showDialog = true;
        this.http.get('/app/trackdata.json')
            .subscribe(function (res) { return _this.trackdata = res.json(); });
        this.http.get('/app/trackdataDSAP.json')
            .subscribe(function (res) { return _this.trackdataDSAP = res.json(); });
        this.userService.getAppovalRequestData(item.id).subscribe(function (data) {
            _this.userTrack = [];
            _this.keyvalues = [];
            console.log("approvalId Data", data[0].app_inst_id);
            var userT = new userTrack_1.UserTrack(data[0].app_inst_id, data[0].app_inst_name, data[0].app_inst_short_name, data[0].app_inst_description, data[0].application_type, data[0].app_inst_status, data[0].app_inst_strategic_status, data[0].app_inst_reviewer_email, data[0].app_inst_reviewer_name, data[0].app_inst_lvl_4_bus_org, data[0].app_inst_lvl_4_bus_org_owner, data[0].app_inst_lvl_5_bus_org, data[0].app_inst_lvl_4_it_dir, data[0].app_inst_lvl_4_it_dir_owner, data[0].app_inst_lvl_5_it_dir, data[0].app_inst_lvl_5_it_dir_owner, data[0].app_inst_dev_manager_primary, data[0].app_inst_dev_manager_secondary, data[0].application_id, data[0].application_name, data[0].app_it_owner, data[0].app_bus_owner, data[0].app_inst_pri_data_centre, data[0].app_inst_pri_data_centre_type, data[0].app_inst_sec_data_centre, data[0].app_inst_supporting_region, data[0].app_inst_supporting_country, data[0].app_inst_dev_region, data[0].app_inst_dev_country, data[0].data_acquisition_request_id, data[0].request_type, data[0].requested_user, data[0].stamp_created, data[0].status);
            console.log(userT);
            _this.userTrack.push(userT);
            for (var obj in _this.userTrack) {
                if (_this.userTrack.hasOwnProperty(obj)) {
                    for (var prop in _this.userTrack[obj]) {
                        if (_this.userTrack[obj].hasOwnProperty(prop)) {
                            console.log(prop + ':' + _this.userTrack[obj][prop]);
                            var newKeyValue = new keyvalue_1.KeyValue(prop, _this.userTrack[obj][prop]);
                            _this.keyvalues.push(newKeyValue);
                        }
                    }
                }
            }
            console.log("keyvalues", _this.keyvalues);
            _this.userTrack.push(userT);
        }, function () { return console.log("acq id service called..."); });
    };
    ProvisionPagination.prototype.init = function () {
        this.currentIndex = 1;
        this.pageStart = 1;
        this.pages = 4;
        if (this.sessionService.getRole() != "Approver") {
            this.isNotApprover = false;
        }
        else {
            this.isNotApprover = true;
        }
        this.pageNumber = parseInt("" + (this.filteredItems.length / this.pageSize));
        if (this.filteredItems.length % this.pageSize != 0) {
            this.pageNumber++;
        }
        if (this.pageNumber < this.pages) {
            this.pages = this.pageNumber;
        }
        this.refreshItems();
        console.log("this.pageNumber :  " + this.pageNumber);
    };
    ProvisionPagination.prototype.FilterByName = function () {
        var _this = this;
        this.filteredItems = [];
        if (this.inputName != "") {
            this.provisionItems.forEach(function (element) {
                if (element.id) {
                    if (element.id.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.applicationName) {
                    if (element.applicationName.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.systemName) {
                    if (element.systemName.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
            });
        }
        else {
            this.filteredItems = this.provisionItems;
        }
        console.log(this.filteredItems);
        this.init();
    };
    ProvisionPagination.prototype.fillArray = function () {
        var obj = new Array();
        for (var index = this.pageStart; index < this.pageStart + this.pages; index++) {
            obj.push(index);
        }
        return obj;
    };
    ProvisionPagination.prototype.refreshItems = function () {
        console.log("test", this.filteredItems);
        this.items = this.filteredItems.slice((this.currentIndex - 1) * this.pageSize, (this.currentIndex) * this.pageSize);
        this.pagesIndex = this.fillArray();
    };
    ProvisionPagination.prototype.prevPage = function () {
        if (this.currentIndex > 1) {
            this.currentIndex--;
        }
        if (this.currentIndex < this.pageStart) {
            this.pageStart = this.currentIndex;
        }
        this.refreshItems();
    };
    ProvisionPagination.prototype.nextPage = function () {
        if (this.currentIndex < this.pageNumber) {
            this.currentIndex++;
        }
        if (this.currentIndex >= (this.pageStart + this.pages)) {
            this.pageStart = this.currentIndex - this.pages + 1;
        }
        this.refreshItems();
    };
    ProvisionPagination.prototype.setPage = function (index) {
        this.currentIndex = index;
        this.refreshItems();
    };
    ProvisionPagination = __decorate([
        core_1.Component({
            selector: 'provision-pagination',
            providers: [user_service_1.UserService],
            template: "\n\n   <div class=\"form-group\">\n         <label>Search </label>\n         <input  type=\"text\"  id=\"inputName\" [(ngModel)]=\"inputName\"/>\n         <a (click)=\"FilterByName()\">\n          <span class=\"glyphicon glyphicon-search\"></span>\n        </a>\n   </div>\n   \n   <div class='row'>\n    <div class=\"panel\">\n    <div class='panel-body'>\n         <table class=\"table table-bordered table-condensed table-hover table-striped\">\n            <thead>\n            <th> Select </th>\n            <th>Troux Id</th>\n            <th>Application Name</th>\n            <th> System Name </th>\n            </thead>\n            <tbody>\n               <tr *ngFor=\"let item of items\" >\n                  <td><input type=\"checkbox\" name=\"options\" value=\"{{item.id}}\" (change)=\"updateChecked(item, $event)\" /></td>\n                  <td>{{item.id}}</td>\n                  <td>{{item.applicationName}}</td>\n                  <td>{{item.systemName}}</td>\n               </tr>\n            </tbody>\n         </table>\n         <div class=\"btn-toolbar \" role=\"toolbar\" style=\"margin: 0;\">\n          <div class=\"btn-group marginleft\">\n               <label style=\"margin-top:10px\">Page {{currentIndex}}/{{pageNumber}}</label>\n            </div>\n            <div class=\"btn-group pull-right \">\n               <ul class=\"pagination\" >\n                  <li [ngClass]=\"{'disabled': (currentIndex == 1 || pageNumber == 0)}\" ><a  (click)=\"prevPage()\">Prev</a></li>\n                     <li *ngFor=\"let page of pagesIndex\"  [ngClass]=\"{'active': (currentIndex == page)}\">\n                        <a (click)=\"setPage(page)\">{{page}}</a>\n                     </li>\n                  <li [ngClass]=\"{'disabled': (currentIndex == pageNumber || pageNumber == 0)}\" ><a   (click)=\"nextPage()\">Next</a></li>\n               </ul>\n            </div>\n         </div>\n      </div>\n   </div>\n\n<div class=\"container\">\n      <div class=\"row\" style=\"margin-top: 2%;margin-bottom: 2%;\">\n        <div class=\"col-sm-12\" style=\"text-align:center;\">\n            <button type=\"submit\" (click)=\"btnApprove();\" class=\"btn-success btn\">Submit</button>\n            <button class=\"btn-success btn\">Save</button>\n        </div>\n        <div class=\"col-sm-12\">\n        </div>\n        </div>\n       </div>\n\n  ",
            styles: ['.pagination { margin: 0px !important; }']
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, http_1.Http, router_1.Router])
    ], ProvisionPagination);
    return ProvisionPagination;
}());
exports.ProvisionPagination = ProvisionPagination;
//# sourceMappingURL=app.provisioningComponent.js.map