"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
var session_service_1 = require("../service/session.service");
var user_service_1 = require("../service/user.service");
var searchproject_1 = require("../dataacquisition/identify/searchproject");
var SearchPagination = (function () {
    function SearchPagination(sessionService, userService, http, router) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.http = http;
        this.router = router;
        this.pages = 4;
        this.pageSize = 5;
        this.pageNumber = 0;
        this.currentIndex = 1;
        this.pageStart = 1;
        this.inputName = '';
        this.showDialog = false;
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.acquisitionId = "";
        this.showDialogApprove = false;
        this.showDialog1 = false;
        this.provisionItems = [];
        this.app_inst_ids = "10031";
        this.app_inst_names = "ABONO A COMMERCIO MX";
        this.app_inst_short_names = "ABACM";
        this.app_inst_descriptions = "Instance Description";
        this.application_types = "Business";
        this.app_inst_statuss = "Active";
        this.app_inst_strategic_statuss = "Non Strategic";
        this.app_inst_reviewer_emails = "Raul GOMEZ/HBMX/HSBC";
        this.devices = ['Rule1', 'Rule2', 'Rule3'];
        this.userTrack = [];
        this.keyvalues = [];
        this.btnApprove = function () {
            this.router.navigate(['/approval']);
        };
        this.approveArray = [];
        console.log("tttt", this.sessionService.getProductList());
        var item1 = new searchproject_1.MyRecentProject("1417", "Prj Name1", "10-May-17", "Prepare");
        var item2 = new searchproject_1.MyRecentProject("1946", "Prj Name7", "6-May-17", "Enrich");
        var item3 = new searchproject_1.MyRecentProject("1403", "Prj Name9", "12-May-17", "Govern");
        var item4 = new searchproject_1.MyRecentProject("1562", "Prj Name8", "1-May-17", "Plan");
        this.provisionItems.push(item1);
        this.provisionItems.push(item2);
        this.provisionItems.push(item3);
        this.provisionItems.push(item4);
        this.filteredItems = this.provisionItems;
        this.init();
    }
    ;
    SearchPagination.prototype.init = function () {
        this.currentIndex = 1;
        this.pageStart = 1;
        this.pages = 4;
        if (this.sessionService.getRole() != "Approver") {
            this.isNotApprover = false;
        }
        else {
            this.isNotApprover = true;
        }
        this.pageNumber = parseInt("" + (this.filteredItems.length / this.pageSize));
        if (this.filteredItems.length % this.pageSize != 0) {
            this.pageNumber++;
        }
        if (this.pageNumber < this.pages) {
            this.pages = this.pageNumber;
        }
        this.refreshItems();
        console.log("this.pageNumber :  " + this.pageNumber);
    };
    SearchPagination.prototype.FilterByName = function () {
        var _this = this;
        this.filteredItems = [];
        if (this.inputName != "") {
            this.provisionItems.forEach(function (element) {
                if (element.projectId) {
                    if (element.projectId.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.projectName) {
                    if (element.projectName.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.dateCreated.toString()) {
                    if (element.dateCreated.toString().toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.Status) {
                    if (element.Status.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
            });
        }
        else {
            this.filteredItems = this.provisionItems;
        }
        console.log(this.filteredItems);
        this.init();
    };
    SearchPagination.prototype.fillArray = function () {
        var obj = new Array();
        for (var index = this.pageStart; index < this.pageStart + this.pages; index++) {
            obj.push(index);
        }
        return obj;
    };
    SearchPagination.prototype.refreshItems = function () {
        console.log("test", this.filteredItems);
        this.items = this.filteredItems.slice((this.currentIndex - 1) * this.pageSize, (this.currentIndex) * this.pageSize);
        this.pagesIndex = this.fillArray();
    };
    SearchPagination.prototype.prevPage = function () {
        if (this.currentIndex > 1) {
            this.currentIndex--;
        }
        if (this.currentIndex < this.pageStart) {
            this.pageStart = this.currentIndex;
        }
        this.refreshItems();
    };
    SearchPagination.prototype.nextPage = function () {
        if (this.currentIndex < this.pageNumber) {
            this.currentIndex++;
        }
        if (this.currentIndex >= (this.pageStart + this.pages)) {
            this.pageStart = this.currentIndex - this.pages + 1;
        }
        this.refreshItems();
    };
    SearchPagination.prototype.setPage = function (index) {
        this.currentIndex = index;
        this.refreshItems();
    };
    SearchPagination = __decorate([
        core_1.Component({
            selector: 'search-project',
            providers: [user_service_1.UserService],
            template: "\n\n   <div class=\"form-group\" style=\"float: right; padding-top: 10px; padding-left: 23px; margin-right: 20px;\">\n         <label>Search </label>\n         <input  type=\"text\"  id=\"inputName\" [(ngModel)]=\"inputName\"/>\n         <a (click)=\"FilterByName()\">\n          <span class=\"glyphicon glyphicon-search\"></span>\n        </a>\n   </div>\n\n   <div class='row'>\n    <div class=\"panel panal-table \">\n    <div class='panel-body'>\n         <table class=\"table table-bordered table-condensed table-hover table-striped\">\n            <thead>\n               <th>Project Id</th>\n               <th>Project Name</th>\n               <th>Date Created</th>\n               <th>Status</th>\n            </thead>\n            <tbody>\n               <tr *ngFor=\"let item of items\" >\n                  <td><a (click)=\"clickItem(item)\">{{item.projectId}}</a></td>\n                  <td>{{item.projectName}}</td>\n                  <td>{{item.dateCreated}}</td>\n                  <td>{{item.Status}}</td>\n               </tr>\n            </tbody>\n         </table>\n         <div class=\"btn-toolbar \" role=\"toolbar\" style=\"margin: 0;\">\n          <div class=\"btn-group marginleft\">\n               <label style=\"margin-top:10px\">Page {{currentIndex}}/{{pageNumber}}</label>\n            </div>\n            <div class=\"btn-group pull-right \">\n               <ul class=\"pagination\" >\n                  <li [ngClass]=\"{'disabled': (currentIndex == 1 || pageNumber == 0)}\" ><a  (click)=\"prevPage()\">Prev</a></li>\n                     <li *ngFor=\"let page of pagesIndex\"  [ngClass]=\"{'active': (currentIndex == page)}\">\n                        <a (click)=\"setPage(page)\">{{page}}</a>\n                     </li>\n                  <li [ngClass]=\"{'disabled': (currentIndex == pageNumber || pageNumber == 0)}\" ><a   (click)=\"nextPage()\">Next</a></li>\n               </ul>\n            </div>\n         </div>\n      </div>\n   </div>\n</div>\n  ",
            styles: ['.pagination { margin: 0px !important; }']
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, http_1.Http, router_1.Router])
    ], SearchPagination);
    return SearchPagination;
}());
exports.SearchPagination = SearchPagination;
//# sourceMappingURL=app.searchproject.component.js.map