"use strict";
exports.productList = [];
//# sourceMappingURL=data1.js.map