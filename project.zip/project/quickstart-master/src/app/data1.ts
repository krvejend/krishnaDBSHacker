import {Ingestion} from './ingestion';
export var productList: Ingestion[] = [

]