export class Ingestion {
   constructor(
     public applicationId: string,
     public applicationName: string,  
    public sourcename: string,
    public frequency : string,
    public currentstatus : string,
    public lastrunstatus: string,
    public tables : string,
    public sizeingb:string,
    public nextdateforarchival:string,
    public dataclassification:string,
    public datazone:string
   ){

   }
}
