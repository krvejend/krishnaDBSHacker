export class ProvisionConfirm {
   constructor(
    public task : string,
    public slaInDays : string,
    public dateInitiated: string,
    public jiraticket: string,
    public requestor: string,
    public status: string,
    public lastUpdatedDate: string,
   ){

   }
}
