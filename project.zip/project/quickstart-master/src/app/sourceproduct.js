"use strict";
var SourceProduct = (function () {
    function SourceProduct(source, domain, region, frenquency) {
        this.source = source;
        this.domain = domain;
        this.region = region;
        this.frenquency = frenquency;
    }
    return SourceProduct;
}());
exports.SourceProduct = SourceProduct;
//# sourceMappingURL=sourceproduct.js.map