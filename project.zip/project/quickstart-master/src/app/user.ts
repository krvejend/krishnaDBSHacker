export class User {
   constructor(
    public app_inst_id : string,
    public app_inst_name : string,
    public app_inst_short_name : string,
    public app_inst_description : string,
    public application_type : string,
    public app_inst_status : string,
    public app_inst_strategic_status : string,
    public app_inst_reviewer_email : string,
    public app_inst_reviewer_name : string,
    public app_inst_lvl_4_bus_org : string,
    public app_inst_lvl_4_bus_org_owner : string,
    public app_inst_lvl_5_bus_org : string,
    public app_inst_lvl_4_it_dir : string,
    public app_inst_lvl_4_it_dir_owner : string,
    public app_inst_lvl_5_it_dir : string,
    public app_inst_lvl_5_it_dir_owner : string,
    public app_inst_dev_manager_primary : string,
    public app_inst_dev_manager_secondary : string,
    public application_id : string,
    public application_name : string,
    public app_it_owner : string,
    public app_bus_owner : string,
    public app_inst_pri_data_centre : string,
    public app_inst_pri_data_centre_type : string,
    public app_inst_sec_data_centre : string,
    public app_inst_supporting_region : string,
    public app_inst_supporting_country : string,
    public app_inst_dev_region : string,
    public app_inst_dev_country : string
   ){

   }
}
