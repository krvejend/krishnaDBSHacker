import {Http, Response} from '@angular/http';
import {Injectable, Component } from '@angular/core';
 
@Component({
  template: `<datatable [dataset]=cities>
                  <column [value]="'app_inst_id'" [header]="'App Id'"></column>
                  <column [value]="'app_inst_name'" [header]="'App Name'"></column>
                  <column [value]="'app_inst_id'" [header]="'App Short Name'"></column>
                  <column [value]="'app_inst_name'" [header]="'App Type'"></column>
                  <column [value]="'app_inst_id'" [header]="'App status'"></column>
                  <column [value]="'app_inst_name'" [header]="'App Strategic Status'"></column>

                  <column [value]="'app_inst_id'" [header]="'App Reviewer Email'"></column>
                  <column [value]="'app_inst_name'" [header]="'App Reviewer Name'"></column>
                  <column [value]="'app_inst_id'" [header]="'App lvl4 Busi Org'"></column>
                  <column [value]="'app_inst_name'" [header]="'App lvl4 Busi Org Owner'"></column>
                  <column [value]="'app_inst_id'" [header]="'app inst lvl 4 it dir'"></column>
                  <column [value]="'app_inst_name'" [header]="'app inst lvl 4 it dir Owner'"></column>

                  <column [value]="'app_inst_id'" [header]="'app inst lvl 5 it dir'"></column>
                  <column [value]="'app_inst_name'" [header]="'app inst lvl 5 it dir Owner'"></column>
                  <column [value]="'app_inst_id'" [header]="'app inst dev manager primary'"></column>
                  <column [value]="'app_inst_name'" [header]="'app inst dev manager csecondary'"></column>
                  <column [value]="'app_inst_id'" [header]="'Inst Sec Data Centre'"></column>
                  <column [value]="'app_inst_name'" [header]="'Inst Supporting Region'"></column>

                  <column [value]="'app_inst_id'" [header]="'Inst Pri Data Centre'"></column>
                  <column [value]="'app_inst_name'" [header]="'Inst Pri Data Centre Type'"></column>
                  <column [value]="'app_inst_id'" [header]="'Inst Supporting Country'"></column>
                  <column [value]="'app_inst_name'" [header]="'Inst Dev Region'"></column>
                  <column [value]="'app_inst_id'" [header]="'Inst Dev Country'"></column>
             </datatable>
             `,
 
})
export class PopupComponent { 
    cities;
 
    constructor(private http:Http) {
        this.http.get('data/cities.json')
                .subscribe(res => this.cities = res.json());
    }
}