"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var PopupComponent = (function () {
    function PopupComponent(http) {
        var _this = this;
        this.http = http;
        this.http.get('data/cities.json')
            .subscribe(function (res) { return _this.cities = res.json(); });
    }
    PopupComponent = __decorate([
        core_1.Component({
            template: "<datatable [dataset]=cities>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'App Id'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'App Name'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'App Short Name'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'App Type'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'App status'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'App Strategic Status'\"></column>\n\n                  <column [value]=\"'app_inst_id'\" [header]=\"'App Reviewer Email'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'App Reviewer Name'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'App lvl4 Busi Org'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'App lvl4 Busi Org Owner'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'app inst lvl 4 it dir'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'app inst lvl 4 it dir Owner'\"></column>\n\n                  <column [value]=\"'app_inst_id'\" [header]=\"'app inst lvl 5 it dir'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'app inst lvl 5 it dir Owner'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'app inst dev manager primary'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'app inst dev manager csecondary'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'Inst Sec Data Centre'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'Inst Supporting Region'\"></column>\n\n                  <column [value]=\"'app_inst_id'\" [header]=\"'Inst Pri Data Centre'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'Inst Pri Data Centre Type'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'Inst Supporting Country'\"></column>\n                  <column [value]=\"'app_inst_name'\" [header]=\"'Inst Dev Region'\"></column>\n                  <column [value]=\"'app_inst_id'\" [header]=\"'Inst Dev Country'\"></column>\n             </datatable>\n             ",
        }), 
        __metadata('design:paramtypes', [http_1.Http])
    ], PopupComponent);
    return PopupComponent;
}());
exports.PopupComponent = PopupComponent;
//# sourceMappingURL=app.popup.component.js.map