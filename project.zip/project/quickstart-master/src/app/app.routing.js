"use strict";
var router_1 = require('@angular/router');
var identify_component_1 = require('./dataacquisition/identify/identify.component');
var login_component_1 = require('./login/login.component');
var propagation_component_1 = require("./propagation/propagation.component");
var plan_component_1 = require("./dataacquisition/plan/plan.component");
var prepare_component_1 = require("./dataacquisition/prepare/prepare.component");
var define_component_1 = require('./dataacquisition/define/define.component');
var govern_component_1 = require('./dataacquisition/govern/govern.component');
var validate_component_1 = require('./dataacquisition/validate/validate.component');
var enrich_component_1 = require('./dataacquisition/enrich/enrich.component');
var promote_component_1 = require("./dataacquisition/promote/promote.component");
var dataacquisition_component_1 = require("./dataacquisition/acquisition/dataacquisition.component");
var dataingestion_component_1 = require("./dataingestion/dataingestion.component");
var availability_component_1 = require("./dataprovision/availability/availability.component");
var dataprovisionconfirm_component_1 = require('./dataprovision/confirm/dataprovisionconfirm.component');
var prepare_component_2 = require("./dataprovision/prepare/prepare.component");
var notify_component_1 = require("./dataprovision/notify/notify.component");
var initiate_component_1 = require("./dataprovision/initiate/initiate.component");
var appRoutes = [
    { path: '', component: login_component_1.LoginComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: 'landing', component: identify_component_1.LandingComponent },
    { path: 'trackrequest', component: propagation_component_1.PropagationComponent },
    { path: 'approval', component: plan_component_1.ApprovalComponent },
    { path: 'prepare', component: prepare_component_1.PrepropagationComponent },
    { path: 'define', component: define_component_1.SourceComponent },
    { path: 'daapproval', component: govern_component_1.FilterSourceComponent },
    { path: 'enrich', component: enrich_component_1.EnrichComponent },
    { path: 'validate', component: validate_component_1.ValidateComponent },
    { path: 'promote', component: promote_component_1.PromoteComponent },
    { path: 'acquisition', component: dataacquisition_component_1.DataAcqusitionComponent },
    { path: 'ingestion', component: dataingestion_component_1.DataIngestionComponent },
    { path: 'provision', component: availability_component_1.DataProvisionComponent },
    { path: 'pprepare', component: prepare_component_2.PrepareComponent },
    { path: 'notify', component: notify_component_1.NotifyComponent },
    { path: 'initiate', component: initiate_component_1.InitiateComponent },
    { path: 'confirmprovision', component: dataprovisionconfirm_component_1.DataProvisionConfirmComponent }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map