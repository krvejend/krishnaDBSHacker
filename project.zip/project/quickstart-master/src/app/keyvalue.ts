export class KeyValue {
   constructor(
    public key : string,
    public value : string,
   ){

   }
}
