import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import {Http,HttpModule , Response} from '@angular/http';
import { Router } from "@angular/router";

@Component({
  templateUrl: './app/dataacquisition/define/define.html',
})
export class SourceComponent implements OnInit {

  projectnames="Risk Data Capture";
  descriptions="Identify Risk through Availal";
  purposes="Risk Identification";
  clarityCodes="10054111";
  keyContacts="Ruwan Perera, Steven Morton";
  estimatedHours="100";

    ngOnInit(): void {}

    data: any[] = [];
    hash = {};
    selectedNodes: any[] = [];

        constructor(private router: Router) {


                  this.data =
                  [
                      {
                          "label": "Documents",
                          "children": [{
                                  "label": "Work",
                                  "children": [{"label": "Expenses.doc", "children":[]}, {"label": "Resume.doc", "children":[]}]
                              },
                              {
                                  "selected": false,
                                  "label": "Home",
                                  "children": [{"label": "Invoices.txt", "children":[]}]
                              }]
                      },
                      {
                          "label": "Pictures",
                          "children": [
                              {"label": "barcelona.jpg", "children":[]},
                              {"label": "logo.jpg", "children":[]},
                              {"label": "primeui.png", "children":[]}]
                      },
                      {
                          "label": "Movies",
                          "children": [{
                                  "label": "Al Pacino",
                                  "children": [{"label": "Scarface", "data": "Scarface Movie", "children":[]}, {"label": "Serpico", "data": "Serpico Movie", "children":[]}]
                              },
                              {
                                  "label": "Robert De Niro",
                                  "children": [{"label": "Goodfellas", "children":[]}, {"label": "Untouchables", "children":[]}]
                              }]
                      }
                  ]

                  this.hash = this.buildDataHierarchy(this.data);
        }

        buildDataHierarchy(data: any[]): any {
       let id = 1;
       let hash = {};
       let setNodeID = (node : any, parentId: number) => {
           hash[id] = node;
           node['selected'] = false;
           node['nodeId'] = id;
           node['parentNodeId'] = parentId;
           if (node.children.length){
               const parentId = id;
               node.children.forEach(function(node: any){
                   id++;
                   setNodeID(node, parentId);
               });
           }
           id++;
       }
       data.forEach(function(node: any){
           setNodeID(node, 0);
       });
       return hash;
   }

   nodeSelected(toggleNode: any) {
       // select / unselect all children (recursive)
       let toggleChildren = (node: any) => {
           node.children.forEach(function (child: any) {
               child.selected = node.selected;
               if (child.children.length) {
                   toggleChildren(child);
               }
           });
       }
       toggleChildren(toggleNode);

       //update parent if needed (recursive)
       let updateParent = (node: any) => {
           if (node.parentNodeId != 0) {
               const parentNode = this.hash[node.parentNodeId];
               const siblings = parentNode.children;
               parentNode.partialSelection = false;
               let equalSiblings = true;
               siblings.forEach(function(sibling: any){
                   if (sibling.selected !== node.selected){
                       equalSiblings = false;
                   }
               });
               if (equalSiblings){
                   parentNode.selected = node.selected;
                   if (parentNode.parentNodeId != 0){
                       updateParent(parentNode);
                   }
               }else{
                   parentNode.partialSelection = true;
               }
           }
       }
       updateParent(toggleNode);
       this.updateSelected();
   }

   updateSelected(){
       this.selectedNodes = [];
       for (let node in this.hash) {
           if (this.hash[node].selected) {
               let currentNode = this.hash[node];
               let nodeLabel = currentNode['label'];
               while (currentNode.parentNodeId !==0){
                   currentNode = this.hash[currentNode.parentNodeId];
                   nodeLabel = currentNode['label'] + ' > ' + nodeLabel;
               }
               this.selectedNodes.push(nodeLabel);
           }
       }
   }
         submitDefine= function (form: NgForm) {
            console.log("JSON VALUE.......",JSON.stringify(form.value));
            this.router.navigate(['/prepare']);
        }

        usecases = [{name:'ABONO A COMMERCIO'},{name:'Automated Clearing Settlement System - ACSS - CA'},{name:'HUB Import / Export System - Canada'},{name:'HUB Sales Solutions - Canada'},
      {name:'BT Dealerboards CA'},{name:'Broker Websites CA'},{name:'Clearing and Depository Services'},{name:'Computer Assisted Collection System HBCA'},{name:'HUB Front End 2 Canada ClientConnect'}];
        selectedUC = "";
      fileTypes = ['Oracle', 'Flat File', 'MainFrame']
      selectedfileTpe = this.fileTypes[0];
      duplicate:boolean = false;
      fileTypes1 = ['Oracle', 'Flat File', 'MainFrame']
      selectedfileTpe1 = this.fileTypes[0];
      types = [{name:"test",value:"test"},{name:"test1",value:"test2"}]

      test;
      withHeader = ['Yes','No'];
      dataTypes = ['INT','STRING','TIMESTAMP','DATE','BIGINT','DOUBLE','FLOAT','DECIMAL','CHAR','VARCHAR','BOOLEAN'];
      selectedHeader = this.withHeader[0];
      selectedTrailer = this.withHeader[0];
      jdbcStrings ="jdbc:oracle:thin:@localhost:1521:oracle_schema";
      dataIPs ="localhost";
      dataPorts ="1521";
      dataSchemas ="DaaS_Schema";
      dataCenters ="Mexico";
      san ="";
      fileNames ="";
      fieldName ="";
      startPosition ="";
      endPosition ="";
      cdNode ="";
      serverName ="";
      ipAddrs = "10.8.0.183";
      portNumbers ="1521";

      db_version="11.2";
      db_home="Opt/Oraapp/Client/12.1.0.2_x64_DBAcc1028";
      db_name="UHGL";
      db_nodes="localhost";
      tns_Admin="/abnitio/storage/vm/aspbcba/Tns_Admin";
      user="RESA_SAU_ASPBCBS239";
      password="XXXXXXXXXX";
      encrypted_password="XXXXXXXXXX";
      case="lower";
      generate_dml_with_nulls="true";
      field_type_prefereence="delimited";
      old_style_empty_string_null="false";
      fully_aualify_dml="false";
      dml_with_maximum_lenght="true";
      preserve_sql_whitespace="true";
      interface="default";
      maximum_data_size="100000000";
      treat_blanks_as_null="true";
      direct_parallel="true";
      
      addSource= function(){
        this.duplicate = true;
      }
      removeSource = function(){
        this.duplicate = false;
      }

}
