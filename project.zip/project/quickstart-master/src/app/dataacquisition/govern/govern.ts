export class Govern {
   constructor(
    public id: number,
    public datagroup : string,
    public applicationname : string,
    public sourceowner: string,
    public lob : string,
    public status:string,
    public region:string,
   ){

   }
}
