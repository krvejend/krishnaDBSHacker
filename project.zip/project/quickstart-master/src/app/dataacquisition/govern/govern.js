"use strict";
var Govern = (function () {
    function Govern(id, datagroup, applicationname, sourceowner, lob, status, region) {
        this.id = id;
        this.datagroup = datagroup;
        this.applicationname = applicationname;
        this.sourceowner = sourceowner;
        this.lob = lob;
        this.status = status;
        this.region = region;
    }
    return Govern;
}());
exports.Govern = Govern;
//# sourceMappingURL=govern.js.map