"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require("@angular/router");
var user_service_1 = require("../../service/user.service");
var session_service_1 = require("../../service/session.service");
var EnrichComponent = (function () {
    function EnrichComponent(sessionService, userService, router) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.router = router;
        this.selectedNodes = [];
        this.nodeSelect = function (event) {
            console.log("selectedFiles", this.selectedFiles);
            console.log(event);
        };
        this.selectedTable = "Data_Acquisition_Master";
        this.selectedColumns = "app_inst_id VARCHAR2(20)";
        this.ingestionscannertypes = "RDBMS SCANNER";
        this.databasetypes = "ORACLE";
        this.hostnames = "localhost";
        this.databasePorts = "3306";
        this.databaseNames = "DaaS_Schema";
        this.usernames = "DaaS_User";
        this.passwords = "********";
        this.fillColumns = function () {
            this.columns = ['app_inst_id VARCHAR2(20)', 'Column 2 INT', 'Column 3 DOUBLE', 'Column 4 FLOAT(n,n)'];
            this.selectedColumns = this.columns[0];
        };
        this.btnClick = function () {
            this.router.navigate(['/validate']);
        };
        this.btnClickLogoff = function () {
            this.router.navigate(['/login']);
        };
    }
    EnrichComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.getFilesystem().then(function (files) { return _this.files = files; });
        console.log("Approval is called..");
    };
    EnrichComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataacquisition/enrich/enrich.html',
            providers: [user_service_1.UserService],
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, router_1.Router])
    ], EnrichComponent);
    return EnrichComponent;
}());
exports.EnrichComponent = EnrichComponent;
//# sourceMappingURL=enrich.component.js.map