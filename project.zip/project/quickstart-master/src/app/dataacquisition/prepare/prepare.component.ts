import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { UserService } from "../../service/user.service";
import { SessionService } from "../../service/session.service";


@Component({
  templateUrl: './app/dataacquisition/prepare/prepare.html',
  providers:[UserService],
})
export class PrepropagationComponent implements OnInit {

  projectnames="Risk Data Capture";
  descriptions="Identify Risk through Availal";
  purposes="Risk Identification";
  clarityCodes="10054111";
  keyContacts="Ruwan Perera, Steven Morton";
  estimatedHours="100";
  
constructor(public sessionService:SessionService, private userService:UserService,private router: Router) { }
        ngOnInit(): void {

        this.userService.getTrackRequest("requestorName","requestorType").subscribe(
          data=>{
          console.log("test",data);
          this.myVar = true;
          },
         ()=>console.log("acq service called...")
        );

        }
myVar;
        usecases = ['Frauddetection','Frauddetection1', 'Frauddetection2'];
        selectedUC = "";

        clusters = ['RBWM','TERADATA', 'ORACLE'];
        selectedCluster = "";

        tables = ['Data_Acquisition_Master','Data_Acquisition_Request','Source_System_Config_Master'];
        selectedTable = "";

        columns = [];
        selectedColumns="";

        ingestionscannertypes="RDBMS SCANNER";
        databasetypes="ORACLE";
        hostnames="localhost";
        databasePorts="3306"
        databaseNames="DaaS_Schema";
        usernames="DaaS_User";
        passwords="********";
        fillColumns = function(){
        this.columns = ['app_inst_id VARCHAR2(20)','app_bus_owners VARCHAR2(20)','application_names VARCHAR2(20)','app_inst_supporting_countrys INT'];
        this.selectedColumns=this.columns[0];
        }
        btnClick= function () {
            this.router.navigate(['/enrich']);
        }
         btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }
}
