"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
var session_service_1 = require("../../service/session.service");
var Project_1 = require("./Project");
var ApprovalComponent = (function () {
    function ApprovalComponent(sessionService, router, http) {
        this.sessionService = sessionService;
        this.router = router;
        this.http = http;
        this.approveArray = [];
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.btnApprove = function () {
            this.router.navigate(['/daapproval']);
        };
    }
    ApprovalComponent.prototype.ngOnInit = function () {
        console.log("Approval is called..");
        var item = new Project_1.Project("10031", "Risk Lending", "Securities Lending Admin MS", "", "", "84", "Weekly");
        var item1 = new Project_1.Project("10032", "Global Risk", "BCBS Global Risk Reporting", "", "", "84", "Weekly");
        var productList = [];
        productList.push(item);
        productList.push(item1);
        this.items = productList;
    };
    ApprovalComponent.prototype.updateChecked = function (option, event) {
        var approve = new Project_1.Project(option.trouxID, option.applicationName, option.systemName, option.ingestionType, option.justification, option.retention, option.Frequency);
        if (event.target.checked) {
            this.approveArray.push(approve);
        }
        else if (!event.target.checked) {
            var indexx = this.approveArray.indexOf(approve);
            this.approveArray.splice(indexx, 1);
        }
        if (this.approveArray.length > 0) {
            this.isNotApproved = true;
        }
        else {
            this.isNotApproved = false;
        }
        console.log("checkbox-------------", this.approveArray);
    };
    ApprovalComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataacquisition/plan/plan.html',
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, router_1.Router, http_1.Http])
    ], ApprovalComponent);
    return ApprovalComponent;
}());
exports.ApprovalComponent = ApprovalComponent;
//# sourceMappingURL=plan.component.js.map