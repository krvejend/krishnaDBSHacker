export class Project {
   constructor(
    public trouxID : string,
    public applicationName:string,
    public systemName : string,
    public ingestionType: string,
    public justification:string,
    public retention: string,
    public Frequency : string
   ){

   }
}
