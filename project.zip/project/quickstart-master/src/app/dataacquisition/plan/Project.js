"use strict";
var Project = (function () {
    function Project(trouxID, applicationName, systemName, ingestionType, justification, retention, Frequency) {
        this.trouxID = trouxID;
        this.applicationName = applicationName;
        this.systemName = systemName;
        this.ingestionType = ingestionType;
        this.justification = justification;
        this.retention = retention;
        this.Frequency = Frequency;
    }
    return Project;
}());
exports.Project = Project;
//# sourceMappingURL=Project.js.map