import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Http, HttpModule, Response } from '@angular/http';
import { Router } from "@angular/router";
import { SessionService } from "../../service/session.service";
import { Project } from "./Project";


@Component({
  templateUrl: './app/dataacquisition/plan/plan.html',
})
export class ApprovalComponent implements OnInit {
  
  ngOnInit(): void {
    console.log("Approval is called..");
  var item = new Project("10031","Risk Lending","Securities Lending Admin MS","","","84","Weekly");
  var item1 = new Project("10032","Global Risk","BCBS Global Risk Reporting","","","84","Weekly");
   var productList: Project[] =[];
   productList.push(item);
   productList.push(item1);
   this.items = productList;
  }
   constructor( public sessionService:SessionService,private router: Router,private http:Http){}

   items: Project[];

    approveArray:Project[]=[]; 
    isNotApproved:boolean = false;
  isNotApprover:boolean =false;

    updateChecked(option, event) {
   var approve = new Project(option.trouxID,option.applicationName,option.systemName,option.ingestionType,option.justification,option.retention,option.Frequency);
    if(event.target.checked){
      this.approveArray.push(approve);
    }
    else if (!event.target.checked){
      let indexx = this.approveArray.indexOf(approve);
      this.approveArray.splice(indexx,1);
    }
    if(this.approveArray.length>0){
      this.isNotApproved = true;
    }else{
    this.isNotApproved = false;
    }
   console.log("checkbox-------------",this.approveArray);
  }

   btnApprove= function () {
             this.router.navigate(['/daapproval']);
         }
}
