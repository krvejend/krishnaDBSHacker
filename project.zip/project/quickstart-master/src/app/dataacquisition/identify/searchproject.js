"use strict";
var MyRecentProject = (function () {
    function MyRecentProject(projectId, projectName, dateCreated, Status) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.dateCreated = dateCreated;
        this.Status = Status;
    }
    return MyRecentProject;
}());
exports.MyRecentProject = MyRecentProject;
//# sourceMappingURL=searchproject.js.map