"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
var Product_1 = require("../../Product");
var session_service_1 = require("../../service/session.service");
var ValidateComponent = (function () {
    function ValidateComponent(sessionService, router, http) {
        this.sessionService = sessionService;
        this.router = router;
        this.http = http;
        this.selectedTable = "Data_Acquisition_Master";
        this.selectedColumns = "app_inst_id VARCHAR2(20)";
        this.ingestionscannertypes = "RDBMS SCANNER";
        this.databasetypes = "ORACLE";
        this.hostnames = "localhost";
        this.databasePorts = "3306";
        this.databaseNames = "DaaS_Schema";
        this.usernames = "DaaS_User";
        this.passwords = "********";
        this.projectnames = "project1";
        this.datagroups = "datagroup";
        this.Countrys = "UK";
        this.lobs = "lob";
        this.Purposes = "purpose";
        this.showDialogApprove = false;
        this.showDialogValidate = false;
        this.finalSubmit = function () {
            this.showDialogApprove = true;
            this.showDialogValidate = false;
        };
        this.approveValidate = function () {
            this.showDialogValidate = true;
        };
        this.btnNext = function () {
            this.router.navigate(['/promote']);
        };
    }
    ValidateComponent.prototype.ngOnInit = function () {
        console.log("Approval is called..");
        var item = new Product_1.Product(10031, "David A GRIMME", "RBWM", "Customer Account ", "Mexico", "ABONO A COMMERCIO", "Enrich", "Customer Account", "Mexico");
        var item1 = new Product_1.Product(10032, "David A GRIMME", "RBWM", "Customer Account", "Mexico", "ABONO A COMMERCIO", "Enrich", "Customer Account", "Mexico");
        var ite2 = new Product_1.Product(10031, "EventViewer", "RBWM", "Finance Risk Data ", "David A GRIMME", "BCBS", "ggf", "reer", "fdfd");
        var item3 = new Product_1.Product(10032, "Essentic Point Positive", "RBWM", "Bad Debts ", "David A GRIMME", "BCBS", "ggf", "reer", "fdfd");
        var item4 = new Product_1.Product(10031, "EventViewer", "Oracle", "localhost", "1521", "jdbc:oracle:thin:@localhost:1521:oracle_schema", "ggf", "reer", "fdfd");
        var item5 = new Product_1.Product(10032, "Essentic Point Positive", "Mysql", "localhost ", "3306", "jdbc:mysql:thin:@localhost:3306:mysql_schema", "ggf", "reer", "fdfd");
        var item6 = new Product_1.Product(10031, "EventViewer", "Oracle", "localhost", "1521", "ffd", "ggf", "reer", "fdfd");
        var item7 = new Product_1.Product(10032, "Essentic Point Positive", "Mysql", "localhost ", "3306", "ffd", "ggf", "reer", "fdfd");
        var item8 = new Product_1.Product(1521, "EventViewer", "Daas_User", "Oracle", "jdbc:oracle:thin:@localhost:1521:oracle_schema", "RDBMS SCANNER", "Data_Acquisition_Master", "app_inst_id VARCHAR2(20 )", "DaaS_Schema");
        var productList = [];
        var productList1 = [];
        var productList2 = [];
        var productList3 = [];
        productList.push(item);
        productList.push(item1);
        productList1.push(ite2);
        productList1.push(item3);
        productList2.push(item4);
        productList3.push(item8);
        this.items = productList;
        this.product = productList1;
        this.product1 = productList2;
        this.product3 = productList3;
    };
    ValidateComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataacquisition/validate/validate.html',
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, router_1.Router, http_1.Http])
    ], ValidateComponent);
    return ValidateComponent;
}());
exports.ValidateComponent = ValidateComponent;
//# sourceMappingURL=validate.component.js.map