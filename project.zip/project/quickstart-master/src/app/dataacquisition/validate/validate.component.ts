import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { Http } from "@angular/http";
import { Product } from "../../Product";
import { SessionService } from "../../service/session.service";


@Component({
  templateUrl: './app/dataacquisition/validate/validate.html',
})
export class ValidateComponent implements OnInit{

 ngOnInit(): void {
    console.log("Approval is called..");
    var item=new Product(10031,"David A GRIMME","RBWM","Customer Account ","Mexico","ABONO A COMMERCIO","Enrich","Customer Account","Mexico");
    var item1=new Product(10032,"David A GRIMME","RBWM","Customer Account","Mexico","ABONO A COMMERCIO","Enrich","Customer Account","Mexico");

    var ite2=new Product(10031,"EventViewer","RBWM","Finance Risk Data ","David A GRIMME","BCBS","ggf","reer","fdfd");
   var item3=new Product(10032,"Essentic Point Positive","RBWM","Bad Debts ","David A GRIMME","BCBS","ggf","reer","fdfd");


   var item4=new Product(10031,"EventViewer","Oracle","localhost","1521","jdbc:oracle:thin:@localhost:1521:oracle_schema","ggf","reer","fdfd");
   var item5=new Product(10032,"Essentic Point Positive","Mysql","localhost ","3306","jdbc:mysql:thin:@localhost:3306:mysql_schema","ggf","reer","fdfd");


   var item6=new Product(10031,"EventViewer","Oracle","localhost","1521","ffd","ggf","reer","fdfd");
   var item7=new Product(10032,"Essentic Point Positive","Mysql","localhost ","3306","ffd","ggf","reer","fdfd");

   var item8=new Product(1521,"EventViewer","Daas_User","Oracle","jdbc:oracle:thin:@localhost:1521:oracle_schema","RDBMS SCANNER","Data_Acquisition_Master","app_inst_id VARCHAR2(20 )","DaaS_Schema");

   var productList: Product[] =[];
   var productList1: Product[] =[];
   var productList2: Product[] =[];
   var productList3: Product[] =[];
   productList.push(item);
   productList.push(item1);
  productList1.push(ite2);
  productList1.push(item3);

  productList2.push(item4);

productList3.push(item8);

   this.items = productList;
   this.product = productList1;
   this.product1 = productList2;
   this.product3 = productList3;
  }
   constructor( public sessionService:SessionService,private router: Router,private http:Http){}

   items: Product[];
   product:Product[];
   product1:Product[];
   product2:Product[];
   product3:Product[];

   selectedTable = "Data_Acquisition_Master";

   selectedColumns="app_inst_id VARCHAR2(20)";

   ingestionscannertypes="RDBMS SCANNER";
   databasetypes="ORACLE";
   hostnames="localhost";
   databasePorts="3306"
   databaseNames="DaaS_Schema";
   usernames="DaaS_User";
   passwords="********";
projectnames="project1";
datagroups="datagroup";
Countrys="UK";
lobs="lob";
Purposes="purpose";
showDialogApprove:boolean = false;
showDialogValidate:boolean=false;
finalSubmit=function(){
  this.showDialogApprove = true;
   this.showDialogValidate = false;
}
approveValidate=function(){
  this.showDialogValidate = true;
}

btnNext= function () {
            this.router.navigate(['/promote']);
        }
}
