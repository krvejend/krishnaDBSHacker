"use strict";
var ProvisionConfirm = (function () {
    function ProvisionConfirm(task, slaInDays, dateInitiated, jiraticket, requestor, status, lastUpdatedDate) {
        this.task = task;
        this.slaInDays = slaInDays;
        this.dateInitiated = dateInitiated;
        this.jiraticket = jiraticket;
        this.requestor = requestor;
        this.status = status;
        this.lastUpdatedDate = lastUpdatedDate;
    }
    return ProvisionConfirm;
}());
exports.ProvisionConfirm = ProvisionConfirm;
//# sourceMappingURL=ProvisionConfirm.js.map