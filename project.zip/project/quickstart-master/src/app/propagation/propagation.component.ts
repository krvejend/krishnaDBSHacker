import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import {Http,HttpModule , Response} from '@angular/http';
import { Router } from "@angular/router";
import {UserService} from '../service/user.service';
import {SessionService} from '../service/session.service';
import {Product} from '../Product';

@Component({
  templateUrl: './app/propagation/propagation.html',
  providers:[UserService],
})
export class PropagationComponent implements OnInit {

constructor(private http:Http, private router: Router,public sessionService:SessionService, private userService:UserService) {
    this.http.get('/company.json')
            .subscribe(res => this.companies = res.json());
}

  ngOnInit(): void {
    console.log("propagation is called..");

    if(this.sessionService.getRole()!="Approver"){
      this.isNotApprover = true;
    }else{
      this.isNotApprover = false;
    }


  }

   companies;
   isNotApprover:boolean =true;

    btnClickNxt= function () {
            this.router.navigate(['/source']);
        }
        btnClickDCn= function () {
            this.router.navigate(['/approval']);
        }
         btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }


}
