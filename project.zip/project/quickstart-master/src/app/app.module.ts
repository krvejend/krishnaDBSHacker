import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { routing }        from './app.routing';
import { AppComponent }  from './app.component';
import { LandingComponent} from './dataacquisition/identify/identify.component';
import { LoginComponent } from './login/login.component'
import { PropagationComponent } from "./propagation/propagation.component";
import { ApprovalComponent } from './dataacquisition/plan/plan.component';
import {DatatableComponent} from './popup/datatable.component';
import {ColumnComponent} from './popup/column.component';
import {HttpModule} from '@angular/http';
import { Pagination}   from './pagination/app.paginationComponent';
import { SearchPagination}   from './pagination/app.searchproject.component';
import { Pagination1}   from './pagination/app.Ingestionpagination.component';
import {ProvisionPagination} from './pagination/app.provisioningComponent'
import {PrepropagationComponent} from './dataacquisition/prepare/prepare.component';
import {SourcePagination} from "./app.source.component";
import {SourceComponent} from './dataacquisition/define/define.component';
import{ FilterSourceComponent } from './dataacquisition/govern/govern.component';
import {PopupComponent } from './popup.component';
import {UserService} from './service/user.service';
import {User} from './user';
import {SessionService} from './service/session.service';
import {ValidateComponent} from './dataacquisition/validate/validate.component';
import {PromoteComponent} from './dataacquisition/promote/promote.component';
import {EnrichComponent} from './dataacquisition/enrich/enrich.component';
import {ComboBoxComponent} from 'ng2-combobox';
import {AutoCompleteModule} from 'primeng/primeng';
import {DataAcqusitionComponent} from './dataacquisition/acquisition/dataacquisition.component';
import { DataIngestionComponent } from './dataingestion/dataingestion.component';
import { DataProvisionComponent } from './dataprovision/availability/availability.component';
import { TreeModule, SharedModule,TreeTableModule,TreeNode} from 'primeng/primeng';
import { DataProvisionConfirmComponent } from './dataprovision/confirm/dataprovisionconfirm.component';
import { PrepareComponent } from "./dataprovision/prepare/prepare.component";
import { NotifyComponent } from "./dataprovision/notify/notify.component";
import { InitiateComponent } from "./dataprovision/initiate/initiate.component";


@NgModule({
  imports:      [ BrowserModule,FormsModule,routing,HttpModule,TreeModule,SharedModule,AutoCompleteModule,TreeTableModule ],
   providers:    [UserService,SessionService],
  declarations: [ AppComponent,DataAcqusitionComponent,DataIngestionComponent,DataProvisionComponent,
    LandingComponent,EnrichComponent,ComboBoxComponent,SourcePagination,ValidateComponent,PromoteComponent,
    SourceComponent,PopupComponent, FilterSourceComponent,LoginComponent,Pagination,SearchPagination,Pagination1,
    ProvisionPagination,PrepropagationComponent,PropagationComponent,ApprovalComponent,DatatableComponent,
    ColumnComponent,DataProvisionConfirmComponent,PrepareComponent, NotifyComponent,InitiateComponent],
  bootstrap:    [ AppComponent],
})
export class AppModule { }
