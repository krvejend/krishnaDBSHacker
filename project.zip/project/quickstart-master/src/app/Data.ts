import {Product} from './Product';
export var productList: Product[] = [

]
