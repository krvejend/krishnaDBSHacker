import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Rx';
import { User } from '../user'
import { TreeNode } from "primeng/primeng";

@Injectable()
export class UserService {
  constructor (
    private http: Http
  ) {}

  getUser() {
    return this.http.get(`https://conduit.productionready.io/api/profiles/eric`)
    .map((res:Response) => res.json());
  }

  postJSON(username){
    var json = JSON.stringify({ 
    "username": username
    })
    let headers = new Headers({ 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' }); // ... Set content type to JSON
    let options = new RequestOptions({ headers: headers }); // Create a request option
    return this.http.post('http://10.108.0.193:8080/services/daservice/login', json, options) // ...using post request
    .map((res:Response) => <User>res.json()) // ...and calling .json() on the response to return data
    .catch((error:any) => Observable.throw(error.json().error || 'Server error')); //...errors if any
}

postAcquisition(acqData){
let headers = new Headers({ 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' }); // ... Set content type to JSON
let options = new RequestOptions({ headers: headers }); // Create a request option
return this.http.post('http://10.108.0.193:8080/services/daservice/create', acqData, options) // ...using post request
.map((res:Response) => <User>res.json()) // ...and calling .json() on the response to return data
.catch((error:any) => Observable.throw(error.json().error || 'Server error')); //...errors if any
}

getTrackRequest(requestorName,requestorType){
var url = 'http://10.108.0.193:8080/services/daservice/trackrequest/'+requestorName+'/Acquisition'
return this.http.get(url)
.map((res:Response) => res.json());
}

getAppovalRequestData(test){
var url="http://10.108.0.193:8080/services/daservice/fetch/"+test
return this.http.get(url)
.map((res:Response) => res.json());
}

postApproval(dataId,status){
  var json = JSON.stringify({
  "data_acquisition_request_id": dataId,
  "status": status
} )
  let headers = new Headers({ 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' }); // ... Set content type to JSON
  let options = new RequestOptions({ headers: headers }); // Create a request option
  return this.http.post('http://10.108.0.193:8080/services/daservice/update', json, options) // ...using post request
  .map((res:Response) => <User>res.json()) // ...and calling .json() on the response to return data
  .catch((error:any) => Observable.throw(error.json().error || 'Server error')); //...errors if any
}

postBulkApproval(bulkApprove){
  var json = JSON.stringify(bulkApprove);
  let headers = new Headers({ 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' }); // ... Set content type to JSON
  let options = new RequestOptions({ headers: headers }); // Create a request option
  return this.http.post('http://10.108.0.193:8080/services/daservice/updateBulk', json, options) // ...using post request
  .map((res:Response) => <User>res.json()) // ...and calling .json() on the response to return data
  .catch((error:any) => Observable.throw(error.json().error || 'Server error')); //...errors if any
}
getFilesystem() {
       return this.http.get('app/filesystem.json')
                   .toPromise()
                   .then(res => <TreeNode[]> res.json().data);
   }

}
