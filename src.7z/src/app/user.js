"use strict";
var User = (function () {
    function User(app_inst_id, app_inst_name, app_inst_short_name, app_inst_description, application_type, app_inst_status, app_inst_strategic_status, app_inst_reviewer_email, app_inst_reviewer_name, app_inst_lvl_4_bus_org, app_inst_lvl_4_bus_org_owner, app_inst_lvl_5_bus_org, app_inst_lvl_4_it_dir, app_inst_lvl_4_it_dir_owner, app_inst_lvl_5_it_dir, app_inst_lvl_5_it_dir_owner, app_inst_dev_manager_primary, app_inst_dev_manager_secondary, application_id, application_name, app_it_owner, app_bus_owner, app_inst_pri_data_centre, app_inst_pri_data_centre_type, app_inst_sec_data_centre, app_inst_supporting_region, app_inst_supporting_country, app_inst_dev_region, app_inst_dev_country) {
        this.app_inst_id = app_inst_id;
        this.app_inst_name = app_inst_name;
        this.app_inst_short_name = app_inst_short_name;
        this.app_inst_description = app_inst_description;
        this.application_type = application_type;
        this.app_inst_status = app_inst_status;
        this.app_inst_strategic_status = app_inst_strategic_status;
        this.app_inst_reviewer_email = app_inst_reviewer_email;
        this.app_inst_reviewer_name = app_inst_reviewer_name;
        this.app_inst_lvl_4_bus_org = app_inst_lvl_4_bus_org;
        this.app_inst_lvl_4_bus_org_owner = app_inst_lvl_4_bus_org_owner;
        this.app_inst_lvl_5_bus_org = app_inst_lvl_5_bus_org;
        this.app_inst_lvl_4_it_dir = app_inst_lvl_4_it_dir;
        this.app_inst_lvl_4_it_dir_owner = app_inst_lvl_4_it_dir_owner;
        this.app_inst_lvl_5_it_dir = app_inst_lvl_5_it_dir;
        this.app_inst_lvl_5_it_dir_owner = app_inst_lvl_5_it_dir_owner;
        this.app_inst_dev_manager_primary = app_inst_dev_manager_primary;
        this.app_inst_dev_manager_secondary = app_inst_dev_manager_secondary;
        this.application_id = application_id;
        this.application_name = application_name;
        this.app_it_owner = app_it_owner;
        this.app_bus_owner = app_bus_owner;
        this.app_inst_pri_data_centre = app_inst_pri_data_centre;
        this.app_inst_pri_data_centre_type = app_inst_pri_data_centre_type;
        this.app_inst_sec_data_centre = app_inst_sec_data_centre;
        this.app_inst_supporting_region = app_inst_supporting_region;
        this.app_inst_supporting_country = app_inst_supporting_country;
        this.app_inst_dev_region = app_inst_dev_region;
        this.app_inst_dev_country = app_inst_dev_country;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.js.map