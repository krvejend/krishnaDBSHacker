import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {Form, FormGroup, FormBuilder, Validators} from '@angular/forms';
import {SessionService} from '../service/session.service';
import {User} from '../user';
import {UserService} from '../service/user.service';
import {Product} from '../Product';

@Component({
  templateUrl: './app/login/login.html',
   providers:[UserService],
})
export class LoginComponent  {

 constructor(
        private router: Router,
        private userService:UserService,
        public sessionService:SessionService
        ) { }

data= {username:'', password:''};
error = false;
postData:User;
formSubmit(){
    var item=new Product(10030,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","David A GRIMME","Risk Profile Questionnaire","Identify","Customer Account","Mexico");
    var item1=new Product(10031,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","David A GRIMME","Securities Lending Admin MS","Project","Customer Account","Mexico");
    var item2=new Product(10032,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","BCBS Global Risk Reporting","Govern","Customer Account","Mexico");
    var item3=new Product(10033,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","David A GRIMME","Premier Risk Profile","Define","Customer Account","Mexico");
    var item4=new Product(10034,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","Catalyst","Prepare","Customer Account","Mexico");
    var item5=new Product(10035,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","David A GRIMME","CBT Risk Consolidation","Enrich","Customer Account","Mexico");
    var item6=new Product(10036,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","CCIL Integrated Risk Info Sys","Validate","Customer Account","Mexico");
    var item7=new Product(10037,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","David A GRIMME","BCBS Global Risk Reporting","Promote","Customer Account","Mexico");
    var item8=new Product(10038,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","BCBS Global Risk Reporting","Define","Customer Account","Mexico");
    var item9=new Product(10039,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","BCBS Global Risk Reporting","Identify","Customer Account","Mexico");
    var item10=new Product(10040,"ABONO A COMMERCIO","RBWM","ABONO A COMMERCIO","Raul GOMEZ","BCBS Global Risk Reporting","Identify","Customer Account","Mexico");
    var productList: Product[] =[];
    productList.push(item1);
    productList.push(item2);
    productList.push(item3);
    productList.push(item4);
    productList.push(item5);
    productList.push(item6);
    productList.push(item7);
    productList.push(item8);
    productList.push(item9);
    productList.push(item10);
    this.sessionService.setProductList(productList);
    this.router.navigate(['/landing']);
  }
}
