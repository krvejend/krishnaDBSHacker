"use strict";
var Ingestion = (function () {
    function Ingestion(applicationId, applicationName, sourcename, frequency, currentstatus, lastrunstatus, tables, sizeingb, nextdateforarchival, dataclassification, datazone) {
        this.applicationId = applicationId;
        this.applicationName = applicationName;
        this.sourcename = sourcename;
        this.frequency = frequency;
        this.currentstatus = currentstatus;
        this.lastrunstatus = lastrunstatus;
        this.tables = tables;
        this.sizeingb = sizeingb;
        this.nextdateforarchival = nextdateforarchival;
        this.dataclassification = dataclassification;
        this.datazone = datazone;
    }
    return Ingestion;
}());
exports.Ingestion = Ingestion;
//# sourceMappingURL=Ingestion.js.map