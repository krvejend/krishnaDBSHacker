"use strict";
var Project = (function () {
    function Project(trouxID, systemName, justification, retention, Frequency) {
        this.trouxID = trouxID;
        this.systemName = systemName;
        this.justification = justification;
        this.retention = retention;
        this.Frequency = Frequency;
    }
    return Project;
}());
exports.Project = Project;
//# sourceMappingURL=Project.js.map