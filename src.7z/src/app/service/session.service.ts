import {Component, NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'

import { Injectable } from '@angular/core';
import {User} from '../user';
import {Product} from '../Product';

@Injectable()
export class SessionService {

    private loggedIn: boolean = false;

    private user:User;

    private userName:string;

    private productList:Product[];

    private role:string;

    getRole():string{
    return this.role;
    }

    setRole(role:string){
    this.role = role;
    }
    
    getUsername():string{
    return this.userName;
    }

    setUserName(user:string){
    this.userName = user;
    }

    isLoggedIn():boolean{
        return this.loggedIn;
    }



    setLoggedIn(isLoggedIn: boolean){
        this.loggedIn = isLoggedIn;
    }

    getUser():User{
      return this.user;
    }

    setUser(newUser:User){
      this.user = newUser;
    }

    getProductList(){
    return this.productList;
    }

    setProductList(productLi:Product[]){
    this.productList = productLi;
    }
}
