import {SourceProduct} from './sourceproduct';
export var sourceproductList: SourceProduct[] = [
  {"source": "Customer", "domain": "Retail", "region": "UK","frenquency": "daily"},
  {"source": "Products", "domain": "Retail", "region": "US","frenquency": "weekly"},
  {"source": "Insurance", "domain": "Retail", "region": "UK","frenquency": "monthly"},   
]
