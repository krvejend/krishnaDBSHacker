"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var sourcedata_1 = require('./sourcedata');
var SourcePagination = (function () {
    function SourcePagination() {
        this.pages = 4;
        this.pageSize = 5;
        this.pageNumber = 0;
        this.currentIndex = 1;
        this.pageStart = 1;
        this.inputName = '';
        this.filteredItems = sourcedata_1.sourceproductList;
        this.init();
    }
    ;
    SourcePagination.prototype.init = function () {
        this.currentIndex = 1;
        this.pageStart = 1;
        this.pages = 4;
        this.pageNumber = parseInt("" + (this.filteredItems.length / this.pageSize));
        if (this.filteredItems.length % this.pageSize != 0) {
            this.pageNumber++;
        }
        if (this.pageNumber < this.pages) {
            this.pages = this.pageNumber;
        }
        this.refreshItems();
        console.log("this.pageNumber :  " + this.pageNumber);
    };
    SourcePagination.prototype.FilterByName = function () {
        var _this = this;
        this.filteredItems = [];
        if (this.inputName != "") {
            sourcedata_1.sourceproductList.forEach(function (element) {
                if (element.source.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                    _this.filteredItems.push(element);
                }
                else if (element.domain.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                    _this.filteredItems.push(element);
                }
                else if (element.region.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                    _this.filteredItems.push(element);
                }
                else if (element.frenquency.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                    _this.filteredItems.push(element);
                }
            });
        }
        else {
            this.filteredItems = sourcedata_1.sourceproductList;
        }
        console.log(this.filteredItems);
        this.init();
    };
    SourcePagination.prototype.fillArray = function () {
        var obj = new Array();
        for (var index = this.pageStart; index < this.pageStart + this.pages; index++) {
            obj.push(index);
        }
        return obj;
    };
    SourcePagination.prototype.refreshItems = function () {
        this.items = this.filteredItems.slice((this.currentIndex - 1) * this.pageSize, (this.currentIndex) * this.pageSize);
        this.pagesIndex = this.fillArray();
    };
    SourcePagination.prototype.prevPage = function () {
        if (this.currentIndex > 1) {
            this.currentIndex--;
        }
        if (this.currentIndex < this.pageStart) {
            this.pageStart = this.currentIndex;
        }
        this.refreshItems();
    };
    SourcePagination.prototype.nextPage = function () {
        if (this.currentIndex < this.pageNumber) {
            this.currentIndex++;
        }
        if (this.currentIndex >= (this.pageStart + this.pages)) {
            this.pageStart = this.currentIndex - this.pages + 1;
        }
        this.refreshItems();
    };
    SourcePagination.prototype.setPage = function (index) {
        this.currentIndex = index;
        this.refreshItems();
    };
    SourcePagination = __decorate([
        core_1.Component({
            selector: 'my-source',
            template: "\n   <div class=\"form-group\">\n         <label>Filter </label>\n         <input  type=\"text\"  id=\"inputName\" [(ngModel)]=\"inputName\"/>\n         <input type=\"button\" (click)=\"FilterByName()\" value=\"Apply\"/>\n   </div>\n   <div class='row'>\n    <div class=\"panel\">\n    <!-- Default panel contents -->\n    <!--<div class='panel-heading'>Product List</div> -->\n    <div class='panel-body'>\n         <table class=\"table table-bordered table-condensed table-hover table-striped\"  >\n            <thead>\n               <th>Select</th>\n               <th>Source</th>\n               <th>Domain</th>\n               <th>Region</th>\n               <th>Frenquency</th>\n            </thead>\n            <tbody>\n               <tr *ngFor=\"let item of items\">\n                  <td><input type=\"radio\" name=\"radiogroup\"></td>\n                  <td>{{item.source}}</td>\n                  <td>{{item.domain}}</td>\n                  <td>{{item.region}}</td>\n                  <td>{{item.frenquency}}</td>                 \n               </tr>\n            </tbody>\n         </table>\n         <div class=\"btn-toolbar\" role=\"toolbar\" style=\"margin: 0;\">\n          <div class=\"btn-group\">\n               <label style=\"margin-top:10px\">Page {{currentIndex}}/{{pageNumber}}</label>\n            </div>\n            <div class=\"btn-group pull-right\">\n               <ul class=\"pagination\" >\n                  <li [ngClass]=\"{'disabled': (currentIndex == 1 || pageNumber == 0)}\" ><a  (click)=\"prevPage()\">Prev</a></li>\n                     <li *ngFor=\"let page of pagesIndex\"  [ngClass]=\"{'active': (currentIndex == page)}\">\n                        <a (click)=\"setPage(page)\">{{page}}</a>\n                     </li>\n                  <li [ngClass]=\"{'disabled': (currentIndex == pageNumber || pageNumber == 0)}\" ><a   (click)=\"nextPage()\">Next</a></li>\n               </ul>\n            </div>\n         </div>\n      </div>\n   </div>\n     \n  ",
            styles: ['.pagination { margin: 0px !important; }']
        }), 
        __metadata('design:paramtypes', [])
    ], SourcePagination);
    return SourcePagination;
}());
exports.SourcePagination = SourcePagination;
//# sourceMappingURL=app.source.component.js.map