import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component'
import { LandingComponent} from './dataacquisition/identify/identify.component'
import { LoginComponent } from './login/login.component'
import { PropagationComponent } from "./propagation/propagation.component";
import { ApprovalComponent } from "./dataacquisition/plan/plan.component";
import {PrepropagationComponent} from "./dataacquisition/prepare/prepare.component";
import {SourceComponent} from './dataacquisition/define/define.component';
import{ FilterSourceComponent } from './dataacquisition/govern/govern.component';
import {ValidateComponent} from './dataacquisition/validate/validate.component';
import { EnrichComponent } from './dataacquisition/enrich/enrich.component';
import { PromoteComponent } from "./dataacquisition/promote/promote.component";
import { DataAcqusitionComponent } from "./dataacquisition/acquisition/dataacquisition.component";
import { DataIngestionComponent } from "./dataingestion/dataingestion.component";
import { DataProvisionComponent } from "./dataprovision/availability/availability.component";
import { DataProvisionConfirmComponent } from './dataprovision/confirm/dataprovisionconfirm.component';
import { PrepareComponent } from "./dataprovision/prepare/prepare.component";
import { NotifyComponent } from "./dataprovision/notify/notify.component";
import { InitiateComponent } from "./dataprovision/initiate/initiate.component";

const appRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'login', component: LoginComponent },
    { path: 'landing', component: LandingComponent },
    { path: 'trackrequest', component: PropagationComponent },
    { path: 'approval', component: ApprovalComponent },
    {path:'prepare', component:PrepropagationComponent},
    {path:'define',component:SourceComponent},
    {path:'daapproval', component:FilterSourceComponent},
    {path:'enrich',component:EnrichComponent},
    {path:'validate',component:ValidateComponent},
    {path:'promote',component:PromoteComponent},
    {path:'acquisition',component:DataAcqusitionComponent},
    {path:'ingestion',component:DataIngestionComponent},
    {path:'provision',component:DataProvisionComponent},
    {path:'pprepare',component:PrepareComponent},
    {path:'notify',component:NotifyComponent},
    {path:'initiate',component:InitiateComponent},
    {path:'confirmprovision',component:DataProvisionConfirmComponent}

];

export const routing = RouterModule.forRoot(appRoutes);
