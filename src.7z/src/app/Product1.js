"use strict";
var Product1 = (function () {
    function Product1(id, requestorname, lob, source, sourceowner, date, acqusitionstatus, ingestionstatus, propagationstatus) {
        this.id = id;
        this.requestorname = requestorname;
        this.lob = lob;
        this.source = source;
        this.sourceowner = sourceowner;
        this.date = date;
        this.acqusitionstatus = acqusitionstatus;
        this.ingestionstatus = ingestionstatus;
        this.propagationstatus = propagationstatus;
    }
    return Product1;
}());
exports.Product1 = Product1;
//# sourceMappingURL=Product1.js.map