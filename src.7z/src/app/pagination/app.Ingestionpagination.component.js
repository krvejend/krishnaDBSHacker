"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
var user_service_1 = require("../service/user.service");
var Ingestion_1 = require("../Ingestion");
var session_service_1 = require("../service/session.service");
var Pagination1 = (function () {
    function Pagination1(sessionService, userService, router, http) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.router = router;
        this.http = http;
        this.ingestionItems = [];
        this.pages = 4;
        this.pageSize = 5;
        this.pageNumber = 0;
        this.currentIndex = 1;
        this.pageStart = 1;
        this.inputName = '';
        this.showDialog = false;
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.acquisitionId = "";
        this.showDialogApprove = false;
        this.showDialog1 = false;
        this.selectedNodes = [];
        this.nodeSelect = function (event) {
            console.log("selectedFiles", this.selectedFiles);
            console.log(event);
        };
        this.approveArray = [];
        this.btnReqProvision = function () {
            this.router.navigate(['/provision']);
        };
        var item = new Ingestion_1.Ingestion("10031", "ABONO A COMMERCIO", "Securities Lending Admin MS", "Weekly", "Fail", "Fail", "5", "1", "05/05/2017", "Restricted", "1");
        var item1 = new Ingestion_1.Ingestion("10032", "ABONO A COMMERCIO", "BCBS Global Risk Reporting", "Daily", "Fail", "Fail", "5", "1", "05/05/2017", "Highly Restricted", "2");
        var item2 = new Ingestion_1.Ingestion("10033", "ABONO A COMMERCIO", "Premier Risk Profile", "Monthly", "Fail", "Pass", "5", "1", "05/05/2017", "Normal", "1");
        var item3 = new Ingestion_1.Ingestion("10034", "ABONO A COMMERCIO", "Catalyst", "Monthly", "Fail", "Pass", "5", "1", "05/05/2017", "Public", "2");
        var item4 = new Ingestion_1.Ingestion("10035", "ABONO A COMMERCIO", "CBT Risk Consolidation", "Monthly", "Fail", "Pass", "5", "1", "05/05/2017", "Internal", "1");
        this.ingestionItems.push(item);
        this.ingestionItems.push(item1);
        this.ingestionItems.push(item2);
        this.ingestionItems.push(item3);
        this.ingestionItems.push(item4);
        this.filteredItems = this.ingestionItems;
        this.init();
    }
    Pagination1.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.getFilesystem().then(function (files) { return _this.files = files; });
        console.log("Approval is called..");
    };
    Pagination1.prototype.clickItem = function (item) {
        this.showDialog = true;
    };
    Pagination1.prototype.init = function () {
        this.currentIndex = 1;
        this.pageStart = 1;
        this.pages = 4;
        if (this.sessionService.getRole() != "Approver") {
            this.isNotApprover = false;
        }
        else {
            this.isNotApprover = true;
        }
        this.pageNumber = parseInt("" + (this.filteredItems.length / this.pageSize));
        if (this.filteredItems.length % this.pageSize != 0) {
            this.pageNumber++;
        }
        if (this.pageNumber < this.pages) {
            this.pages = this.pageNumber;
        }
        this.refreshItems();
        console.log("this.pageNumber :  " + this.pageNumber);
    };
    Pagination1.prototype.FilterByName = function () {
        var _this = this;
        this.filteredItems = [];
        if (this.inputName != "") {
            this.ingestionItems.forEach(function (element) {
                if (element.applicationId) {
                    if (element.applicationId.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.applicationName) {
                    if (element.applicationName.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.sourcename) {
                    if (element.sourcename.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.frequency) {
                    if (element.frequency.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.currentstatus) {
                    if (element.currentstatus.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.lastrunstatus) {
                    if (element.lastrunstatus.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.tables) {
                    if (element.tables.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.sizeingb) {
                    if (element.sizeingb.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.nextdateforarchival) {
                    if (element.nextdateforarchival.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.dataclassification) {
                    if (element.dataclassification.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.datazone) {
                    if (element.datazone.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
            });
        }
        else {
            this.filteredItems = this.ingestionItems;
        }
        console.log(this.filteredItems);
        this.init();
    };
    Pagination1.prototype.fillArray = function () {
        var obj = new Array();
        for (var index = this.pageStart; index < this.pageStart + this.pages; index++) {
            obj.push(index);
        }
        return obj;
    };
    Pagination1.prototype.refreshItems = function () {
        console.log("test", this.filteredItems);
        this.items = this.filteredItems.slice((this.currentIndex - 1) * this.pageSize, (this.currentIndex) * this.pageSize);
        this.pagesIndex = this.fillArray();
    };
    Pagination1.prototype.prevPage = function () {
        if (this.currentIndex > 1) {
            this.currentIndex--;
        }
        if (this.currentIndex < this.pageStart) {
            this.pageStart = this.currentIndex;
        }
        this.refreshItems();
    };
    Pagination1.prototype.nextPage = function () {
        if (this.currentIndex < this.pageNumber) {
            this.currentIndex++;
        }
        if (this.currentIndex >= (this.pageStart + this.pages)) {
            this.pageStart = this.currentIndex - this.pages + 1;
        }
        this.refreshItems();
    };
    Pagination1.prototype.setPage = function (index) {
        this.currentIndex = index;
        this.refreshItems();
    };
    Pagination1 = __decorate([
        core_1.Component({
            selector: 'Ingestion-pagination',
            providers: [user_service_1.UserService],
            template: "\n   \n  <div class=\"form-group\">\n         <label>Search </label>\n         <input  type=\"text\"  id=\"inputName\" [(ngModel)]=\"inputName\"/>\n         <a (click)=\"FilterByName()\">\n          <span class=\"glyphicon glyphicon-search\"></span>\n        </a>\n   </div>\n\n   <div class=\"row\" style=\"margin-top: 12px;margin-left: -28px;\">\n         <div class=\"col-sm-12\" style=\"margin-top: -18px;margin-bottom: 6px;\">\n            <h2><label class=\"label label-danger\" style=\"font-size:large\">Ingestion Status</label></h2>\n         </div>\n      </div>\n\n   <div class='row'>\n    <div class=\"panel\">\n     <div class='panel-body'>\n         <table class=\"table table-bordered table-condensed table-hover table-striped\">\n\n            <thead>\n               <th> Select </th>\n               <th>Application Id</th>\n               <th>Application Name</th>\n               <th> System Name </th>\n               <th> Frequency </th>\n               <th> Status </th>\n               <th> Last Run Date </th>\n               <th> #tables </th>\n               <th> Size In Gb </th>\n               <th> Next Date For Archival </th>\n               <th> Data Classification </th>\n               <th> Data Zone </th>\n            </thead>\n\n            <tbody>\n\n               <tr *ngFor=\"let item of items\" >\n                  <td><input type=\"radio\"value=\"{{item.applicationId}}\" name=\"radio\"/></td>\n                  <td>{{item.applicationId}}</td>\n                  <td>{{item.applicationName}}</td>\n                  <td>{{item.sourcename}}</td>\n                  <td>{{item.frequency}}</td>\n                  <td>{{item.currentstatus}}</td>\n                  <td>{{item.lastrunstatus}}</td>\n                  <td><a (click)=\"clickItem(item)\">{{item.tables}}</a></td>\n                  <td>{{item.sizeingb}}</td>\n                  <td>{{item.nextdateforarchival}}</td>\n                  <td>{{item.dataclassification}}</td>\n                  <td>{{item.datazone}}</td>\n\n               </tr>\n            </tbody>\n         </table>\n        <div class=\"btn-toolbar \" role=\"toolbar\" style=\"margin: 0;\">\n          <div class=\"btn-group marginleft\">\n               <label style=\"margin-top:10px\">Page {{currentIndex}}/{{pageNumber}}</label>\n            </div>\n            <div class=\"btn-group pull-right \">\n               <ul class=\"pagination\" >\n                  <li [ngClass]=\"{'disabled': (currentIndex == 1 || pageNumber == 0)}\" ><a  (click)=\"prevPage()\">Prev</a></li>\n                     <li *ngFor=\"let page of pagesIndex\"  [ngClass]=\"{'active': (currentIndex == page)}\">\n                        <a (click)=\"setPage(page)\">{{page}}</a>\n                     </li>\n                  <li [ngClass]=\"{'disabled': (currentIndex == pageNumber || pageNumber == 0)}\" ><a   (click)=\"nextPage()\">Next</a></li>\n               </ul>\n            </div>\n         </div>\n      </div>\n   </div>\n\n\n      <div class=\"container\">\n       <div class=\"row\" style=\"margin-top: 2%;margin-bottom: 2%;\">\n         <div class=\"col-sm-12\" style=\"text-align:center;\">\n             <button type=\"button\" class=\"btn-success btn\" (click)=\"btnReqProvision()\">Request For Provision</button>\n\n         </div>\n         </div>\n      </div>\n\n    <app-dialog [(visible)]=\"showDialog\">\n  <div class=\"container\" style=\"background-color:gainsboro;margin-top: 10px;padding-top: 5px;padding-bottom: 5px;border-radius: 5px; overflow: auto; max-height: 350px \">\n    <p-treeTable [value]=\"files\" selectionMode=\"checkbox\" [(selection)]=\"selectedFiles\" [contextMenu]=\"cm\" (onNodeSelect)=\"nodeSelect($event)\">\n      <p-column field=\"name\" header=\"Select the Tables & Columns\"></p-column>\n    </p-treeTable>\n  </div>\n   \n<div class=\"container\">\n       <div class=\"row\" style=\"margin-top: 2%;margin-bottom: 2%;\">\n         <div class=\"col-sm-12\" style=\"text-align:center;\">\n             <button type=\"button\" class=\"btn-success btn\">Archive</button>\n             <button type=\"button\" class=\"btn-success btn\">Delete</button>\n             <button type=\"button\" class=\"btn-success btn\">Start</button>\n             <button type=\"button\" class=\"btn-success btn\">Stop</button>\n         </div>\n         </div>\n      </div>\n\n   <button (click)=\"showDialog = !showDialog\" class=\"btn-success btn\" style=\"float:right\">Close</button>\n    </app-dialog>\n       \n        \n        ",
            styles: ['.pagination { margin: 0px !important; }']
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, router_1.Router, http_1.Http])
    ], Pagination1);
    return Pagination1;
}());
exports.Pagination1 = Pagination1;
//# sourceMappingURL=app.Ingestionpagination.component.js.map