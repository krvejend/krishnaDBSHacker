import { Component, NgModule, OnInit } from '@angular/core';

import { Http, HttpModule, Response } from '@angular/http';
import { Router } from "@angular/router";
import { TreeNode } from 'primeng/primeng';
import { UserService } from "../service/user.service";
import { Ingestion } from "../Ingestion";
import { SessionService } from "../service/session.service";


@Component({
 selector: 'Ingestion-pagination',
 providers:[UserService],
 template: `
   
  <div class="form-group">
         <label>Search </label>
         <input  type="text"  id="inputName" [(ngModel)]="inputName"/>
         <a (click)="FilterByName()">
          <span class="glyphicon glyphicon-search"></span>
        </a>
   </div>

   <div class="row" style="margin-top: 12px;margin-left: -28px;">
         <div class="col-sm-12" style="margin-top: -18px;margin-bottom: 6px;">
            <h2><label class="label label-danger" style="font-size:large">Ingestion Status</label></h2>
         </div>
      </div>

   <div class='row'>
    <div class="panel">
     <div class='panel-body'>
         <table class="table table-bordered table-condensed table-hover table-striped">

            <thead>
               <th> Select </th>
               <th>Application Id</th>
               <th>Application Name</th>
               <th> System Name </th>
               <th> Frequency </th>
               <th> Status </th>
               <th> Last Run Date </th>
               <th> #tables </th>
               <th> Size In Gb </th>
               <th> Next Date For Archival </th>
               <th> Data Classification </th>
               <th> Data Zone </th>
            </thead>

            <tbody>

               <tr *ngFor="let item of items" >
                  <td><input type="radio"value="{{item.applicationId}}" name="radio"/></td>
                  <td>{{item.applicationId}}</td>
                  <td>{{item.applicationName}}</td>
                  <td>{{item.sourcename}}</td>
                  <td>{{item.frequency}}</td>
                  <td>{{item.currentstatus}}</td>
                  <td>{{item.lastrunstatus}}</td>
                  <td><a (click)="clickItem(item)">{{item.tables}}</a></td>
                  <td>{{item.sizeingb}}</td>
                  <td>{{item.nextdateforarchival}}</td>
                  <td>{{item.dataclassification}}</td>
                  <td>{{item.datazone}}</td>

               </tr>
            </tbody>
         </table>
        <div class="btn-toolbar " role="toolbar" style="margin: 0;">
          <div class="btn-group marginleft">
               <label style="margin-top:10px">Page {{currentIndex}}/{{pageNumber}}</label>
            </div>
            <div class="btn-group pull-right ">
               <ul class="pagination" >
                  <li [ngClass]="{'disabled': (currentIndex == 1 || pageNumber == 0)}" ><a  (click)="prevPage()">Prev</a></li>
                     <li *ngFor="let page of pagesIndex"  [ngClass]="{'active': (currentIndex == page)}">
                        <a (click)="setPage(page)">{{page}}</a>
                     </li>
                  <li [ngClass]="{'disabled': (currentIndex == pageNumber || pageNumber == 0)}" ><a   (click)="nextPage()">Next</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>


      <div class="container">
       <div class="row" style="margin-top: 2%;margin-bottom: 2%;">
         <div class="col-sm-12" style="text-align:center;">
             <button type="button" class="btn-success btn" (click)="btnReqProvision()">Request For Provision</button>

         </div>
         </div>
      </div>

    <app-dialog [(visible)]="showDialog">
  <div class="container" style="background-color:gainsboro;margin-top: 10px;padding-top: 5px;padding-bottom: 5px;border-radius: 5px; overflow: auto; max-height: 350px ">
    <p-treeTable [value]="files" selectionMode="checkbox" [(selection)]="selectedFiles" [contextMenu]="cm" (onNodeSelect)="nodeSelect($event)">
      <p-column field="name" header="Select the Tables & Columns"></p-column>
    </p-treeTable>
  </div>
   
<div class="container">
       <div class="row" style="margin-top: 2%;margin-bottom: 2%;">
         <div class="col-sm-12" style="text-align:center;">
             <button type="button" class="btn-success btn">Archive</button>
             <button type="button" class="btn-success btn">Delete</button>
             <button type="button" class="btn-success btn">Start</button>
             <button type="button" class="btn-success btn">Stop</button>
         </div>
         </div>
      </div>

   <button (click)="showDialog = !showDialog" class="btn-success btn" style="float:right">Close</button>
    </app-dialog>
       
        
        `,
        styles: ['.pagination { margin: 0px !important; }']
})
export class Pagination1 implements OnInit {
   
   filteredItems : Ingestion[];
   ingestionItems: Ingestion[] =[];
   pages : number = 4;
  pageSize : number = 5;
   pageNumber : number = 0;
   currentIndex : number = 1;
   items: Ingestion[];
   pagesIndex : Array<number>;
   pageStart : number = 1;
   inputName : string = '';
   showDialog:boolean = false;
  isNotApproved:boolean = false;
  isNotApprover:boolean =false;
  acquisitionId:string = "";
  showDialogApprove:boolean=false;
  showDialog1:boolean = false;
  jira;
  trackdata;
  trackdataDSAP;


   ngOnInit(): void {
     this.userService.getFilesystem().then(files => this.files = files);
    console.log("Approval is called..")

  }

  myVar;

selectedNodes: any[] = [];

selectedFiles: TreeNode[];

nodeSelect= function(event){
  console.log("selectedFiles",this.selectedFiles);
  console.log(event);
}
  files:TreeNode[];

   constructor( public sessionService:SessionService,private userService:UserService,private router: Router,private http:Http){

     var item=new Ingestion("10031","ABONO A COMMERCIO","Securities Lending Admin MS","Weekly","Fail","Fail","5","1","05/05/2017","Restricted","1");
    var item1=new Ingestion("10032","ABONO A COMMERCIO","BCBS Global Risk Reporting","Daily","Fail","Fail","5","1","05/05/2017","Highly Restricted","2");
    var item2=new Ingestion("10033","ABONO A COMMERCIO","Premier Risk Profile","Monthly","Fail","Pass","5","1","05/05/2017","Normal","1");
    var item3=new Ingestion("10034","ABONO A COMMERCIO","Catalyst","Monthly","Fail","Pass","5","1","05/05/2017","Public","2");
    var item4=new Ingestion("10035","ABONO A COMMERCIO","CBT Risk Consolidation","Monthly","Fail","Pass","5","1","05/05/2017","Internal","1");
    
   this.ingestionItems.push(item);
   this.ingestionItems.push(item1);
   this.ingestionItems.push(item2);
   this.ingestionItems.push(item3);
   this.ingestionItems.push(item4);


    this.filteredItems = this.ingestionItems;
   this.init();

   }

 
   clickItem(item){ 
   this.showDialog = true;
  }
 
 approveArray:Ingestion[]=[];
   init(){
         this.currentIndex = 1;
         this.pageStart = 1;
         this.pages = 4;
         if(this.sessionService.getRole()!="Approver"){
           this.isNotApprover = false;
         }else{
           this.isNotApprover = true;
         }

         this.pageNumber = parseInt(""+ (this.filteredItems.length / this.pageSize));
         if(this.filteredItems.length % this.pageSize != 0){
            this.pageNumber ++;
         }

         if(this.pageNumber  < this.pages){

               this.pages =  this.pageNumber;

         }
         this.refreshItems();
         console.log("this.pageNumber :  "+this.pageNumber);
   }



   FilterByName(){

      this.filteredItems = [];

      if(this.inputName != ""){

            this.ingestionItems.forEach(element => {
              if(element.applicationId){
                  if(element.applicationId.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.applicationName){
                   if(element.applicationName.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.sourcename){
                    if(element.sourcename.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                 if(element.frequency){
                  if(element.frequency.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.currentstatus){
                   if(element.currentstatus.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.lastrunstatus){
                    if(element.lastrunstatus.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                 if(element.tables){
                  if(element.tables.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.sizeingb){
                   if(element.sizeingb.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.nextdateforarchival){
                    if(element.nextdateforarchival.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                 if(element.dataclassification){
                  if(element.dataclassification.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.datazone){
                   if(element.datazone.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

            });
      }else{
         this.filteredItems = this.ingestionItems;
      }
      console.log(this.filteredItems);
      this.init();
   }
   fillArray(): any{
      var obj = new Array();
      for(var index = this.pageStart; index< this.pageStart + this.pages; index ++) {

                  obj.push(index);

      }

      return obj;

   }

 refreshItems(){
              console.log("test",this.filteredItems);
               this.items = this.filteredItems.slice((this.currentIndex - 1)*this.pageSize, (this.currentIndex) * this.pageSize);

               this.pagesIndex =  this.fillArray();

   }

   prevPage(){

      if(this.currentIndex>1){
         this.currentIndex --;
      }
      if(this.currentIndex < this.pageStart){

         this.pageStart = this.currentIndex;

      }

      this.refreshItems();

   }

   nextPage(){

      if(this.currentIndex < this.pageNumber){

            this.currentIndex ++;

      }

      if(this.currentIndex >= (this.pageStart + this.pages)){
         this.pageStart = this.currentIndex - this.pages + 1;
      }

      this.refreshItems();
   }
    setPage(index : number){
         this.currentIndex = index;
         this.refreshItems();
    }


   btnReqProvision= function () {
            this.router.navigate(['/provision']);
        }
}
   