"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var router_1 = require("@angular/router");
var Product_1 = require("../Product");
var userTrack_1 = require("../userTrack");
var keyvalue_1 = require("../keyvalue");
var session_service_1 = require("../service/session.service");
var user_service_1 = require("../service/user.service");
var identify_1 = require("../dataacquisition/identify/identify");
var Pagination = (function () {
    function Pagination(sessionService, userService, http, router) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.http = http;
        this.router = router;
        this.pages = 4;
        this.pageSize = 5;
        this.pageNumber = 0;
        this.currentIndex = 1;
        this.pageStart = 1;
        this.inputName = '';
        this.showDialog = false;
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.acquisitionId = "";
        this.showDialogApprove = false;
        this.showDialog1 = false;
        this.app_inst_ids = "10031";
        this.app_inst_names = "ABONO A COMMERCIO MX";
        this.app_inst_short_names = "ABACM";
        this.app_inst_descriptions = "Instance Description";
        this.application_types = "Business";
        this.app_inst_statuss = "Active";
        this.app_inst_strategic_statuss = "Non Strategic";
        this.app_inst_reviewer_emails = "Raul GOMEZ/HBMX/HSBC";
        this.devices = ['Rule1', 'Rule2', 'Rule3'];
        this.userTrack = [];
        this.keyvalues = [];
        this.btnApprove = function () {
            this.router.navigate(['/approval']);
        };
        this.approveArray = [];
        console.log("tttt", this.sessionService.getProductList());
        this.filteredItems = this.sessionService.getProductList();
        this.init();
    }
    ;
    Pagination.prototype.updateChecked = function (option, event) {
        var approve = new identify_1.Identify(option.id, option.requestorname, option.lob, option.source, option.sourceowner, option.date, option.acqusitionstatus, option.ingestionstatus, option.propagationstatus);
        if (event.target.checked) {
            this.approveArray.push(approve);
        }
        else if (!event.target.checked) {
            var indexx = this.approveArray.indexOf(approve);
            this.approveArray.splice(indexx, 1);
        }
        if (this.approveArray.length > 0) {
            this.isNotApproved = true;
        }
        else {
            this.isNotApproved = false;
        }
        console.log("checkbox-------------", this.approveArray);
    };
    Pagination.prototype.onClick = function (row) {
        if (row.acqusitionstatus != "Approved") {
            console.log(row.acqusitionstatus);
            this.acquisitionId = row.id;
        }
        else {
            console.log("false..");
        }
    };
    Pagination.prototype.scoreClass = function (item) {
        console.log("this is called...");
        if (item.acqusitionstatus != "Approved") {
            return "danger";
        }
        else {
            return "success";
        }
    };
    Pagination.prototype.btnClickNxt = function () {
        var _this = this;
        this.userService.postBulkApproval(this.approveArray).subscribe(function (data) {
            console.log("approve request", data);
            _this.http.get('/app/jiraid.json')
                .subscribe(function (res) { return _this.jira = res.json(); });
            _this.showDialogApprove = true;
            _this.isNotApproved = false;
            _this.userService.getTrackRequest(_this.sessionService.getUsername(), "requestorType").subscribe(function (data) {
                var productList = [];
                for (var i in data) {
                    var product = new Product_1.Product(data[i].data_acquisition_request_id, data[i].requested_user, data[i].app_inst_lvl_4_bus_org, data[i].app_inst_name, data[i].app_inst_lvl_4_bus_org_owner, data[i].stamp_created, data[i].status, "-", "-");
                    productList.push(product);
                }
                _this.sessionService.setProductList(productList);
                _this.filteredItems = _this.sessionService.getProductList();
            }, function () { return console.log("acq service called..."); });
        }, function () { return console.log("approve re id service called..."); });
    };
    Pagination.prototype.btnClickNxtSingle = function (status) {
        var _this = this;
        this.userService.postApproval(this.acquisitionId, status).subscribe(function (data) {
            console.log("approve request", data);
            _this.http.get('/app/jiraid.json')
                .subscribe(function (res) { return _this.jira = res.json(); });
            _this.showDialogApprove = true;
            _this.showDialog = false;
            _this.filteredItems = [];
            _this.userService.getTrackRequest(_this.sessionService.getUsername(), "requestorType").subscribe(function (data) {
                var productList = [];
                for (var i in data) {
                    var product = new Product_1.Product(data[i].data_acquisition_request_id, data[i].requested_user, data[i].app_inst_lvl_4_bus_org, data[i].app_inst_name, data[i].app_inst_lvl_4_bus_org_owner, data[i].stamp_created, data[i].status, "-", "-");
                    productList.push(product);
                }
                _this.sessionService.setProductList(productList);
                _this.filteredItems = _this.sessionService.getProductList();
            }, function () { return console.log("acq service called..."); });
        }, function () { return console.log("approve re id service called..."); });
    };
    Pagination.prototype.clickItem = function (item) {
        var _this = this;
        console.log(item.id);
        this.acquisitionId = item.id;
        this.showDialog = true;
        this.http.get('/app/trackdata.json')
            .subscribe(function (res) { return _this.trackdata = res.json(); });
        this.http.get('/app/trackdataDSAP.json')
            .subscribe(function (res) { return _this.trackdataDSAP = res.json(); });
        this.userService.getAppovalRequestData(item.id).subscribe(function (data) {
            _this.userTrack = [];
            _this.keyvalues = [];
            console.log("approvalId Data", data[0].app_inst_id);
            var userT = new userTrack_1.UserTrack(data[0].app_inst_id, data[0].app_inst_name, data[0].app_inst_short_name, data[0].app_inst_description, data[0].application_type, data[0].app_inst_status, data[0].app_inst_strategic_status, data[0].app_inst_reviewer_email, data[0].app_inst_reviewer_name, data[0].app_inst_lvl_4_bus_org, data[0].app_inst_lvl_4_bus_org_owner, data[0].app_inst_lvl_5_bus_org, data[0].app_inst_lvl_4_it_dir, data[0].app_inst_lvl_4_it_dir_owner, data[0].app_inst_lvl_5_it_dir, data[0].app_inst_lvl_5_it_dir_owner, data[0].app_inst_dev_manager_primary, data[0].app_inst_dev_manager_secondary, data[0].application_id, data[0].application_name, data[0].app_it_owner, data[0].app_bus_owner, data[0].app_inst_pri_data_centre, data[0].app_inst_pri_data_centre_type, data[0].app_inst_sec_data_centre, data[0].app_inst_supporting_region, data[0].app_inst_supporting_country, data[0].app_inst_dev_region, data[0].app_inst_dev_country, data[0].data_acquisition_request_id, data[0].request_type, data[0].requested_user, data[0].stamp_created, data[0].status);
            console.log(userT);
            _this.userTrack.push(userT);
            for (var obj in _this.userTrack) {
                if (_this.userTrack.hasOwnProperty(obj)) {
                    for (var prop in _this.userTrack[obj]) {
                        if (_this.userTrack[obj].hasOwnProperty(prop)) {
                            console.log(prop + ':' + _this.userTrack[obj][prop]);
                            var newKeyValue = new keyvalue_1.KeyValue(prop, _this.userTrack[obj][prop]);
                            _this.keyvalues.push(newKeyValue);
                        }
                    }
                }
            }
            console.log("keyvalues", _this.keyvalues);
            _this.userTrack.push(userT);
        }, function () { return console.log("acq id service called..."); });
    };
    Pagination.prototype.init = function () {
        this.currentIndex = 1;
        this.pageStart = 1;
        this.pages = 4;
        if (this.sessionService.getRole() != "Approver") {
            this.isNotApprover = false;
        }
        else {
            this.isNotApprover = true;
        }
        this.pageNumber = parseInt("" + (this.filteredItems.length / this.pageSize));
        if (this.filteredItems.length % this.pageSize != 0) {
            this.pageNumber++;
        }
        if (this.pageNumber < this.pages) {
            this.pages = this.pageNumber;
        }
        this.refreshItems();
        console.log("this.pageNumber :  " + this.pageNumber);
    };
    Pagination.prototype.FilterByName = function () {
        var _this = this;
        this.filteredItems = [];
        if (this.inputName != "") {
            this.sessionService.getProductList().forEach(function (element) {
                if (element.requestorname) {
                    if (element.requestorname.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.lob) {
                    if (element.lob.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.id.toString()) {
                    if (element.id.toString().toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.source) {
                    if (element.source.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.sourceowner) {
                    if (element.sourceowner.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.acqusitionstatus) {
                    if (element.acqusitionstatus.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
                if (element.date) {
                    if (element.date.toUpperCase().indexOf(_this.inputName.toUpperCase()) >= 0) {
                        _this.filteredItems.push(element);
                    }
                }
            });
        }
        else {
            this.filteredItems = this.sessionService.getProductList();
        }
        console.log(this.filteredItems);
        this.init();
    };
    Pagination.prototype.fillArray = function () {
        var obj = new Array();
        for (var index = this.pageStart; index < this.pageStart + this.pages; index++) {
            obj.push(index);
        }
        return obj;
    };
    Pagination.prototype.refreshItems = function () {
        console.log("test", this.filteredItems);
        this.items = this.filteredItems.slice((this.currentIndex - 1) * this.pageSize, (this.currentIndex) * this.pageSize);
        this.pagesIndex = this.fillArray();
    };
    Pagination.prototype.prevPage = function () {
        if (this.currentIndex > 1) {
            this.currentIndex--;
        }
        if (this.currentIndex < this.pageStart) {
            this.pageStart = this.currentIndex;
        }
        this.refreshItems();
    };
    Pagination.prototype.nextPage = function () {
        if (this.currentIndex < this.pageNumber) {
            this.currentIndex++;
        }
        if (this.currentIndex >= (this.pageStart + this.pages)) {
            this.pageStart = this.currentIndex - this.pages + 1;
        }
        this.refreshItems();
    };
    Pagination.prototype.setPage = function (index) {
        this.currentIndex = index;
        this.refreshItems();
    };
    Pagination = __decorate([
        core_1.Component({
            selector: 'my-pagination',
            providers: [user_service_1.UserService],
            template: "\n\n   <div class=\"form-group\">\n         <label>Search </label>\n         <input  type=\"text\"  id=\"inputName\" [(ngModel)]=\"inputName\"/>\n         <a (click)=\"FilterByName()\">\n          <span class=\"glyphicon glyphicon-search\"></span>\n        </a>\n   </div>\n\n   <div class='row'>\n    <div class=\"panel\">\n    <!-- Default panel contents -->\n    <!--<div class='panel-heading'>Product List</div> -->\n    <div class='panel-body'>\n         <table class=\"table table-bordered table-condensed table-hover table-striped\">\n            <thead>\n               <th>Select</th>\n               <th>Data Group</th>\n               <th>Troux ID</th>\n               <th>Application Name</th>\n               <th>System Name</th>\n               <th>Source Owner</th>\n               <th>LOB</th>\n               <th>Region</th>\n               <th>Status</th>\n\n            </thead>\n            <tbody>\n               <tr *ngFor=\"let item of items\" >\n                  <td><input type=\"checkbox\" name=\"options\" value=\"{{item.id}}\" (change)=\"updateChecked(item, $event)\"/></td>\n                  <td>{{item.ingestionstatus}}</td>\n                  <td><a (click)=\"clickItem(item)\">{{item.id}}</a></td>\n                  <td>{{item.source}}</td>\n                  <td>{{item.date}}</td>\n                  <td>{{item.sourceowner}}</td>\n                  <td>{{item.lob}}</td>\n                  <td>{{item.propagationstatus}}</td>\n                  <td>{{item.acqusitionstatus}}</td>\n\n               </tr>\n            </tbody>\n         </table>\n         <div class=\"btn-toolbar \" role=\"toolbar\" style=\"margin: 0;\">\n          <div class=\"btn-group marginleft\">\n               <label style=\"margin-top:10px\">Page {{currentIndex}}/{{pageNumber}}</label>\n            </div>\n            <div class=\"btn-group pull-right \">\n               <ul class=\"pagination\" >\n                  <li [ngClass]=\"{'disabled': (currentIndex == 1 || pageNumber == 0)}\" ><a  (click)=\"prevPage()\">Prev</a></li>\n                     <li *ngFor=\"let page of pagesIndex\"  [ngClass]=\"{'active': (currentIndex == page)}\">\n                        <a (click)=\"setPage(page)\">{{page}}</a>\n                     </li>\n                  <li [ngClass]=\"{'disabled': (currentIndex == pageNumber || pageNumber == 0)}\" ><a   (click)=\"nextPage()\">Next</a></li>\n               </ul>\n            </div>\n         </div>\n      </div>\n   </div>\n\n<div class=\"container\">\n      <div class=\"row\" style=\"margin-top: 2%;margin-bottom: 2%;\">\n        <div class=\"col-sm-12\" style=\"text-align:center;\">\n            <button type=\"submit\" (click)=\"btnApprove();\" class=\"btn-success btn\">Submit</button>\n            <button class=\"btn-success btn\">Save</button>\n        </div>\n        <div class=\"col-sm-12\">\n        </div>\n        </div>\n       </div>\n\n   <app-dialog [(visible)]=\"showDialogApprove\">\n\n        <button (click)=\"showDialogApprove = !showDialogApprove\" class=\"btn-success btn\">Close</button>\n  </app-dialog>\n\n<app-dialog [(visible)]=\"showDialog\">\n\n <form #landingForm=\"ngForm\" (ngSubmit)=\"submitLanding(landingForm)\">\n  <div class=\"container\" [hidden]=\"tabValue==2\">\n    <div class=\"row\" >\n        <div class=\"col-sm-12\" style=\"margin-top: -18px;margin-bottom: 6px;\">\n        <h2><label class=\"label label-danger\" style=\"font-size: large;\">Application Details</label></h2>\n        </div>\n    </div>\n  <!--Tab for Business and Project Details -->\n<!--Tab for Source System Server Name -->\n<div class=\"container\" style=\"padding-bottom: 10px;border-radius: 5px;margin-top: 5px;background-color:gainsboro\">\n<div class=\"row\" style=\"margin-top: 12px;margin-left: -28px;\">\n    <div class=\"col-sm-12\" style=\"margin-top: -18px;margin-bottom: 6px;\">\n    <h2><label class=\"label label-danger\" style=\"font-size:large\">Business Details</label></h2>\n    </div>\n</div>\n<div class=\"row\">\n  <div class=\"red-line\"></div>\n</div>\n  <div class=\"row\">\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_id\">App Id:</label>\n      <input class=\"form-control\" id=\"app_inst_id\" type=\"text\" [(ngModel)]=\"app_inst_ids\" name=\"app_inst_id\" (change)=\"loadIngestion()\" #app_inst_id=\"ngModel\">\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_name\">App Name:</label>\n      <input class=\"form-control\" id=\"app_inst_name\" type=\"text\"  [(ngModel)]=\"app_inst_names\" name=\"app_inst_name\" (change)=\"loadIngestion()\" #app_inst_name=\"ngModel\">\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_short_name\">App Short Name:</label>\n      <input class=\"form-control\" id=\"app_inst_short_name\" type=\"text\" [(ngModel)]=\"app_inst_short_names\" name=\"app_inst_short_name\" (change)=\"loadIngestion()\" #app_inst_short_name=\"ngModel\">\n\n    </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"col-xs-4\">\n      <label for=\"application_type\">App Type:</label>\n      <input class=\"form-control\" id=\"application_type\" type=\"text\" [(ngModel)]=\"application_types\" name=\"application_type\" (change)=\"loadIngestion()\" #application_type=\"ngModel\">\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_status\">App status:</label>\n      <input class=\"form-control\" id=\"app_inst_status\" type=\"text\"  [(ngModel)]=\"app_inst_statuss\" name=\"app_inst_status\" (change)=\"loadIngestion()\" #app_inst_status=\"ngModel\">\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_strategic_status\">App Strategic Status:</label>\n      <input class=\"form-control\" id=\"app_inst_strategic_status\" type=\"text\" [(ngModel)]=\"app_inst_strategic_statuss\" name=\"app_inst_strategic_status\" (change)=\"loadIngestion()\" #app_inst_strategic_status=\"ngModel\">\n    </div>\n  </div>\n\n<div class=\"row\" style=\"margin-top: 12px;margin-left: -28px;\">\n    <div class=\"col-sm-12\" style=\"margin-top: -18px;margin-bottom: 6px;\">\n    <h2><label class=\"label label-danger\" style=\"font-size:large\">Application Owner Details</label></h2>\n    </div>\n</div>\n<div class=\"row\">\n  <div class=\"red-line\"></div>\n</div>\n  <div class=\"row\">\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_reviewer_email\">App Reviewer Email:</label>\n      <input class=\"form-control\" id=\"app_inst_reviewer_email\" type=\"text\" [(ngModel)]=\"app_inst_reviewer_emails\" name=\"app_inst_reviewer_email\" (change)=\"loadIngestion()\" #app_inst_reviewer_email=\"ngModel\">\n\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_reviewer_name\">App Reviewer Name:</label>\n      <input class=\"form-control\" id=\"app_inst_reviewer_name\" type=\"text\"  [(ngModel)]=\"app_inst_reviewer_names\" name=\"app_inst_reviewer_name\" (change)=\"loadIngestion()\" #app_inst_reviewer_name=\"ngModel\">\n    </div>\n    <div class=\"col-xs-4\">\n      <label for=\"app_inst_lvl_5_bus_org\">Level 5 Bus Org:</label>\n      <input class=\"form-control\" id=\"app_inst_lvl_5_bus_org\" type=\"text\" [(ngModel)]=\"app_inst_lvl_5_bus_orgs\" name=\"app_inst_lvl_5_bus_org\" (change)=\"loadIngestion()\" #app_inst_lvl_5_bus_org=\"ngModel\">\n    </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"col-xs-4\">\n      <label for=\"application_id\">Application ID</label>\n      <input class=\"form-control\" id=\"application_id\" type=\"text\" [(ngModel)]=\"application_ids\" name=\"application_id\" required (change)=\"loadIngestion()\" #application_id=\"ngModel\">\n    </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"col-xs-4\">\n      <label for=\"application_name\">Application Name</label>\n      <input class=\"form-control\" id=\"application_name\" type=\"text\" [(ngModel)]=\"application_names\" name=\"application_name\" (change)=\"loadIngestion()\"  #application_name=\"ngModel\">\n    </div>\n   <div class=\"col-xs-4\">\n      <label for=\"app_it_owner\">IT Owner:</label>\n      <input class=\"form-control\" id=\"app_it_owner\" type=\"text\"  [(ngModel)]=\"app_it_owners\" name=\"app_it_owner\" (change)=\"loadIngestion()\"  #app_it_owner=\"ngModel\">\n\n    </div>\n   <div class=\"col-xs-4\">\n      <label for=\"app_bus_owner\">BU Owner:</label>\n      <input class=\"form-control\" id=\"app_bus_owner\" type=\"text\" [(ngModel)]=\"app_bus_owners\" name=\"app_bus_owner\"  (change)=\"loadIngestion()\" #app_bus_owner=\"ngModel\">\n\n    </div>\n  </div>\n</div>\n  </div>\n </form>\n\n </app-dialog>\n\n\n   <app-dialog [(visible)]=\"showDialog1\">\n   <datatable [dataset]=userTrack>\n               <column [value]=\"'app_inst_id'\" [header]=\"'App Id:'\"></column>\n               <column [value]=\"'app_inst_name'\" [header]=\"'App Name:'\"></column>\n               <column [value]=\"'app_inst_short_name'\" [header]=\"'App Short Name'\"></column>\n                <column [value]=\"'app_inst_description'\" [header]=\"'App Description'\"></column>\n               <column [value]=\"'application_type'\" [header]=\"'Application Type'\"></column>\n               <column [value]=\"'app_inst_status'\" [header]=\"'App Status'\"></column>\n               <column [value]=\"'app_inst_strategic_status'\" [header]=\"'strategic status'\"></column>\n               <column [value]=\"'app_inst_reviewer_email'\" [header]=\"'Reviewer Email'\"></column>\n               <column [value]=\"'app_inst_reviewer_name'\" [header]=\"'Reviewer Name'\"></column>\n               <column [value]=\"'app_inst_lvl_4_bus_org'\" [header]=\"'LOB'\"></column>\n               <column [value]=\"'app_inst_lvl_4_bus_org_owner'\" [header]=\"'Business Owner'\"></column>\n               <column [value]=\"'app_inst_lvl_5_bus_org'\" [header]=\"'Business Org'\"></column>\n               <column [value]=\"'app_inst_lvl_4_it_dir'\" [header]=\"'It Dir'\"></column>\n               <column [value]=\"'app_inst_lvl_4_it_dir_owner'\" [header]=\"'It Dir Owner'\"></column>\n               <column [value]=\"'app_inst_lvl_5_it_dir'\" [header]=\"'It Dir Level 5'\"></column>\n               <column [value]=\"'app_inst_lvl_5_it_dir_owner'\" [header]=\"'It Dir Owner Lvl 5'\"></column>\n               <column [value]=\"'app_inst_dev_manager_primary'\" [header]=\"'Dev Mgr Primary'\"></column>\n               <column [value]=\"'app_inst_dev_manager_secondary'\" [header]=\"'Dev Mgr Secondary'\"></column>\n               <column [value]=\"'application_id'\" [header]=\"'Application ID'\"></column>\n               <column [value]=\"'application_name'\" [header]=\"'Application Name'\"></column>\n               <column [value]=\"'app_it_owner'\" [header]=\"'IT Owner'\"></column>\n               <column [value]=\"'app_bus_owner'\" [header]=\"'Bus Owner'\"></column>\n               <column [value]=\"'app_inst_pri_data_centre'\" [header]=\"'Pri Data Center'\"></column>\n               <column [value]=\"'app_inst_pri_data_centre_type'\" [header]=\"'Data Center Type'\"></column>\n               <column [value]=\"'app_inst_sec_data_centre'\" [header]=\"'Sec Data Center'\"></column>\n               <column [value]=\"'app_inst_supporting_region'\" [header]=\"'Supporting Region'\"></column>\n               <column [value]=\"'app_inst_supporting_country'\" [header]=\"'Supporting Country'\"></column>\n               <column [value]=\"'app_inst_dev_region'\" [header]=\"'Dev Region'\"></column>\n               <column [value]=\"'app_inst_dev_country'\" [header]=\"'Dev Country'\"></column>\n               <column [value]=\"'data_acquisition_request_id'\" [header]=\"'Request ID'\"></column>\n               <column [value]=\"'request_type'\" [header]=\"'Request Type'\"></column>\n               <column [value]=\"'requested_user'\" [header]=\"'Requested User'\"></column>\n               <column [value]=\"'stamp_created'\" [header]=\"'Stamp Created'\"></column>\n               <column [value]=\"'status'\" [header]=\"'Status'\"></column>\n          </datatable>\n   <button (click)=\"showDialog = !showDialog\" class=\"btn\">Close</button>\n    </app-dialog>\n\n   <div class=\"col-sm-4\" *ngIf=\"isNotApproved\">\n       <button type=\"button\" class=\"btn-success btn\" ng-disabled=\"!radiobutton\" (click)=\"btnClickNxt();\"><i class=\"fa fa-plus\"></i>Approve</button>\n   </div>\n\n  ",
            styles: ['.pagination { margin: 0px !important; }']
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, http_1.Http, router_1.Router])
    ], Pagination);
    return Pagination;
}());
exports.Pagination = Pagination;
//# sourceMappingURL=app.paginationComponent.js.map