import { Component, NgModule } from '@angular/core';
import { UserService } from "../service/user.service";
import { Provision } from "../Provision";
import { UserTrack } from "../userTrack";
import { KeyValue } from "../keyvalue";
import { SessionService } from "../service/session.service";
import { Http } from "@angular/http";
import { Product } from "../Product";
import { Router } from "@angular/router";
import { Availability } from "../dataprovision/availability/availability";


@Component({
 selector: 'provision-pagination',
 providers:[UserService],
 template: `

   <div class="form-group">
         <label>Search </label>
         <input  type="text"  id="inputName" [(ngModel)]="inputName"/>
         <a (click)="FilterByName()">
          <span class="glyphicon glyphicon-search"></span>
        </a>
   </div>
   
   <div class='row'>
    <div class="panel">
    <div class='panel-body'>
         <table class="table table-bordered table-condensed table-hover table-striped">
            <thead>
            <th> Select </th>
            <th>Troux Id</th>
            <th>Application Name</th>
            <th> System Name </th>
            </thead>
            <tbody>
               <tr *ngFor="let item of items" >
                  <td><input type="checkbox" name="options" value="{{item.id}}" (change)="updateChecked(item, $event)" /></td>
                  <td>{{item.id}}</td>
                  <td>{{item.applicationName}}</td>
                  <td>{{item.systemName}}</td>
               </tr>
            </tbody>
         </table>
         <div class="btn-toolbar " role="toolbar" style="margin: 0;">
          <div class="btn-group marginleft">
               <label style="margin-top:10px">Page {{currentIndex}}/{{pageNumber}}</label>
            </div>
            <div class="btn-group pull-right ">
               <ul class="pagination" >
                  <li [ngClass]="{'disabled': (currentIndex == 1 || pageNumber == 0)}" ><a  (click)="prevPage()">Prev</a></li>
                     <li *ngFor="let page of pagesIndex"  [ngClass]="{'active': (currentIndex == page)}">
                        <a (click)="setPage(page)">{{page}}</a>
                     </li>
                  <li [ngClass]="{'disabled': (currentIndex == pageNumber || pageNumber == 0)}" ><a   (click)="nextPage()">Next</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>

<div class="container">
      <div class="row" style="margin-top: 2%;margin-bottom: 2%;">
        <div class="col-sm-12" style="text-align:center;">
            <button type="submit" (click)="btnApprove();" class="btn-success btn">Submit</button>
            <button class="btn-success btn">Save</button>
        </div>
        <div class="col-sm-12">
        </div>
        </div>
       </div>

  `,
 styles: ['.pagination { margin: 0px !important; }']
})
export class ProvisionPagination {

   filteredItems : Provision[];
   pages : number = 4;
  pageSize : number = 5;
   pageNumber : number = 0;
   currentIndex : number = 1;
   items: Provision[];
   pagesIndex : Array<number>;
   pageStart : number = 1;
   inputName : string = '';
   showDialog:boolean = false;
  isNotApproved:boolean = false;
  isNotApprover:boolean =false;
  acquisitionId:string = "";
  showDialogApprove:boolean=false;
  showDialog1:boolean = false;
  jira;
  trackdata;
  trackdataDSAP;
  provisionItems:Provision[] = [];
      app_inst_ids = "10031";
      app_inst_names="ABONO A COMMERCIO MX"
      app_inst_short_names="ABACM";
      app_inst_descriptions="Instance Description";
      application_types="Business";
      app_inst_statuss="Active";
      app_inst_strategic_statuss="Non Strategic";
      app_inst_reviewer_emails="Raul GOMEZ/HBMX/HSBC";



  devices=['Rule1','Rule2','Rule3']

  userTrack:UserTrack[]=[];

  keyvalues:KeyValue[]=[];

   constructor( public sessionService:SessionService,private userService:UserService,private http:Http,private router: Router,){

        var item1 = new Provision("10031","ABONO A COMMERCIO","Securities Lending Admin MS");
        var item2 = new Provision("10032","ABONO A COMMERCIO","BCBS Global Risk Reporting");

        this.provisionItems.push(item1);
        this.provisionItems.push(item2);

         this.filteredItems = this.provisionItems;

       this.init();
   };

  btnApprove= function () {
            this.router.navigate(['/pprepare']);
        }
   approveArray:Availability[]=[];

    updateChecked(option, event) {
   var approve = new Availability(option.id,option.applicationName,option.systemName);
    if(event.target.checked){
      this.approveArray.push(approve);
    }
    else if (!event.target.checked){
      let indexx = this.approveArray.indexOf(approve);
      this.approveArray.splice(indexx,1);
    }
    if(this.approveArray.length>0){
      this.isNotApproved = true;
    }else{
    this.isNotApproved = false;
    }
   console.log("checkbox-------------",this.approveArray);
  }

    onClick(row){

    if(row.acqusitionstatus != "Approved"){
    console.log(row.acqusitionstatus);
        this.acquisitionId = row.id;
      }else{
      console.log("false..");
      }
    }

    scoreClass(item){
      console.log("this is called...");
        if(item.acqusitionstatus != "Approved"){
            return "danger";
          }else{
            return "success"
          }
    }

    btnClickNxt(){
    this.userService.postBulkApproval(this.approveArray).subscribe(
      data=>{
      console.log("approve request",data);
      this.http.get('/app/jiraid.json')
                 .subscribe(res => this.jira = res.json());
      this.showDialogApprove=true;
      this.isNotApproved = false;
      this.userService.getTrackRequest(this.sessionService.getUsername(),"requestorType").subscribe(
        data=>{
           var productList: Product[] =[];
        for (let i in data) {
          var product:Product=new Product(data[i].data_acquisition_request_id,data[i].requested_user, data[i].app_inst_lvl_4_bus_org,data[i].app_inst_name,data[i].app_inst_lvl_4_bus_org_owner,data[i].stamp_created,data[i].status,"-","-");
          productList.push(product);
          }
          this.sessionService.setProductList(productList);
          this.filteredItems = this.provisionItems;
        },
       ()=>console.log("acq service called...")
      );
      },
     ()=>console.log("approve re id service called...")
    );
    }

    btnClickNxtSingle(status){
    this.userService.postApproval(this.acquisitionId,status).subscribe(
      data=>{
      console.log("approve request",data);
      this.http.get('/app/jiraid.json')
                 .subscribe(res => this.jira = res.json());
      this.showDialogApprove=true;
      this.showDialog=false;
      this.filteredItems = [];
      this.userService.getTrackRequest(this.sessionService.getUsername(),"requestorType").subscribe(
        data=>{
           var productList: Product[] =[];
        for (let i in data) {
          var product:Product=new Product(data[i].data_acquisition_request_id,data[i].requested_user, data[i].app_inst_lvl_4_bus_org,data[i].app_inst_name,data[i].app_inst_lvl_4_bus_org_owner,data[i].stamp_created,data[i].status,"-","-");
          productList.push(product);
          }
          this.sessionService.setProductList(productList);
          this.filteredItems = this.provisionItems;
        },
       ()=>console.log("acq service called...")
      );

      },
     ()=>console.log("approve re id service called...")
    );
    }


   clickItem(item){
   console.log(item.id);
   this.acquisitionId = item.id;
   this.showDialog = true;
   this.http.get('/app/trackdata.json')
              .subscribe(res => this.trackdata = res.json());

  this.http.get('/app/trackdataDSAP.json')
                         .subscribe(res => this.trackdataDSAP = res.json());

   this.userService.getAppovalRequestData(item.id).subscribe(
     data=>{
     this.userTrack = [];

     this.keyvalues = [];
     console.log("approvalId Data",data[0].app_inst_id);
     var userT = new UserTrack(data[0].app_inst_id,
     data[0].app_inst_name,data[0].app_inst_short_name,data[0].app_inst_description,data[0].application_type,data[0].app_inst_status,data[0].app_inst_strategic_status,data[0].app_inst_reviewer_email,
     data[0].app_inst_reviewer_name,data[0].app_inst_lvl_4_bus_org,data[0].app_inst_lvl_4_bus_org_owner,data[0].app_inst_lvl_5_bus_org,data[0].app_inst_lvl_4_it_dir,data[0].app_inst_lvl_4_it_dir_owner,data[0].app_inst_lvl_5_it_dir,
     data[0].app_inst_lvl_5_it_dir_owner,data[0].app_inst_dev_manager_primary,data[0].app_inst_dev_manager_secondary,data[0].application_id,data[0].application_name,data[0].app_it_owner,data[0].app_bus_owner,data[0].app_inst_pri_data_centre,
     data[0].app_inst_pri_data_centre_type,data[0].app_inst_sec_data_centre,data[0].app_inst_supporting_region,data[0].app_inst_supporting_country,data[0].app_inst_dev_region,data[0].app_inst_dev_country,data[0].data_acquisition_request_id,
     data[0].request_type,data[0].requested_user,data[0].stamp_created,data[0].status);
     console.log(userT);
     this.userTrack.push(userT);

     for(var obj in this.userTrack){
      if(this.userTrack.hasOwnProperty(obj)){
        for(var prop in this.userTrack[obj]){
          if(this.userTrack[obj].hasOwnProperty(prop)){
            console.log(prop + ':' + this.userTrack[obj][prop]);
            var newKeyValue = new KeyValue(prop,this.userTrack[obj][prop]);
            this.keyvalues.push(newKeyValue);
          }
        }
      }
    }

    console.log("keyvalues",this.keyvalues);


     this.userTrack.push(userT);

     },
    ()=>console.log("acq id service called...")
   );


   }
   init(){
         this.currentIndex = 1;
         this.pageStart = 1;
         this.pages = 4;
         if(this.sessionService.getRole()!="Approver"){
           this.isNotApprover = false;
         }else{
           this.isNotApprover = true;
         }

         this.pageNumber = parseInt(""+ (this.filteredItems.length / this.pageSize));
         if(this.filteredItems.length % this.pageSize != 0){
            this.pageNumber ++;
         }

         if(this.pageNumber  < this.pages){

               this.pages =  this.pageNumber;

         }
         this.refreshItems();
         console.log("this.pageNumber :  "+this.pageNumber);
   }



   FilterByName(){

      this.filteredItems = [];

      if(this.inputName != ""){

           this. provisionItems.forEach(element => {
              if(element.id){
                  if(element.id.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.applicationName){
                   if(element.applicationName.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.systemName){
                    if(element.systemName.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

            });
      }else{
         this.filteredItems = this.provisionItems;
      }
      console.log(this.filteredItems);
      this.init();
   }
   fillArray(): any{
      var obj = new Array();
      for(var index = this.pageStart; index< this.pageStart + this.pages; index ++) {

                  obj.push(index);

      }

      return obj;

   }

 refreshItems(){
              console.log("test",this.filteredItems);
               this.items = this.filteredItems.slice((this.currentIndex - 1)*this.pageSize, (this.currentIndex) * this.pageSize);

               this.pagesIndex =  this.fillArray();

   }

   prevPage(){

      if(this.currentIndex>1){
         this.currentIndex --;
      }
      if(this.currentIndex < this.pageStart){

         this.pageStart = this.currentIndex;

      }

      this.refreshItems();

   }

   nextPage(){

      if(this.currentIndex < this.pageNumber){

            this.currentIndex ++;

      }

      if(this.currentIndex >= (this.pageStart + this.pages)){
         this.pageStart = this.currentIndex - this.pages + 1;
      }

      this.refreshItems();
   }
    setPage(index : number){
         this.currentIndex = index;
         this.refreshItems();
    }

 }
