import { Component, NgModule } from '@angular/core';
import { Http, HttpModule, Response } from '@angular/http';
import { Router } from "@angular/router";
import { Product } from "../Product";
import { UserTrack } from "../userTrack";
import { KeyValue } from "../keyvalue";
import { SessionService } from "../service/session.service";
import { UserService } from "../service/user.service";
import { Identify } from "../dataacquisition/identify/identify";


@Component({
 selector: 'my-pagination',
 providers:[UserService],
 template: `

   <div class="form-group">
         <label>Search </label>
         <input  type="text"  id="inputName" [(ngModel)]="inputName"/>
         <a (click)="FilterByName()">
          <span class="glyphicon glyphicon-search"></span>
        </a>
   </div>

   <div class='row'>
    <div class="panel">
    <!-- Default panel contents -->
    <!--<div class='panel-heading'>Product List</div> -->
    <div class='panel-body'>
         <table class="table table-bordered table-condensed table-hover table-striped">
            <thead>
               <th>Select</th>
               <th>Data Group</th>
               <th>Troux ID</th>
               <th>Application Name</th>
               <th>System Name</th>
               <th>Source Owner</th>
               <th>LOB</th>
               <th>Region</th>
               <th>Status</th>

            </thead>
            <tbody>
               <tr *ngFor="let item of items" >
                  <td><input type="checkbox" name="options" value="{{item.id}}" (change)="updateChecked(item, $event)"/></td>
                  <td>{{item.ingestionstatus}}</td>
                  <td><a (click)="clickItem(item)">{{item.id}}</a></td>
                  <td>{{item.source}}</td>
                  <td>{{item.date}}</td>
                  <td>{{item.sourceowner}}</td>
                  <td>{{item.lob}}</td>
                  <td>{{item.propagationstatus}}</td>
                  <td>{{item.acqusitionstatus}}</td>

               </tr>
            </tbody>
         </table>
         <div class="btn-toolbar " role="toolbar" style="margin: 0;">
          <div class="btn-group marginleft">
               <label style="margin-top:10px">Page {{currentIndex}}/{{pageNumber}}</label>
            </div>
            <div class="btn-group pull-right ">
               <ul class="pagination" >
                  <li [ngClass]="{'disabled': (currentIndex == 1 || pageNumber == 0)}" ><a  (click)="prevPage()">Prev</a></li>
                     <li *ngFor="let page of pagesIndex"  [ngClass]="{'active': (currentIndex == page)}">
                        <a (click)="setPage(page)">{{page}}</a>
                     </li>
                  <li [ngClass]="{'disabled': (currentIndex == pageNumber || pageNumber == 0)}" ><a   (click)="nextPage()">Next</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>

<div class="container">
      <div class="row" style="margin-top: 2%;margin-bottom: 2%;">
        <div class="col-sm-12" style="text-align:center;">
            <button type="submit" (click)="btnApprove();" class="btn-success btn">Submit</button>
            <button class="btn-success btn">Save</button>
        </div>
        <div class="col-sm-12">
        </div>
        </div>
       </div>

   <app-dialog [(visible)]="showDialogApprove">

        <button (click)="showDialogApprove = !showDialogApprove" class="btn-success btn">Close</button>
  </app-dialog>

<app-dialog [(visible)]="showDialog">

 <form #landingForm="ngForm" (ngSubmit)="submitLanding(landingForm)">
  <div class="container" [hidden]="tabValue==2">
    <div class="row" >
        <div class="col-sm-12" style="margin-top: -18px;margin-bottom: 6px;">
        <h2><label class="label label-danger" style="font-size: large;">Application Details</label></h2>
        </div>
    </div>
  <!--Tab for Business and Project Details -->
<!--Tab for Source System Server Name -->
<div class="container" style="padding-bottom: 10px;border-radius: 5px;margin-top: 5px;background-color:gainsboro">
<div class="row" style="margin-top: 12px;margin-left: -28px;">
    <div class="col-sm-12" style="margin-top: -18px;margin-bottom: 6px;">
    <h2><label class="label label-danger" style="font-size:large">Business Details</label></h2>
    </div>
</div>
<div class="row">
  <div class="red-line"></div>
</div>
  <div class="row">
    <div class="col-xs-4">
      <label for="app_inst_id">App Id:</label>
      <input class="form-control" id="app_inst_id" type="text" [(ngModel)]="app_inst_ids" name="app_inst_id" (change)="loadIngestion()" #app_inst_id="ngModel">
    </div>
    <div class="col-xs-4">
      <label for="app_inst_name">App Name:</label>
      <input class="form-control" id="app_inst_name" type="text"  [(ngModel)]="app_inst_names" name="app_inst_name" (change)="loadIngestion()" #app_inst_name="ngModel">
    </div>
    <div class="col-xs-4">
      <label for="app_inst_short_name">App Short Name:</label>
      <input class="form-control" id="app_inst_short_name" type="text" [(ngModel)]="app_inst_short_names" name="app_inst_short_name" (change)="loadIngestion()" #app_inst_short_name="ngModel">

    </div>
  </div>

  <div class="row">
    <div class="col-xs-4">
      <label for="application_type">App Type:</label>
      <input class="form-control" id="application_type" type="text" [(ngModel)]="application_types" name="application_type" (change)="loadIngestion()" #application_type="ngModel">
    </div>
    <div class="col-xs-4">
      <label for="app_inst_status">App status:</label>
      <input class="form-control" id="app_inst_status" type="text"  [(ngModel)]="app_inst_statuss" name="app_inst_status" (change)="loadIngestion()" #app_inst_status="ngModel">
    </div>
    <div class="col-xs-4">
      <label for="app_inst_strategic_status">App Strategic Status:</label>
      <input class="form-control" id="app_inst_strategic_status" type="text" [(ngModel)]="app_inst_strategic_statuss" name="app_inst_strategic_status" (change)="loadIngestion()" #app_inst_strategic_status="ngModel">
    </div>
  </div>

<div class="row" style="margin-top: 12px;margin-left: -28px;">
    <div class="col-sm-12" style="margin-top: -18px;margin-bottom: 6px;">
    <h2><label class="label label-danger" style="font-size:large">Application Owner Details</label></h2>
    </div>
</div>
<div class="row">
  <div class="red-line"></div>
</div>
  <div class="row">
    <div class="col-xs-4">
      <label for="app_inst_reviewer_email">App Reviewer Email:</label>
      <input class="form-control" id="app_inst_reviewer_email" type="text" [(ngModel)]="app_inst_reviewer_emails" name="app_inst_reviewer_email" (change)="loadIngestion()" #app_inst_reviewer_email="ngModel">

    </div>
    <div class="col-xs-4">
      <label for="app_inst_reviewer_name">App Reviewer Name:</label>
      <input class="form-control" id="app_inst_reviewer_name" type="text"  [(ngModel)]="app_inst_reviewer_names" name="app_inst_reviewer_name" (change)="loadIngestion()" #app_inst_reviewer_name="ngModel">
    </div>
    <div class="col-xs-4">
      <label for="app_inst_lvl_5_bus_org">Level 5 Bus Org:</label>
      <input class="form-control" id="app_inst_lvl_5_bus_org" type="text" [(ngModel)]="app_inst_lvl_5_bus_orgs" name="app_inst_lvl_5_bus_org" (change)="loadIngestion()" #app_inst_lvl_5_bus_org="ngModel">
    </div>
  </div>

  <div class="row">
    <div class="col-xs-4">
      <label for="application_id">Application ID</label>
      <input class="form-control" id="application_id" type="text" [(ngModel)]="application_ids" name="application_id" required (change)="loadIngestion()" #application_id="ngModel">
    </div>
  </div>

  <div class="row">
    <div class="col-xs-4">
      <label for="application_name">Application Name</label>
      <input class="form-control" id="application_name" type="text" [(ngModel)]="application_names" name="application_name" (change)="loadIngestion()"  #application_name="ngModel">
    </div>
   <div class="col-xs-4">
      <label for="app_it_owner">IT Owner:</label>
      <input class="form-control" id="app_it_owner" type="text"  [(ngModel)]="app_it_owners" name="app_it_owner" (change)="loadIngestion()"  #app_it_owner="ngModel">

    </div>
   <div class="col-xs-4">
      <label for="app_bus_owner">BU Owner:</label>
      <input class="form-control" id="app_bus_owner" type="text" [(ngModel)]="app_bus_owners" name="app_bus_owner"  (change)="loadIngestion()" #app_bus_owner="ngModel">

    </div>
  </div>
</div>
  </div>
 </form>

 </app-dialog>


   <app-dialog [(visible)]="showDialog1">
   <datatable [dataset]=userTrack>
               <column [value]="'app_inst_id'" [header]="'App Id:'"></column>
               <column [value]="'app_inst_name'" [header]="'App Name:'"></column>
               <column [value]="'app_inst_short_name'" [header]="'App Short Name'"></column>
                <column [value]="'app_inst_description'" [header]="'App Description'"></column>
               <column [value]="'application_type'" [header]="'Application Type'"></column>
               <column [value]="'app_inst_status'" [header]="'App Status'"></column>
               <column [value]="'app_inst_strategic_status'" [header]="'strategic status'"></column>
               <column [value]="'app_inst_reviewer_email'" [header]="'Reviewer Email'"></column>
               <column [value]="'app_inst_reviewer_name'" [header]="'Reviewer Name'"></column>
               <column [value]="'app_inst_lvl_4_bus_org'" [header]="'LOB'"></column>
               <column [value]="'app_inst_lvl_4_bus_org_owner'" [header]="'Business Owner'"></column>
               <column [value]="'app_inst_lvl_5_bus_org'" [header]="'Business Org'"></column>
               <column [value]="'app_inst_lvl_4_it_dir'" [header]="'It Dir'"></column>
               <column [value]="'app_inst_lvl_4_it_dir_owner'" [header]="'It Dir Owner'"></column>
               <column [value]="'app_inst_lvl_5_it_dir'" [header]="'It Dir Level 5'"></column>
               <column [value]="'app_inst_lvl_5_it_dir_owner'" [header]="'It Dir Owner Lvl 5'"></column>
               <column [value]="'app_inst_dev_manager_primary'" [header]="'Dev Mgr Primary'"></column>
               <column [value]="'app_inst_dev_manager_secondary'" [header]="'Dev Mgr Secondary'"></column>
               <column [value]="'application_id'" [header]="'Application ID'"></column>
               <column [value]="'application_name'" [header]="'Application Name'"></column>
               <column [value]="'app_it_owner'" [header]="'IT Owner'"></column>
               <column [value]="'app_bus_owner'" [header]="'Bus Owner'"></column>
               <column [value]="'app_inst_pri_data_centre'" [header]="'Pri Data Center'"></column>
               <column [value]="'app_inst_pri_data_centre_type'" [header]="'Data Center Type'"></column>
               <column [value]="'app_inst_sec_data_centre'" [header]="'Sec Data Center'"></column>
               <column [value]="'app_inst_supporting_region'" [header]="'Supporting Region'"></column>
               <column [value]="'app_inst_supporting_country'" [header]="'Supporting Country'"></column>
               <column [value]="'app_inst_dev_region'" [header]="'Dev Region'"></column>
               <column [value]="'app_inst_dev_country'" [header]="'Dev Country'"></column>
               <column [value]="'data_acquisition_request_id'" [header]="'Request ID'"></column>
               <column [value]="'request_type'" [header]="'Request Type'"></column>
               <column [value]="'requested_user'" [header]="'Requested User'"></column>
               <column [value]="'stamp_created'" [header]="'Stamp Created'"></column>
               <column [value]="'status'" [header]="'Status'"></column>
          </datatable>
   <button (click)="showDialog = !showDialog" class="btn">Close</button>
    </app-dialog>

   <div class="col-sm-4" *ngIf="isNotApproved">
       <button type="button" class="btn-success btn" ng-disabled="!radiobutton" (click)="btnClickNxt();"><i class="fa fa-plus"></i>Approve</button>
   </div>

  `,
 styles: ['.pagination { margin: 0px !important; }']
})
export class Pagination {

   filteredItems : Product[];
   pages : number = 4;
  pageSize : number = 5;
   pageNumber : number = 0;
   currentIndex : number = 1;
   items: Product[];
   pagesIndex : Array<number>;
   pageStart : number = 1;
   inputName : string = '';
   showDialog:boolean = false;
  isNotApproved:boolean = false;
  isNotApprover:boolean =false;
  acquisitionId:string = "";
  showDialogApprove:boolean=false;
  showDialog1:boolean = false;
  jira;
  trackdata;
  trackdataDSAP;

      app_inst_ids = "10031";
      app_inst_names="ABONO A COMMERCIO MX"
      app_inst_short_names="ABACM";
      app_inst_descriptions="Instance Description";
      application_types="Business";
      app_inst_statuss="Active";
      app_inst_strategic_statuss="Non Strategic";
      app_inst_reviewer_emails="Raul GOMEZ/HBMX/HSBC";



  devices=['Rule1','Rule2','Rule3']

  userTrack:UserTrack[]=[];

  keyvalues:KeyValue[]=[];

   constructor( public sessionService:SessionService,private userService:UserService,private http:Http,private router: Router,){
        console.log("tttt", this.sessionService.getProductList());
         this.filteredItems = this.sessionService.getProductList();

       this.init();
   };

  btnApprove= function () {
            this.router.navigate(['/approval']);
        }

        
   approveArray:Identify[]=[];
   
  
   updateChecked(option, event) {
   var approve = new Identify(option.id,option.requestorname,option.lob,option.source,option.sourceowner,option.date,option.acqusitionstatus,option.ingestionstatus,option.propagationstatus);
    if(event.target.checked){
      this.approveArray.push(approve);
    }
    else if (!event.target.checked){
      let indexx = this.approveArray.indexOf(approve);
      this.approveArray.splice(indexx,1);
    }
    if(this.approveArray.length>0){
      this.isNotApproved = true;
    }else{
    this.isNotApproved = false;
    }
   console.log("checkbox-------------",this.approveArray);
  }

    onClick(row){

    if(row.acqusitionstatus != "Approved"){
    console.log(row.acqusitionstatus);
        this.acquisitionId = row.id;
      }else{
      console.log("false..");
      }
    }

    scoreClass(item){
      console.log("this is called...");
        if(item.acqusitionstatus != "Approved"){
            return "danger";
          }else{
            return "success"
          }
    }

    btnClickNxt(){
    this.userService.postBulkApproval(this.approveArray).subscribe(
      data=>{
      console.log("approve request",data);
      this.http.get('/app/jiraid.json')
                 .subscribe(res => this.jira = res.json());
      this.showDialogApprove=true;
      this.isNotApproved = false;
      this.userService.getTrackRequest(this.sessionService.getUsername(),"requestorType").subscribe(
        data=>{
           var productList: Product[] =[];
        for (let i in data) {
          var product:Product=new Product(data[i].data_acquisition_request_id,data[i].requested_user, data[i].app_inst_lvl_4_bus_org,data[i].app_inst_name,data[i].app_inst_lvl_4_bus_org_owner,data[i].stamp_created,data[i].status,"-","-");
          productList.push(product);
          }
          this.sessionService.setProductList(productList);
          this.filteredItems = this.sessionService.getProductList();
        },
       ()=>console.log("acq service called...")
      );
      },
     ()=>console.log("approve re id service called...")
    );
    }

    btnClickNxtSingle(status){
    this.userService.postApproval(this.acquisitionId,status).subscribe(
      data=>{
      console.log("approve request",data);
      this.http.get('/app/jiraid.json')
                 .subscribe(res => this.jira = res.json());
      this.showDialogApprove=true;
      this.showDialog=false;
      this.filteredItems = [];
      this.userService.getTrackRequest(this.sessionService.getUsername(),"requestorType").subscribe(
        data=>{
           var productList: Product[] =[];
        for (let i in data) {
          var product:Product=new Product(data[i].data_acquisition_request_id,data[i].requested_user, data[i].app_inst_lvl_4_bus_org,data[i].app_inst_name,data[i].app_inst_lvl_4_bus_org_owner,data[i].stamp_created,data[i].status,"-","-");
          productList.push(product);
          }
          this.sessionService.setProductList(productList);
          this.filteredItems = this.sessionService.getProductList();
        },
       ()=>console.log("acq service called...")
      );

      },
     ()=>console.log("approve re id service called...")
    );
    }


   clickItem(item){
   console.log(item.id);
   this.acquisitionId = item.id;
   this.showDialog = true;
   this.http.get('/app/trackdata.json')
              .subscribe(res => this.trackdata = res.json());

  this.http.get('/app/trackdataDSAP.json')
                         .subscribe(res => this.trackdataDSAP = res.json());

   this.userService.getAppovalRequestData(item.id).subscribe(
     data=>{
     this.userTrack = [];

     this.keyvalues = [];
     console.log("approvalId Data",data[0].app_inst_id);
     var userT = new UserTrack(data[0].app_inst_id,
     data[0].app_inst_name,data[0].app_inst_short_name,data[0].app_inst_description,data[0].application_type,data[0].app_inst_status,data[0].app_inst_strategic_status,data[0].app_inst_reviewer_email,
     data[0].app_inst_reviewer_name,data[0].app_inst_lvl_4_bus_org,data[0].app_inst_lvl_4_bus_org_owner,data[0].app_inst_lvl_5_bus_org,data[0].app_inst_lvl_4_it_dir,data[0].app_inst_lvl_4_it_dir_owner,data[0].app_inst_lvl_5_it_dir,
     data[0].app_inst_lvl_5_it_dir_owner,data[0].app_inst_dev_manager_primary,data[0].app_inst_dev_manager_secondary,data[0].application_id,data[0].application_name,data[0].app_it_owner,data[0].app_bus_owner,data[0].app_inst_pri_data_centre,
     data[0].app_inst_pri_data_centre_type,data[0].app_inst_sec_data_centre,data[0].app_inst_supporting_region,data[0].app_inst_supporting_country,data[0].app_inst_dev_region,data[0].app_inst_dev_country,data[0].data_acquisition_request_id,
     data[0].request_type,data[0].requested_user,data[0].stamp_created,data[0].status);
     console.log(userT);
     this.userTrack.push(userT);

     for(var obj in this.userTrack){
      if(this.userTrack.hasOwnProperty(obj)){
        for(var prop in this.userTrack[obj]){
          if(this.userTrack[obj].hasOwnProperty(prop)){
            console.log(prop + ':' + this.userTrack[obj][prop]);
            var newKeyValue = new KeyValue(prop,this.userTrack[obj][prop]);
            this.keyvalues.push(newKeyValue);
          }
        }
      }
    }

    console.log("keyvalues",this.keyvalues);


     this.userTrack.push(userT);

     },
    ()=>console.log("acq id service called...")
   );


   }
   init(){
         this.currentIndex = 1;
         this.pageStart = 1;
         this.pages = 4;
         if(this.sessionService.getRole()!="Approver"){
           this.isNotApprover = false;
         }else{
           this.isNotApprover = true;
         }

         this.pageNumber = parseInt(""+ (this.filteredItems.length / this.pageSize));
         if(this.filteredItems.length % this.pageSize != 0){
            this.pageNumber ++;
         }

         if(this.pageNumber  < this.pages){

               this.pages =  this.pageNumber;

         }
         this.refreshItems();
         console.log("this.pageNumber :  "+this.pageNumber);
   }



   FilterByName(){

      this.filteredItems = [];

      if(this.inputName != ""){

            this.sessionService.getProductList().forEach(element => {
              if(element.requestorname){
                  if(element.requestorname.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                    this.filteredItems.push(element);
                 }
               }

               if(element.lob){
                   if(element.lob.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                     this.filteredItems.push(element);
                  }
                }

                if(element.id.toString()){
                    if(element.id.toString().toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                if(element.source){
                    if(element.source.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                      this.filteredItems.push(element);
                   }
                 }

                 if(element.sourceowner){
                     if(element.sourceowner.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                       this.filteredItems.push(element);
                    }
                  }

                  if(element.acqusitionstatus){
                      if(element.acqusitionstatus.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                        this.filteredItems.push(element);
                     }
                   }

                   if(element.date){
                       if(element.date.toUpperCase().indexOf(this.inputName.toUpperCase())>=0){
                         this.filteredItems.push(element);
                      }
                    }
            });
      }else{
         this.filteredItems = this.sessionService.getProductList();
      }
      console.log(this.filteredItems);
      this.init();
   }
   fillArray(): any{
      var obj = new Array();
      for(var index = this.pageStart; index< this.pageStart + this.pages; index ++) {

                  obj.push(index);

      }

      return obj;

   }

 refreshItems(){
              console.log("test",this.filteredItems);
               this.items = this.filteredItems.slice((this.currentIndex - 1)*this.pageSize, (this.currentIndex) * this.pageSize);

               this.pagesIndex =  this.fillArray();

   }

   prevPage(){

      if(this.currentIndex>1){
         this.currentIndex --;
      }
      if(this.currentIndex < this.pageStart){

         this.pageStart = this.currentIndex;

      }

      this.refreshItems();

   }

   nextPage(){

      if(this.currentIndex < this.pageNumber){

            this.currentIndex ++;

      }

      if(this.currentIndex >= (this.pageStart + this.pages)){
         this.pageStart = this.currentIndex - this.pages + 1;
      }

      this.refreshItems();
   }
    setPage(index : number){
         this.currentIndex = index;
         this.refreshItems();
    }

 }
