import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { TreeNode } from 'primeng/primeng';
import { UserService } from "../../service/user.service";
import { SessionService } from "../../service/session.service";

@Component({
 templateUrl: './app/dataprovision/prepare/prepare.html',
  providers:[UserService],
})
export class PrepareComponent implements OnInit {

constructor(public sessionService:SessionService, private userService:UserService,private router: Router) { }
        ngOnInit(): void {
        this.userService.getFilesystem().then(files => this.files = files);
        this.userService.getTrackRequest("requestorName","requestorType").subscribe(
          data=>{
          console.log("test",data);
          this.myVar = true;
          },
         ()=>console.log("acq service called...")
        );

        }
myVar;

selectedNodes: any[] = [];

selectedFiles: TreeNode[];

nodeSelect= function(event){
  console.log("selectedFiles",this.selectedFiles);
  console.log(event);
}
  files:TreeNode[];

    projectid="10031";
    sourcename="ABONO A COMMERCIO ";
    dataasset="securities Lending Data Asset";

        fillColumns = function(){
        this.columns = ['app_inst_id VARCHAR2(20)','app_bus_owners VARCHAR2(20)','application_names VARCHAR2(20)','app_inst_supporting_countrys INT'];
        this.selectedColumns=this.columns[0];
        }
        btnClick= function () {
            this.router.navigate(['/enrich']);
        }
         btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }

        btnInitiate= function () {
             this.router.navigate(['/initiate']);
         }

}
