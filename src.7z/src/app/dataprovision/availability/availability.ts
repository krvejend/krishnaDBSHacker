export class Availability {
   constructor(
    public id: number,
    public applicationName : string,
     public systemName : string
   
   ){

   }
}