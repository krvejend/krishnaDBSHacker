import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Form, FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { User } from "../../user";
import { UserService } from "../../service/user.service";
import { SessionService } from "../../service/session.service";
@Component({
  templateUrl: './app/dataprovision/initiate/initiate.html',
   providers:[UserService],
  })
export class InitiateComponent  {
 ingestion = false;
    showDialog:boolean = false;
     ngOnInit(): void {


    }
afterFilter:Boolean = false;
    usecases = [{name:'ABONO A COMMERCIO'},{name:'Automated Clearing Settlement System - ACSS - CA'},{name:'HUB Import / Export System - Canada'},{name:'HUB Sales Solutions - Canada'},
  {name:'BT Dealerboards CA'},{name:'Broker Websites CA'},{name:'Clearing and Depository Services'},{name:'Computer Assisted Collection System HBCA'},{name:'HUB Front End 2 Canada ClientConnect'}];
    selectedUC = "";

    clusters = [{name:'Mexico'},{name:'LA'},{name: 'London'}];
    selectedCluster = "";

    tables = [{name:'RBWM'},{name:'CMB'},{name:'GPB'},{name:'GBM'}];
    selectedTable = "";

    columns = [{name:'Transaction and Payments Details'},{name:'Customer Account'},{name:'Trade'},{name:'Contract Financial Value'},{name:'Correspondant Bank Details'},{name:
  'Credit Contract Details'},{name:'Customer Transaction'},{name:'Financial Instrument'},{name:'Product Contract Details'},{name:'Trade Account'},{name:'Customer Communications'},{name:
'Customer Contact Details'},{name:'Customer Identification Details'},{name:'Contract Limit'},{name:'Investment Portfolio Details'},{name:'Connected Parties Identification Details'}];


    selectedColumn = "";

    datagroups=[];
    selectedDataApp="";



userData:User;
projectname = "BCBS";
projectid="10031";
sourcename="ABONO A COMMERCIO";
dataasset="Securities Lending Data asset";



projects = ['IFRS9','G9', 'MRFD'];
selectedProject = "";

systemOwners = ['Ian Oneill', 'Pooja Singh/Chetan Pulate','Nilesh Shrimant'];
selectedOwner = "";

fileTypes = ['Oracle', 'Flat File', 'MainFrame']
selectedfileTpe = this.fileTypes[0];

withHeader = ['Yes','No'];
selectedHeader = this.withHeader[0];

selectedTrailer = this.withHeader[0];
dataTypes = ['INT','STRING','TIMESTAMP','DATE','BIGINT','DOUBLE','FLOAT','DECIMAL(n,n)','CHAR(n)','VARCHAR(n)','BOOLEAN']
selectedDataType = "";








 constructor(private router: Router ,public sessionService:SessionService, private userService:UserService) { }
 btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }

           btnAcqusition= function () {
            this.router.navigate(['/landing']);
        }

        btnIngestion= function () {
            this.router.navigate(['/ingestion']);
        }

         btnProvision= function () {
            this.router.navigate(['/provision']);
        }
        btnConfirm= function () {
           this.router.navigate(['/confirmprovision']);
       }
}
