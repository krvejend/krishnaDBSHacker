"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require("../../service/user.service");
var session_service_1 = require("../../service/session.service");
var InitiateComponent = (function () {
    function InitiateComponent(router, sessionService, userService) {
        this.router = router;
        this.sessionService = sessionService;
        this.userService = userService;
        this.ingestion = false;
        this.showDialog = false;
        this.afterFilter = false;
        this.usecases = [{ name: 'ABONO A COMMERCIO' }, { name: 'Automated Clearing Settlement System - ACSS - CA' }, { name: 'HUB Import / Export System - Canada' }, { name: 'HUB Sales Solutions - Canada' },
            { name: 'BT Dealerboards CA' }, { name: 'Broker Websites CA' }, { name: 'Clearing and Depository Services' }, { name: 'Computer Assisted Collection System HBCA' }, { name: 'HUB Front End 2 Canada ClientConnect' }];
        this.selectedUC = "";
        this.clusters = [{ name: 'Mexico' }, { name: 'LA' }, { name: 'London' }];
        this.selectedCluster = "";
        this.tables = [{ name: 'RBWM' }, { name: 'CMB' }, { name: 'GPB' }, { name: 'GBM' }];
        this.selectedTable = "";
        this.columns = [{ name: 'Transaction and Payments Details' }, { name: 'Customer Account' }, { name: 'Trade' }, { name: 'Contract Financial Value' }, { name: 'Correspondant Bank Details' }, { name: 'Credit Contract Details' }, { name: 'Customer Transaction' }, { name: 'Financial Instrument' }, { name: 'Product Contract Details' }, { name: 'Trade Account' }, { name: 'Customer Communications' }, { name: 'Customer Contact Details' }, { name: 'Customer Identification Details' }, { name: 'Contract Limit' }, { name: 'Investment Portfolio Details' }, { name: 'Connected Parties Identification Details' }];
        this.selectedColumn = "";
        this.datagroups = [];
        this.selectedDataApp = "";
        this.projectname = "BCBS";
        this.projectid = "10031";
        this.sourcename = "ABONO A COMMERCIO";
        this.dataasset = "Securities Lending Data asset";
        this.projects = ['IFRS9', 'G9', 'MRFD'];
        this.selectedProject = "";
        this.systemOwners = ['Ian Oneill', 'Pooja Singh/Chetan Pulate', 'Nilesh Shrimant'];
        this.selectedOwner = "";
        this.fileTypes = ['Oracle', 'Flat File', 'MainFrame'];
        this.selectedfileTpe = this.fileTypes[0];
        this.withHeader = ['Yes', 'No'];
        this.selectedHeader = this.withHeader[0];
        this.selectedTrailer = this.withHeader[0];
        this.dataTypes = ['INT', 'STRING', 'TIMESTAMP', 'DATE', 'BIGINT', 'DOUBLE', 'FLOAT', 'DECIMAL(n,n)', 'CHAR(n)', 'VARCHAR(n)', 'BOOLEAN'];
        this.selectedDataType = "";
        this.btnClickLogoff = function () {
            this.router.navigate(['/login']);
        };
        this.btnAcqusition = function () {
            this.router.navigate(['/landing']);
        };
        this.btnIngestion = function () {
            this.router.navigate(['/ingestion']);
        };
        this.btnProvision = function () {
            this.router.navigate(['/provision']);
        };
        this.btnConfirm = function () {
            this.router.navigate(['/confirmprovision']);
        };
    }
    InitiateComponent.prototype.ngOnInit = function () {
    };
    InitiateComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataprovision/initiate/initiate.html',
            providers: [user_service_1.UserService],
        }), 
        __metadata('design:paramtypes', [router_1.Router, session_service_1.SessionService, user_service_1.UserService])
    ], InitiateComponent);
    return InitiateComponent;
}());
exports.InitiateComponent = InitiateComponent;
//# sourceMappingURL=initiate.component.js.map