"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var user_service_1 = require("../../service/user.service");
var Product_1 = require("../../Product");
var session_service_1 = require("../../service/session.service");
var DataProvisionConfirmComponent = (function () {
    function DataProvisionConfirmComponent(router, sessionService, userService) {
        this.router = router;
        this.sessionService = sessionService;
        this.userService = userService;
        this.ingestion = false;
        this.showDialog = false;
        this.afterFilter = false;
        this.usecases = [{ name: 'ABONO A COMMERCIO' }, { name: 'Automated Clearing Settlement System - ACSS - CA' }, { name: 'HUB Import / Export System - Canada' }, { name: 'HUB Sales Solutions - Canada' },
            { name: 'BT Dealerboards CA' }, { name: 'Broker Websites CA' }, { name: 'Clearing and Depository Services' }, { name: 'Computer Assisted Collection System HBCA' }, { name: 'HUB Front End 2 Canada ClientConnect' }];
        this.selectedUC = "";
        this.clusters = [{ name: 'Mexico' }, { name: 'LA' }, { name: 'London' }];
        this.selectedCluster = "";
        this.tables = [{ name: 'RBWM' }, { name: 'CMB' }, { name: 'GPB' }, { name: 'GBM' }];
        this.selectedTable = "";
        this.columns = [{ name: 'Transaction and Payments Details' }, { name: 'Customer Account' }, { name: 'Trade' }, { name: 'Contract Financial Value' }, { name: 'Correspondant Bank Details' }, { name: 'Credit Contract Details' }, { name: 'Customer Transaction' }, { name: 'Financial Instrument' }, { name: 'Product Contract Details' }, { name: 'Trade Account' }, { name: 'Customer Communications' }, { name: 'Customer Contact Details' }, { name: 'Customer Identification Details' }, { name: 'Contract Limit' }, { name: 'Investment Portfolio Details' }, { name: 'Connected Parties Identification Details' }];
        this.selectedColumn = "";
        this.datagroups = [];
        this.selectedDataApp = "";
        this.projectname = "BCBS";
        this.applicationname = "ABONO A COMMERCIO";
        this.sourcename = "Securities Lending Admin MS";
        this.myVar = false;
        this.ipAddrt = "";
        this.ssl = "";
        this.sssn = "";
        this.sourceSysName = "";
        this.ipAddress = "";
        this.sourceSysLocation = "";
        this.dcan = "";
        this.targetId = "";
        this.dataRead = "";
        this.foi = "";
        this.stagCluster = "";
        this.dirLanPath = "";
        this.transMech = "";
        this.jdbcString = "";
        this.dataIP = "";
        this.dataPort = "";
        this.dataSchema = "";
        this.dataCenter = "";
        this.san = "";
        this.fileNames = "";
        this.fieldName = "";
        this.startPosition = "";
        this.endPosition = "";
        this.cdNode = "";
        this.serverName = "";
        this.ipAddr = "";
        this.portNumber = "";
        this.tabValue = 1;
        this.lobs = [];
        this.selectedLob = "";
        this.showDialogApprove = false;
        this.search = function () {
            this.afterFilter = true;
        };
        this.projects = ['IFRS9', 'G9', 'MRFD'];
        this.selectedProject = "";
        this.systemOwners = ['Ian Oneill', 'Pooja Singh/Chetan Pulate', 'Nilesh Shrimant'];
        this.selectedOwner = "";
        this.fileTypes = ['Oracle', 'Flat File', 'MainFrame'];
        this.selectedfileTpe = this.fileTypes[0];
        this.withHeader = ['Yes', 'No'];
        this.selectedHeader = this.withHeader[0];
        this.selectedTrailer = this.withHeader[0];
        this.dataTypes = ['INT', 'STRING', 'TIMESTAMP', 'DATE', 'BIGINT', 'DOUBLE', 'FLOAT', 'DECIMAL(n,n)', 'CHAR(n)', 'VARCHAR(n)', 'BOOLEAN'];
        this.selectedDataType = "";
        this.btnClickLogoff = function () {
            this.router.navigate(['/login']);
        };
        this.btnAcqusition = function () {
            this.router.navigate(['/landing']);
        };
        this.btnIngestion = function () {
            this.router.navigate(['/ingestion']);
        };
        this.btnProvision = function () {
            this.router.navigate(['/provision']);
        };
        this.btnNotify = function () {
            this.router.navigate(['/notify']);
        };
    }
    DataProvisionConfirmComponent.prototype.ngOnInit = function () {
        //   this.loadIngestion();
        //   if(this.sessionService.getRole()!="Approver"){
        //     this.isNotApprover = true;
        //   }else{
        //     this.isNotApprover = false;
        //   }
        // this.userData = this.sessionService.getUser();
        //   console.log("userData",JSON.stringify(this.userData));
        //   this.lobs[0] = [];
        //   this.app_inst_ids = "10031";
        //   this.app_inst_names="ABONO A COMMERCIO MX"
        // this.app_inst_short_names="ABACM";
        // this.app_inst_descriptions="Instance Description";
        // this.application_types="";
        // this.app_inst_statuss="";
        // this.app_inst_strategic_statuss="";
        // this.app_inst_reviewer_emails="";
        // this.app_inst_reviewer_names="";
        // this.app_inst_lvl_4_bus_orgs="";
        // this.app_inst_lvl_4_bus_org_owners="";
        // this.app_inst_lvl_5_bus_orgs="";
        // this.app_inst_lvl_4_it_dirs="";
        // this.app_inst_lvl_4_it_dir_owners="";
        // this.app_inst_lvl_5_it_dirs="";
        // this.app_inst_lvl_5_it_dir_owners="";
        // this.app_inst_dev_manager_primarys="";
        // this.app_inst_dev_manager_secondarys="";
        // this.application_ids="";
        // this.application_names="";
        // this.app_it_owners="";
        // this.app_bus_owners="";
        // this.app_inst_pri_data_centres="";
        // this.app_inst_pri_data_centre_types="";
        // this.app_inst_sec_data_centres="";
        // this.app_inst_supporting_regions="";
        // this.app_inst_supporting_countrys="";
        // this.app_inst_dev_regions="";
        // this.app_inst_dev_countrys="";
        // this.status_s = "Open";
        // this.requested_user_s="";
        // this.request_type_s="Acquisition";
    };
    DataProvisionConfirmComponent.prototype.loadIngestion = function () {
        console.log("ssl" + this.ssl);
        if (this.selectedLob != '' && this.selectedProject != ''
            && this.selectedOwner != '' && this.sourceSysLocation != ""
            && this.sourceSysName != "" && this.ipAddress != "") {
            this.ingestion = true;
        }
        else {
            this.ingestion = false;
        }
    };
    DataProvisionConfirmComponent.prototype.callfromChild = function () {
        console.log('this is called...');
    };
    DataProvisionConfirmComponent.prototype.tab = function (tabVal) {
        this.tabValue = tabVal;
    };
    DataProvisionConfirmComponent.prototype.submitLanding = function (form) {
        var _this = this;
        console.log(JSON.stringify(form.value));
        var dataAcq = JSON.stringify(form.value);
        this.userService.postAcquisition(dataAcq).subscribe(function (data) {
            console.log("test", data);
            _this.myVar = true;
            _this.showDialogApprove = true;
            _this.userService.getTrackRequest(_this.sessionService.getUsername(), "requestorType").subscribe(function (data) {
                var productList = [];
                for (var i in data) {
                    var product = new Product_1.Product(data[i].data_acquisition_request_id, data[i].requested_user, data[i].app_inst_lvl_4_bus_org, data[i].app_inst_name, data[i].app_inst_lvl_4_bus_org_owner, data[i].stamp_created, data[i].status, "-", "-");
                    productList.push(product);
                }
                _this.sessionService.setProductList(productList);
            }, function () { return console.log("acq service called..."); });
        }, function () { return console.log("acq service called..."); });
    };
    DataProvisionConfirmComponent.prototype.lobChange = function () {
        var lobValue = this.selectedLob;
        var lobLocal = this.lobs;
        for (var i = 0, len = lobLocal.length; i < len; i++) {
            if (lobValue == lobLocal[i]) {
                this.selectedProject = this.projects[i];
            }
        }
    };
    DataProvisionConfirmComponent.prototype.projectChange = function () {
        var project = this.selectedProject;
        var projectLocal = this.projects;
        for (var i = 0, len = projectLocal.length; i < len; i++) {
            if (project == projectLocal[i]) {
                this.selectedLob = this.lobs[i];
            }
        }
    };
    DataProvisionConfirmComponent.prototype.lob = function () {
        console.log('this is called..');
        this.datagroups = [{ name: 'Finance Data App' }, { name: 'Risk Data App' }];
    };
    DataProvisionConfirmComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataprovision/confirm/dataprovisionconfirm.html',
            providers: [user_service_1.UserService],
        }), 
        __metadata('design:paramtypes', [router_1.Router, session_service_1.SessionService, user_service_1.UserService])
    ], DataProvisionConfirmComponent);
    return DataProvisionConfirmComponent;
}());
exports.DataProvisionConfirmComponent = DataProvisionConfirmComponent;
//# sourceMappingURL=dataprovisionconfirm.component.js.map