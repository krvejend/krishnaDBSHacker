"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require("@angular/router");
var SourceComponent = (function () {
    function SourceComponent(router) {
        this.router = router;
        this.projectnames = "Risk Data Capture";
        this.descriptions = "Identify Risk through Availal";
        this.purposes = "Risk Identification";
        this.clarityCodes = "10054111";
        this.keyContacts = "Ruwan Perera, Steven Morton";
        this.estimatedHours = "100";
        this.data = [];
        this.hash = {};
        this.selectedNodes = [];
        this.submitDefine = function (form) {
            console.log("JSON VALUE.......", JSON.stringify(form.value));
            this.router.navigate(['/prepare']);
        };
        this.usecases = [{ name: 'ABONO A COMMERCIO' }, { name: 'Automated Clearing Settlement System - ACSS - CA' }, { name: 'HUB Import / Export System - Canada' }, { name: 'HUB Sales Solutions - Canada' },
            { name: 'BT Dealerboards CA' }, { name: 'Broker Websites CA' }, { name: 'Clearing and Depository Services' }, { name: 'Computer Assisted Collection System HBCA' }, { name: 'HUB Front End 2 Canada ClientConnect' }];
        this.selectedUC = "";
        this.fileTypes = ['Oracle', 'Flat File', 'MainFrame'];
        this.selectedfileTpe = this.fileTypes[0];
        this.duplicate = false;
        this.fileTypes1 = ['Oracle', 'Flat File', 'MainFrame'];
        this.selectedfileTpe1 = this.fileTypes[0];
        this.types = [{ name: "test", value: "test" }, { name: "test1", value: "test2" }];
        this.withHeader = ['Yes', 'No'];
        this.dataTypes = ['INT', 'STRING', 'TIMESTAMP', 'DATE', 'BIGINT', 'DOUBLE', 'FLOAT', 'DECIMAL', 'CHAR', 'VARCHAR', 'BOOLEAN'];
        this.selectedHeader = this.withHeader[0];
        this.selectedTrailer = this.withHeader[0];
        this.jdbcStrings = "jdbc:oracle:thin:@localhost:1521:oracle_schema";
        this.dataIPs = "localhost";
        this.dataPorts = "1521";
        this.dataSchemas = "DaaS_Schema";
        this.dataCenters = "Mexico";
        this.san = "";
        this.fileNames = "";
        this.fieldName = "";
        this.startPosition = "";
        this.endPosition = "";
        this.cdNode = "";
        this.serverName = "";
        this.ipAddrs = "10.8.0.183";
        this.portNumbers = "1521";
        this.db_version = "11.2";
        this.db_home = "Opt/Oraapp/Client/12.1.0.2_x64_DBAcc1028";
        this.db_name = "UHGL";
        this.db_nodes = "localhost";
        this.tns_Admin = "/abnitio/storage/vm/aspbcba/Tns_Admin";
        this.user = "RESA_SAU_ASPBCBS239";
        this.password = "XXXXXXXXXX";
        this.encrypted_password = "XXXXXXXXXX";
        this.case = "lower";
        this.generate_dml_with_nulls = "true";
        this.field_type_prefereence = "delimited";
        this.old_style_empty_string_null = "false";
        this.fully_aualify_dml = "false";
        this.dml_with_maximum_lenght = "true";
        this.preserve_sql_whitespace = "true";
        this.interface = "default";
        this.maximum_data_size = "100000000";
        this.treat_blanks_as_null = "true";
        this.direct_parallel = "true";
        this.addSource = function () {
            this.duplicate = true;
        };
        this.removeSource = function () {
            this.duplicate = false;
        };
        this.data =
            [
                {
                    "label": "Documents",
                    "children": [{
                            "label": "Work",
                            "children": [{ "label": "Expenses.doc", "children": [] }, { "label": "Resume.doc", "children": [] }]
                        },
                        {
                            "selected": false,
                            "label": "Home",
                            "children": [{ "label": "Invoices.txt", "children": [] }]
                        }]
                },
                {
                    "label": "Pictures",
                    "children": [
                        { "label": "barcelona.jpg", "children": [] },
                        { "label": "logo.jpg", "children": [] },
                        { "label": "primeui.png", "children": [] }]
                },
                {
                    "label": "Movies",
                    "children": [{
                            "label": "Al Pacino",
                            "children": [{ "label": "Scarface", "data": "Scarface Movie", "children": [] }, { "label": "Serpico", "data": "Serpico Movie", "children": [] }]
                        },
                        {
                            "label": "Robert De Niro",
                            "children": [{ "label": "Goodfellas", "children": [] }, { "label": "Untouchables", "children": [] }]
                        }]
                }
            ];
        this.hash = this.buildDataHierarchy(this.data);
    }
    SourceComponent.prototype.ngOnInit = function () { };
    SourceComponent.prototype.buildDataHierarchy = function (data) {
        var id = 1;
        var hash = {};
        var setNodeID = function (node, parentId) {
            hash[id] = node;
            node['selected'] = false;
            node['nodeId'] = id;
            node['parentNodeId'] = parentId;
            if (node.children.length) {
                var parentId_1 = id;
                node.children.forEach(function (node) {
                    id++;
                    setNodeID(node, parentId_1);
                });
            }
            id++;
        };
        data.forEach(function (node) {
            setNodeID(node, 0);
        });
        return hash;
    };
    SourceComponent.prototype.nodeSelected = function (toggleNode) {
        var _this = this;
        // select / unselect all children (recursive)
        var toggleChildren = function (node) {
            node.children.forEach(function (child) {
                child.selected = node.selected;
                if (child.children.length) {
                    toggleChildren(child);
                }
            });
        };
        toggleChildren(toggleNode);
        //update parent if needed (recursive)
        var updateParent = function (node) {
            if (node.parentNodeId != 0) {
                var parentNode = _this.hash[node.parentNodeId];
                var siblings = parentNode.children;
                parentNode.partialSelection = false;
                var equalSiblings_1 = true;
                siblings.forEach(function (sibling) {
                    if (sibling.selected !== node.selected) {
                        equalSiblings_1 = false;
                    }
                });
                if (equalSiblings_1) {
                    parentNode.selected = node.selected;
                    if (parentNode.parentNodeId != 0) {
                        updateParent(parentNode);
                    }
                }
                else {
                    parentNode.partialSelection = true;
                }
            }
        };
        updateParent(toggleNode);
        this.updateSelected();
    };
    SourceComponent.prototype.updateSelected = function () {
        this.selectedNodes = [];
        for (var node in this.hash) {
            if (this.hash[node].selected) {
                var currentNode = this.hash[node];
                var nodeLabel = currentNode['label'];
                while (currentNode.parentNodeId !== 0) {
                    currentNode = this.hash[currentNode.parentNodeId];
                    nodeLabel = currentNode['label'] + ' > ' + nodeLabel;
                }
                this.selectedNodes.push(nodeLabel);
            }
        }
    };
    SourceComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataacquisition/define/define.html',
        }), 
        __metadata('design:paramtypes', [router_1.Router])
    ], SourceComponent);
    return SourceComponent;
}());
exports.SourceComponent = SourceComponent;
//# sourceMappingURL=define.component.js.map