"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require("@angular/router");
var session_service_1 = require("../../service/session.service");
var govern_1 = require("./govern");
var FilterSourceComponent = (function () {
    function FilterSourceComponent(sessionService, router) {
        this.sessionService = sessionService;
        this.router = router;
        this.projectnames = "Risk Data Capture";
        this.descriptions = "Identify Risk through Availal";
        this.purposes = "Risk Identification";
        this.clarityCodes = "10054111";
        this.keyContacts = "Ruwan Perera, Steven Morton";
        this.estimatedHours = "100";
        this.showDialogApprove = false;
        this.isSelected = false;
        this.approveArray = [];
        this.isNotApproved = false;
        this.isNotApprover = false;
        this.btnApprove = function () {
            this.showDialogApprove = true;
        };
        this.popupApprove = function () {
            this.router.navigate(['/define']);
        };
    }
    FilterSourceComponent.prototype.setFilter = function () {
        this.sizes = [
            { 'ChooseTables': 'Customer Master' },
            { 'ChooseTables': 'Address' },
            { 'ChooseTables': 'Email' },
            { 'ChooseTables': 'Passport' },
        ];
    };
    FilterSourceComponent.prototype.ngOnInit = function () {
        console.log("Approval is called..");
        var item = new govern_1.Govern(10031, "Customer Account", "ABONO A COMMERCIO", "David A GRIMME", "RBWM", "Define", "Mexico");
        var item1 = new govern_1.Govern(10032, "Customer Account", "ABONO A COMMERCIO", "David A GRIMME", "RBWM", "Define", "Mexico");
        var productList = [];
        productList.push(item);
        productList.push(item1);
        this.items = productList;
    };
    FilterSourceComponent.prototype.updateChecked = function (option, event) {
        var approve = new govern_1.Govern(option.id, option.datagroup, option.applicationname, option.sourceowner, option.lob, option.status, option.region);
        if (event.target.checked) {
            this.approveArray.push(approve);
        }
        else if (!event.target.checked) {
            var indexx = this.approveArray.indexOf(approve);
            this.approveArray.splice(indexx, 1);
        }
        if (this.approveArray.length > 0) {
            this.isNotApproved = true;
        }
        else {
            this.isNotApproved = false;
        }
        console.log("checkbox-------------", this.approveArray);
    };
    FilterSourceComponent = __decorate([
        core_1.Component({
            templateUrl: '../app/dataacquisition/govern/govern.html',
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, router_1.Router])
    ], FilterSourceComponent);
    return FilterSourceComponent;
}());
exports.FilterSourceComponent = FilterSourceComponent;
//# sourceMappingURL=govern.component.js.map