import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { Product } from "../../Product";
import { SessionService } from "../../service/session.service";
import { Govern } from "./govern";

@Component({
  templateUrl: '../app/dataacquisition/govern/govern.html',
})
export class FilterSourceComponent implements OnInit  {
  projectnames="Risk Data Capture";
  descriptions="Identify Risk through Availal";
  purposes="Risk Identification";
  clarityCodes="10054111";
  keyContacts="Ruwan Perera, Steven Morton";
  estimatedHours="100";
  
  showDialogApprove:boolean = false;
   isSelected = false;
   sizes: any;
    setFilter() {
    this.sizes = [
        {'ChooseTables': 'Customer Master'},
        {'ChooseTables': 'Address'},
        {'ChooseTables': 'Email'},
        {'ChooseTables': 'Passport'},
    ]
}

ngOnInit(): void {

console.log("Approval is called..");
 var item=new Govern(10031,"Customer Account","ABONO A COMMERCIO","David A GRIMME","RBWM","Define","Mexico");
 var item1=new Govern(10032,"Customer Account","ABONO A COMMERCIO","David A GRIMME","RBWM","Define","Mexico");
 var productList: Govern[] =[];
 productList.push(item);
 productList.push(item1);

 this.items = productList;
}

constructor( public sessionService:SessionService,private router: Router){}

items: Govern[];

    approveArray:Govern[]=[]; 
    isNotApproved:boolean = false;
    isNotApprover:boolean =false;

    updateChecked(option, event) {
   var approve = new Govern(option.id,option.datagroup,option.applicationname,option.sourceowner,option.lob,option.status,option.region);
    if(event.target.checked){
      this.approveArray.push(approve);
    }
    else if (!event.target.checked){
      let indexx = this.approveArray.indexOf(approve);
      this.approveArray.splice(indexx,1);
    }
    if(this.approveArray.length>0){
      this.isNotApproved = true;
    }else{
    this.isNotApproved = false;
    }
   console.log("checkbox-------------",this.approveArray);
  }


btnApprove= function () {
          this.showDialogApprove=true;
      }
      popupApprove= function () {
         this.router.navigate(['/define']);
      }

}
