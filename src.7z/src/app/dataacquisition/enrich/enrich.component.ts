import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { UserService } from "../../service/user.service";
import { SessionService } from "../../service/session.service";
import { TreeNode } from "primeng/primeng";

@Component({
  templateUrl: './app/dataacquisition/enrich/enrich.html',
  providers:[UserService],
})
export class EnrichComponent implements OnInit {

constructor(public sessionService:SessionService, private userService:UserService,private router: Router) { }
       ngOnInit(): void {
     this.userService.getFilesystem().then(files => this.files = files);
    console.log("Approval is called..")

  }
myVar;
       selectedNodes: any[] = [];

      selectedFiles: TreeNode[];

nodeSelect= function(event){
  console.log("selectedFiles",this.selectedFiles);
  console.log(event);
}
  files:TreeNode[];
        selectedTable = "Data_Acquisition_Master";

        selectedColumns="app_inst_id VARCHAR2(20)";

        ingestionscannertypes="RDBMS SCANNER";
        databasetypes="ORACLE";
        hostnames="localhost";
        databasePorts="3306"
        databaseNames="DaaS_Schema";
        usernames="DaaS_User";
        passwords="********";
        fillColumns = function(){
        this.columns = ['app_inst_id VARCHAR2(20)','Column 2 INT','Column 3 DOUBLE','Column 4 FLOAT(n,n)'];
        this.selectedColumns=this.columns[0];
        }
        btnClick= function () {
            this.router.navigate(['/validate']);
        }
         btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }
}
