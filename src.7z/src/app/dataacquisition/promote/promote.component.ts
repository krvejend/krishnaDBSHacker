import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { Http } from "@angular/http";


@Component({
  templateUrl: './app/dataacquisition/promote/promote.html',
})
export class PromoteComponent {
   
   security:boolean = false;
   
   btnIngestion= function () {
            this.router.navigate(['/ingestion']);
        }
        addSecurity= function(){
        this.security = true;
      }
      removeSecurity = function(){
        this.security = false;
      }
  }
  


