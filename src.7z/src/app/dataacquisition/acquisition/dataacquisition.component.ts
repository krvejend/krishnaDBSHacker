import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {Form, FormGroup, FormBuilder, Validators} from '@angular/forms';
@Component({
  templateUrl: './app/dataacquisition/acquisition/dataacqusition.html',
  })
export class DataAcqusitionComponent  {

 constructor( private router: Router) { }

  btnIngestion= function () {
            this.router.navigate(['/ingestion']);
        }

        btnProvision= function () {
            this.router.navigate(['/provision']);
        }
}
