"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require("@angular/router");
var user_service_1 = require("../../service/user.service");
var session_service_1 = require("../../service/session.service");
var PrepropagationComponent = (function () {
    function PrepropagationComponent(sessionService, userService, router) {
        this.sessionService = sessionService;
        this.userService = userService;
        this.router = router;
        this.projectnames = "Risk Data Capture";
        this.descriptions = "Identify Risk through Availal";
        this.purposes = "Risk Identification";
        this.clarityCodes = "10054111";
        this.keyContacts = "Ruwan Perera, Steven Morton";
        this.estimatedHours = "100";
        this.usecases = ['Frauddetection', 'Frauddetection1', 'Frauddetection2'];
        this.selectedUC = "";
        this.clusters = ['RBWM', 'TERADATA', 'ORACLE'];
        this.selectedCluster = "";
        this.tables = ['Data_Acquisition_Master', 'Data_Acquisition_Request', 'Source_System_Config_Master'];
        this.selectedTable = "";
        this.columns = [];
        this.selectedColumns = "";
        this.ingestionscannertypes = "RDBMS SCANNER";
        this.databasetypes = "ORACLE";
        this.hostnames = "localhost";
        this.databasePorts = "3306";
        this.databaseNames = "DaaS_Schema";
        this.usernames = "DaaS_User";
        this.passwords = "********";
        this.fillColumns = function () {
            this.columns = ['app_inst_id VARCHAR2(20)', 'app_bus_owners VARCHAR2(20)', 'application_names VARCHAR2(20)', 'app_inst_supporting_countrys INT'];
            this.selectedColumns = this.columns[0];
        };
        this.btnClick = function () {
            this.router.navigate(['/enrich']);
        };
        this.btnClickLogoff = function () {
            this.router.navigate(['/login']);
        };
    }
    PrepropagationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.getTrackRequest("requestorName", "requestorType").subscribe(function (data) {
            console.log("test", data);
            _this.myVar = true;
        }, function () { return console.log("acq service called..."); });
    };
    PrepropagationComponent = __decorate([
        core_1.Component({
            templateUrl: './app/dataacquisition/prepare/prepare.html',
            providers: [user_service_1.UserService],
        }), 
        __metadata('design:paramtypes', [session_service_1.SessionService, user_service_1.UserService, router_1.Router])
    ], PrepropagationComponent);
    return PrepropagationComponent;
}());
exports.PrepropagationComponent = PrepropagationComponent;
//# sourceMappingURL=prepare.component.js.map