export class Identify {
   constructor(
    public id : string,
    public requestorname : string,
    public lob : string,
    public source: string,
    public sourceowner : string,
    public date:string,
    public acqusitionstatus:string,
    public ingestionstatus:string,
    public propagationstatus:string
   ){

   }
}
