export class MyRecentProject {
   constructor(
    public projectId : string,
    public projectName : string,
    public dateCreated : string,
    public Status: string
   ){

   }
}
