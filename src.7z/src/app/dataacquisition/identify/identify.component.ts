import { Component,OnInit } from '@angular/core';
import { DropdownModule } from "ngx-dropdown";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { UserService } from "../../service/user.service";
import { User } from "../../user";
import { Product } from "../../Product";
import { SessionService } from "../../service/session.service";


@Component({
  templateUrl: './app/dataacquisition/identify/identify.html',
  providers:[UserService],
})
export class LandingComponent implements OnInit {
    ingestion = false;
    showDialog:boolean = false;
     ngOnInit(): void {
    //   this.loadIngestion();
    //   if(this.sessionService.getRole()!="Approver"){
    //     this.isNotApprover = true;
    //   }else{
    //     this.isNotApprover = false;
    //   }
    // this.userData = this.sessionService.getUser();
    //   console.log("userData",JSON.stringify(this.userData));
    //   this.lobs[0] = [];
    //   this.app_inst_ids = "10031";
    //   this.app_inst_names="ABONO A COMMERCIO MX"
    // this.app_inst_short_names="ABACM";
    // this.app_inst_descriptions="Instance Description";
    // this.application_types="";
    // this.app_inst_statuss="";
    // this.app_inst_strategic_statuss="";
    // this.app_inst_reviewer_emails="";
    // this.app_inst_reviewer_names="";
    // this.app_inst_lvl_4_bus_orgs="";
    // this.app_inst_lvl_4_bus_org_owners="";
    // this.app_inst_lvl_5_bus_orgs="";
    // this.app_inst_lvl_4_it_dirs="";
    // this.app_inst_lvl_4_it_dir_owners="";
    // this.app_inst_lvl_5_it_dirs="";
    // this.app_inst_lvl_5_it_dir_owners="";
    // this.app_inst_dev_manager_primarys="";
    // this.app_inst_dev_manager_secondarys="";
    // this.application_ids="";
    // this.application_names="";
    // this.app_it_owners="";
    // this.app_bus_owners="";
    // this.app_inst_pri_data_centres="";
    // this.app_inst_pri_data_centre_types="";
    // this.app_inst_sec_data_centres="";
    // this.app_inst_supporting_regions="";
    // this.app_inst_supporting_countrys="";
    // this.app_inst_dev_regions="";
    // this.app_inst_dev_countrys="";
    // this.status_s = "Open";
    // this.requested_user_s="";
    // this.request_type_s="Acquisition";

    }
afterFilter:Boolean = false;
    usecases = [{name:'ABONO A COMMERCIO'},{name:'Automated Clearing Settlement System - ACSS - CA'},{name:'HUB Import / Export System - Canada'},{name:'HUB Sales Solutions - Canada'},
  {name:'BT Dealerboards CA'},{name:'Broker Websites CA'},{name:'Clearing and Depository Services'},{name:'Computer Assisted Collection System HBCA'},{name:'HUB Front End 2 Canada ClientConnect'}];
    selectedUC = "";

    clusters = [{name:'Mexico'},{name:'LA'},{name: 'London'}];
    selectedCluster = "";

    tables = [{name:'RBWM'},{name:'CMB'},{name:'GPB'},{name:'GBM'}];
    selectedTable = "";

    columns = [{name:'Transaction and Payments Details'},{name:'Customer Account'},{name:'Trade'},{name:'Contract Financial Value'},{name:'Correspondant Bank Details'},{name:
  'Credit Contract Details'},{name:'Customer Transaction'},{name:'Financial Instrument'},{name:'Product Contract Details'},{name:'Trade Account'},{name:'Customer Communications'},{name:
'Customer Contact Details'},{name:'Customer Identification Details'},{name:'Contract Limit'},{name:'Investment Portfolio Details'},{name:'Connected Parties Identification Details'}];


    selectedColumn = "";

    

loadIngestion(){
  console.log("ssl"+this.ssl);
  if(this.selectedLob != '' && this.selectedProject != ''
      && this.selectedOwner != ''&& this.sourceSysLocation!=""
      && this.sourceSysName !="" && this.ipAddress!=""){
        this.ingestion=true;
      }else{
        this.ingestion=false;
      }
}
callfromChild(){
  console.log('this is called...');
}
userData:User;

isNotApprover:boolean;
myVar=false;
status_s;
request_type_s;
requested_user_s;
app_inst_ids;
app_inst_names;
app_inst_short_names
app_inst_descriptions
application_types
app_inst_statuss
app_inst_strategic_statuss
app_inst_reviewer_emails
app_inst_reviewer_names
app_inst_lvl_4_bus_orgs
app_inst_lvl_4_bus_org_owners
app_inst_lvl_5_bus_orgs
app_inst_lvl_4_it_dirs
app_inst_lvl_4_it_dir_owners
app_inst_lvl_5_it_dirs
app_inst_lvl_5_it_dir_owners
app_inst_dev_manager_primarys
app_inst_dev_manager_secondarys
application_ids
application_names
app_it_owners
app_bus_owners
app_inst_pri_data_centres
app_inst_pri_data_centre_types
app_inst_sec_data_centres
app_inst_supporting_regions
app_inst_supporting_countrys
app_inst_dev_regions
app_inst_dev_countrys

ipAddrt="";
ssl="";
sssn="";
sourceSysName = "";
ipAddress = "";
sourceSysLocation = "";
dcan="";
targetId = "";
dataRead = "";
foi ="";
stagCluster ="";
dirLanPath ="";
transMech ="";
jdbcString ="";
dataIP ="";
dataPort ="";
dataSchema ="";
dataCenter ="";
san ="";
fileNames ="";
fieldName ="";
startPosition ="";
endPosition ="";
cdNode ="";
serverName ="";
ipAddr = "";
portNumber ="";

tabValue = 1;
lobs=[] ;
selectedLob = "";

showDialogApprove:boolean = false;

search = function(){
this.afterFilter=true;
}

projects = ['IFRS9','G9', 'MRFD'];
selectedProject = "";

systemOwners = ['Ian Oneill', 'Pooja Singh/Chetan Pulate','Nilesh Shrimant'];
selectedOwner = "";

fileTypes = ['Oracle', 'Flat File', 'MainFrame']
selectedfileTpe = this.fileTypes[0];

withHeader = ['Yes','No'];
selectedHeader = this.withHeader[0];

selectedTrailer = this.withHeader[0];
dataTypes = ['INT','STRING','TIMESTAMP','DATE','BIGINT','DOUBLE','FLOAT','DECIMAL(n,n)','CHAR(n)','VARCHAR(n)','BOOLEAN']
selectedDataType = "";

tab(tabVal){
  this.tabValue = tabVal;
}

submitLanding(form: NgForm){
  console.log(JSON.stringify(form.value));
  var dataAcq = JSON.stringify(form.value)
  this.userService.postAcquisition(dataAcq).subscribe(
    data=>{
    console.log("test",data);
    this.myVar = true;
this.showDialogApprove=true;
    this.userService.getTrackRequest(this.sessionService.getUsername(),"requestorType").subscribe(
      data=>{
         var productList: Product[] =[];
      for (let i in data) {
        var product:Product=new Product(data[i].data_acquisition_request_id,data[i].requested_user, data[i].app_inst_lvl_4_bus_org,data[i].app_inst_name,data[i].app_inst_lvl_4_bus_org_owner,data[i].stamp_created,data[i].status,"-","-");
        productList.push(product);
        }
        this.sessionService.setProductList(productList);
      },
     ()=>console.log("acq service called...")
    );

    },

   ()=>console.log("acq service called...")
  );
}


lobChange(){
  var lobValue = this.selectedLob;
  var lobLocal = this.lobs;

  for (var i = 0, len = lobLocal.length; i < len; i++) {
    if(lobValue == lobLocal[i]){
        this.selectedProject =this.projects[i];
    }
  }
}

projectChange(){
  var project = this.selectedProject;
  var projectLocal = this.projects;

  for (var i = 0, len = projectLocal.length; i < len; i++) {
    if(project == projectLocal[i]){
        this.selectedLob =this.lobs[i];
    }
  }
}
 constructor(private router: Router ,public sessionService:SessionService, private userService:UserService) { }
 btnClickLogoff= function () {
            this.router.navigate(['/login']);
        }

        btnIngestion= function () {
            this.router.navigate(['/ingestion']);
        }

          btnAcqusition= function () {
            this.router.navigate(['/acquisition']);
        }
        
        btnProvision= function () {
            this.router.navigate(['/provision']);
        }
}
