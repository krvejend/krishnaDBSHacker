"use strict";
var KeyValue = (function () {
    function KeyValue(key, value) {
        this.key = key;
        this.value = value;
    }
    return KeyValue;
}());
exports.KeyValue = KeyValue;
//# sourceMappingURL=keyvalue.js.map