export class Provision {
   constructor(
    public id : string,
    public applicationName : string,
    public systemName: string,
   ){

   }
}
