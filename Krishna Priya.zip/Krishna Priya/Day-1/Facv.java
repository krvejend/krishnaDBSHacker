public class fact {
    public ArrayList<Integer> allFactors(int a) {

        int upperlimit = (int)(Math.sqrt(a));
        ArrayList<Integer> factors = new ArrayList<Integer>();
        for(int i=1;i <= upperlimit; i+= 1){
            
                factors.add(i);
                if(i != a/i){
                    factors.add(a/i);
                }
            
        }
        Collections.sort(factors);
        return factors;
    }
}