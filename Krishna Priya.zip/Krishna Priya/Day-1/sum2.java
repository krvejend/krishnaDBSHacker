
import java.io.*;
import java.util.*;
import java.util.*;
public class sum2 {

    public static void main(String[] args) {
        int n , sum=0, r, temp;
		Scanner in = new Scanner(System.in);
        n= in.nextInt();
        while(n>0)
		{
            r=n%10;
			sum=sum+r;
			n=n/10;
        }
		System.out.println(sum);
		temp=sum;
		if(sum>0)
		{
            r=n%10;
			temp=temp+r;
			n=n/10;
		}
       System.out.println(sum);
    }
}