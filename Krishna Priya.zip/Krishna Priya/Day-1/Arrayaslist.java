import java.io.*;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

class  Arrayaslist
{
	public static void main(String[] args) 
	{
   Integer n ,array[];
   Scanner in = new Scanner(System.in);
   n= in.nextInt();
   System.out.println("Enter number of elements");
   array=new Integer[n];
   for(int i=0; i<n; i++)
	{
	   array[i]=in.nextInt();
	}
		List<Integer> li=Arrays.asList(array);
		System.out.println(li.size());
	}
}
