import java.math.BigInteger;
import java.util.Scanner;

/*
 * A java example source code to demonstrate
 * the use of nextProbablePrime() 
 * method of BigInteger class
 */

public class BigIntegerNextProbablePrimeExample {

	public static void main(String[] args) {	
		
		// get user input		 
		System.out.print("Enter a value:");
		Scanner s = new Scanner(System.in);
		String input = s.nextLine();		
		s.close();		

		// convert string input to BigInteger
		BigInteger val = new BigInteger(input);
		
		// get the next probable prime number 
		BigInteger result = val.nextProbablePrime();
		System.out.println("Next Prime Number:"+result);
		
	}

}