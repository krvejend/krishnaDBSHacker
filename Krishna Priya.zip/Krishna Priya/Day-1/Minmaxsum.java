import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.stream.*;
import java.math.BigInteger;
public class Minmaxsum {
   
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        BigInteger[] arr= new BigInteger[5];
        for(int arr_i=0; arr_i < 5; arr_i++){
            arr[arr_i] = in.nextBigInteger();
        }
         
        System.out.println(arr);
    }
}
