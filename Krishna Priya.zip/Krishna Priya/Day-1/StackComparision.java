import java.util.*;

 

public class StackComparision

{

    public static void main(String[] args)

    {

        StackClass stack1 = new StackClass();

        StackClass stack2 = new StackClass();

 

        try

        {

            stack1.push(new IntElement(5));

            stack1.push(new IntElement(7));
            stack1.push(new IntElement(1));

            stack1.push(new IntElement(3));

            stack1.push(new IntElement(2));

        }

        catch(StackOverflowException sofe)

        {

            System.out.println(sofe.toString());

            System.exit(0);

        }

 

        stack1.copyStack(stack1);

 

        System.out.print("stack1 elements are: ");

 

        while (!stack1.isEmptyStack())

        {

            System.out.print(stack1.top() + " ");

            stack1.pop();

          }

        System.out.println();

 

        try

        {

            stack2.push(new IntElement(1));

            stack2.push(new IntElement(3));

            stack2.push(new IntElement(2));

            stack2.push(new IntElement(5));

            stack2.push(new IntElement(7));

            stack2.push(new IntElement(0));

 

        }

        catch(StackOverflowException sofe)

       {

             System.out.println(sofe.toString());

             System.exit(0);

        }

 

        stack2.copyStack(stack2);

 

        System.out.print("stack2 elements are: ");

 

        while (!stack2.isEmptyStack())

        {

             System.out.print(stack2.top() + " ");

              stack2.pop();

       }

        System.out.println();

 

        if(stack1.equalStack(stack2))
        System.out.println("The two Stacks have the same content");
        else

        System.out.println("The two Stacks have NOT the same content");

        

    }

}
