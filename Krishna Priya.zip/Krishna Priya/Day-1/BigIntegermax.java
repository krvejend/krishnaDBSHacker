import java.util.*;
import java.math.*;

public class BigIntegermax {

   public static void main(String[] args) {

      Scanner in=new Scanner(System.in);
      BigInteger bi1, bi2, bi3;

      bi1 = in.nextBigInteger();
      bi2 = in.nextBigInteger();
     long longVal1 = bi1.longValue();
	 long longVal2 = bi2.longValue();

      // assign the max value of bi1, bi2 to bi3
      bi3 = bi1.xor(bi2);

      String str = "Minimum Value among " + bi1 + " and "+ bi2+" is "+ bi3;

      // print the maximum value
      System.out.println( str );
   }
}

