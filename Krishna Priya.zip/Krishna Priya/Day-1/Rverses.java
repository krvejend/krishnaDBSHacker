
import java.io.*;
import java.util.Scanner;
import java.lang.StringBuilder;

class Rverses 
{
	public static void main(String[] args) 
	{
		
		Scanner in=new Scanner(System.in);
		String str= in.nextLine();
		StringBuilder st=new StringBuilder(str);
		System.out.println("Enter the Statement");
		System.out.println(st.reverse());
		

	}
}
