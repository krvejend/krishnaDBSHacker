import java.io.*;
import java.util.Scanner;


public class Staircase 
{
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
         int n= in.nextInt();
		 String str="#";

		for(int i=0;i<n; i++)
		{

		System.out.printf("%"+(n+1)+"s",str+"\n");
		str=str+"#";
		/*int a, c, d;
		String b="tau";
		a=(int)b.charAt(0);
		c=(int)b.charAt(1);
		d=(int)b.charAt(2);
		if(((c-a)==10) || ((d-c)==20))
		{
          System.out.println("Not Exceeded");

		}
		else 
           System.out.println("Exceeded");

        //System.out.println((int)b.charAt(1+1+0));
		*/
		}
	}

}