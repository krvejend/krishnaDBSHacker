import java.io.*;
import java.util.Scanner;
import java.lang.*;

 class Vowelss 
{
	public static void main(String[] args) 
	{
		int count=0;
		Scanner in=new Scanner(System.in);
		String str= in.nextLine();
		System.out.println("Enter the statement");
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i) == 'A' || str.charAt(i)== 'a' || str.charAt(i) == 'E' || str.charAt(i)== 'e' || str.charAt(i) == 'I' || str.charAt(i)== 'i' || str.charAt(i) == 'O' || str.charAt(i)== 'o'|| str.charAt(i) == 'U' || str.charAt(i)== 'u')
			{
                count=count+1;
			}

			
		}
		System.out.println("the vowels count"+count);

	}
}
