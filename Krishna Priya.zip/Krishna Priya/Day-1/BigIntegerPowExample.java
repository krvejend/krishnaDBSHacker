import java.math.BigInteger;
import java.util.Scanner;

/*
 * A java example source code to demonstrate
 * the use of pow() method of BigInteger class
 */

public class BigIntegerPowExample {

	public static void main(String[] args) {	
		
		
		System.out.print("Enter the base number:");
		Scanner s = new Scanner(System.in);
		String input = s.nextLine();
		// ask for exponent
		System.out.print("Enter the exponent:");
		String exponent = s.nextLine();
		s.close();
		
		// convert the string input to BigInteger
		BigInteger value = new BigInteger(input);
		Integer exp = Integer.parseInt(exponent);
		
		// get result
		BigInteger result = value.pow(exp);
		System.out.println("The result is "+result);		
				
	}


}