import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        Stack<Integer> s1=new Stack();
        Stack <Integer> maxs= new Stack();
        maxs.push(0);
        int query= in.nextInt();
        
        if(query==1)
        {
            
            s1.push(in.nextInt());
           
        }
        if(query==2)
        {
            s1.pop();
        }
        if(query==3)
        {
            System.out.println(s1.peek());
        }
    }
}