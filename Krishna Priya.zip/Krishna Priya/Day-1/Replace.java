import java.util.Scanner;
import java.lang.*;
class  Replace
{
	public static void main(String[] args) 
	{
		String str="";
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the string");
        str= in.nextLine();
		System.out.println(str.replace('a','i'));

	}
}
