import java.util.*;
class  Adjacentmatrixsum
{
	public static void main(String[] args) 
	{
		
		Scanner s = new Scanner(System.in);
        System.out.print("Enter the first number of rows:");
         int row =s.nextInt();
		 System.out.print("Enter the first number of columns:");
         int col =s.nextInt();
         
		int a[][] =new int[row][col]; 
	    
		System.out.print("Enter values of the matrix");
		for(int i=0; i<row; i++)
		{
		  for(int j=0; j<col; j++)
			{
			  a[i][j]=s.nextInt();
			  
			}
		}
        
		int count[]=new int[row];

        for(int i=0; i<row; i++)
		{
			count[i]=0;
		  for(int j=0; j<col; j++)
			  {

		        count[i]=count[i]+a[i][j];
			  }
		}

		int min=0, minrow=0;
		for(int i=0; i<row;i++)
		{
			if(min>count[i])
				min=count[i];
			    minrow=i;
		}

        System.out.println("Row" + minrow + "has min value"); 
	}
}
