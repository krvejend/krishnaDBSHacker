import java.io.*;
import java.util.*;
import java.util.*;


class  split
{
	public static void main(String[] args) 
	{
	 
	 Scanner in=new Scanner(System.in);
	 String s=in.nextLine();
	String[] splited = s.split("\\s+");
        String testString = Arrays.toString(splited);
      System.out.println(testString);

	String sp1=splited[0];
	System.out.println(sp1);
	}
}
