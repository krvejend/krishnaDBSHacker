import java.io.*;
import java.util.Scanner;
import java.util.Arrays;

public class Arrayp1{

public static void main(String args[])
{
   int n ,array[], key;
   Scanner in = new Scanner(System.in);
   n= in.nextInt();
   System.out.println("Enter number of elements");
   /*array=new int[n];
   for(int i=0; i<n; i++)
	{
	   array[i]=in.nextInt();
	}

  System.out.println("Enter key");
   key= in.nextInt();
   
   Arrays.sort(array);
   System.out.println(Arrays.binarySearch(array,key ));*/
   List <Integer> li=new ArrayList<Integer>();
   for(int i = 1; i <= n; ++i) {
            if (n % i == 0) {
               li.add(i);
            }
			System.out.println(i);

}

}
}