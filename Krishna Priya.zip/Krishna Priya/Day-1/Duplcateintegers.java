import java.util.Scanner;
import java.util.Arrays;
class Duplcateintegers 
{
	public static void main(String[] args) 
	{
		int n ,array[], count=0;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter n value");
		n= in.nextInt();
		array=new int[n];
       for(int i=0; i<n; i++)
	   {
	   array[i]=in.nextInt();
	   }
       

      

       for(int i=1; i<array.length; i++)
		{
		  
	   if(array[i]== array[i-1])
		 
		   count=count+1;
		System.out.println(count + "i Value"+ i);
		}
		
	}
}
