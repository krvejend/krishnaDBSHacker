import java.util.*;

class Recursion 
{
	public static void main(String[] args) 
	{
		int n;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter n value");
        n= in.nextInt();
		Recursion obj=new Recursion();
		int s=obj.recursions(n,1);
	}

	int recursions(int x, int y)
	{
		if(y<=x)
		{
			System.out.println(y+"");
			return recursions(x,y+1);
		}
		return 1;
	}
}
