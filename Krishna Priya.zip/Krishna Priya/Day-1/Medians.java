import java.io.*;
import java.util.*;
import java.lang.*;
public class Medians {

    public static void main(String[] args) {
       Scanner in =new Scanner(System.in);
        int n = in.nextInt();
		int temp=0 ,min;
        int ar[]=new int[n];
        for(int i=0; i<n ; i++)
        {
            ar[i]=in.nextInt();
        }
        Arrays.sort(ar);
        temp=n/2;
		System.out.println(ar[temp]);
		for(int i=0; i<n ; i++)
		{
		if(min>ar[i])
		{
           min=ar[i];
		}
		}
		System.out.println("min value" + min);
    }
}