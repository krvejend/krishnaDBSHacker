
import java.io.*; 
 import java.util.*; 
 import java.text.*; 
 import java.math.*; 
 import java.util.regex.*; 
 import org.apache.commons.lang3.text.WordUtils;


class  Comp
{
	public static void main(String[] args) 
	{
		System.out.println("Enter the sentense");
		Scanner in=new Scanner(System.in);
	    String s1=in.nextLine();
		String s=WordUtils.capitalize(s1);

	    String[] splited = s.split("\\s+");

		//String[] str=new String[n];
		/*for(int i=0; i<n; i++)
		{
			str[i]=s.next();
		}*/
        
		Arrays.sort(splited, new Comparator<String>()
		{
			public int compare(String a, String b)
			{
			  
			  return StringAsIntegerCompare(a,b);

			}

		});
		for(int i=0; i< splited.length; i++)
		{
			System.out.println(""+ splited[i]);

		}
	}

	public static int StringAsIntegerCompare(String s1,String s2) 
     { 
          if(s1.length() > s2.length()) return 1; 
          if(s1.length() < s2.length()) return -1; 
         for(int i = 0; i< s1.length(); i++) 
         { 
             if((int)s1.charAt(i) > (int)s2.charAt(i)) return 1; 
             if((int)s1.charAt(i) < (int)s2.charAt(i)) return -1; 
         } 
        return 0; 
     } 
 } 

	

