import java.io.*;
import java.util.Scanner;
import java.lang.*;

class  Camel
{
	
	public static void main(String[] args) 
	{
		String str="", str1="" ;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the string");
		 str= in.nextLine();
		for(int i=0; i<str.length();i++)
		{
			char c=str.charAt(i);
			char cu=Character.toUpperCase(c);
		    str1=str1+cu;
		}
		System.out.println(str1);
	}
}
