import java.util.regex.*;  
import java.io.*;
import java.util.Scanner;
import java.lang.*;

class RegexExample4{  
public static void main(String args[]){  
/*System.out.println("? quantifier ....");  
System.out.println(Pattern.matches("[amn]+", "a"));//true (a or m or n comes one time) 
System.out.println(Pattern.matches("[amn]?", "m"));//false (a or m or n must come one time)  
System.out.println(Pattern.matches("[amn]?", "n"));//false (a or m or n must come one time) 
System.out.println(Pattern.matches("[amn]?", "aaa"));//false (a comes more than one time)  
System.out.println(Pattern.matches("[amn]+", "aammmnn"));//false (a m and n comes more than one time)  
System.out.println(Pattern.matches("[amn]+", "ax"));//false (a or m or n must come one time)  
System.out.println(Pattern.matches("[amn]+", "an"));//false (a or m or n must come one time) 
System.out.println(Pattern.matches("[amn]+", "amn"));//false (a or m or n must come one time)  
System.out.println(Pattern.matches("[amn]?", "aazzta"));//false (a comes more than one time)*/  
 
  
  
/*System.out.println("+ quantifier ....");  
System.out.println(Pattern.matches("[amn]+", "a"));//true (a or m or n once or more times)  
System.out.println(Pattern.matches("[amn]+", "aaa"));//true (a comes more than one time)  
System.out.println(Pattern.matches("[amn]+", "aammmnn"));//true (a or m or n comes more than once)  
System.out.println(Pattern.matches("[amn]+", "aazzta"));//false (z and t are not matching pattern)  
  
System.out.println("* quantifier ....");  
System.out.println(Pattern.matches("[amn]*", "ammmna"));//true (a or m or n may come zero or more times)  */

String str="",str1="", str2="";
Scanner in=new Scanner(System.in);
System.out.println("Enter the string");
str= in.nextLine();
Pattern pattern = Pattern.compile("[m]?[i]?[n]?");
Matcher matcher = pattern.matcher(str);
if (matcher.find()) {
    str1 = str.substring(0, matcher.start());
    str2 = str.substring(matcher.end());
}
  System.out.println(str1);
  System.out.println(str2);
}}  