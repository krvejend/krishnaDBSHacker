import java.io.*;
import java.util.Scanner;
import java.util.Arrays;

public class CopyArray{

public static void main(String args[])
{
   int n,a[],b[], j,k;
   Scanner in = new Scanner(System.in);
   n= in.nextInt();
   System.out.println("Enter number of elements");
   a=new int[n];
   for(int i=0; i<n; i++)
	{
	   a[i]=in.nextInt();
	}
	System.out.println("Enter i and j values");
    j= in.nextInt();
    k= in.nextInt();
	b=Arrays.copyOfRange(a,j,k);
	for(int m=0;m<b.length;m++)
	{
   System.out.println(b[m]);
	}
}

}