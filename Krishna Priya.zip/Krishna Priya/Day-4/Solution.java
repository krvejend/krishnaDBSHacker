import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        int n;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter n value");
		n=in.nextInt();
        Stack<Integer> s1=new Stack <Integer>();
        Stack <Integer> maxs= new Stack <Integer>();

        s1.push(0);
		
        
        for(int i=0;i<n;i++)
	    {
	      System.out.println("Enter query value");
		  int query= in.nextInt();

        if(query==1)
        {
            
            System.out.println("Enter pushing Element");
			s1.push(in.nextInt());
			
           
        }
        if(query==2)
        {
            s1.pop();
        }
        if(query==3)
        {
            System.out.println(s1.peek());
        }

		}
    }
}