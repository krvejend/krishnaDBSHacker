import java.util.*;
import java.lang.*;

class  Sss
{
	public static void main(String[] args) 
	{
		 String sentence ="";
        Scanner in= new Scanner(System.in);
         sentence=in.nextLine();
	    String[] str = sentence.split(" ");
        List<Integer> list = new ArrayList<Integer>();
	//System.out.println(str.length);
	int max =0;
	String maxStr ="";
        for(int i=0;i<str.length;i++){
            list.add(str[i].length());
			if( str[i].length()>max){
				if(str[i].length()%2==0)
				{
				max = str[i].length();
				maxStr=str[i];
			}
        }
		
    	System.out.println("Word"+maxStr);
    }
       
    
	}

