import java.util.*;
02
 
03
public class StackComparision
04
{
05
    public static void main(String[] args)
06
    {
07
        StackClass stack1 = new StackClass();
08
        StackClass stack2 = new StackClass();
09
 
10
        try
11
        {
12
            stack1.push(new IntElement(5));
13
            stack1.push(new IntElement(7));
14
            stack1.push(new IntElement(1));
15
            stack1.push(new IntElement(3));
16
            stack1.push(new IntElement(2));
17
        }
18
        catch(StackOverflowException sofe)
19
        {
20
            System.out.println(sofe.toString());
21
            System.exit(0);
22
        }
23
 
24
        stack1.copyStack(stack1);
25
 
26
        System.out.print("stack1 elements are: ");
27
 
28
        while (!stack1.isEmptyStack())
29
        {
30
            System.out.print(stack1.top() + " ");
31
            stack1.pop();
32
          }
33
        System.out.println();
34
 
35
        try
36
        {
37
            stack2.push(new IntElement(1));
38
            stack2.push(new IntElement(3));
39
            stack2.push(new IntElement(2));
40
            stack2.push(new IntElement(5));
41
            stack2.push(new IntElement(7));
42
            stack2.push(new IntElement(0));
43
 
44
        }
45
        catch(StackOverflowException sofe)
46
        {
47
             System.out.println(sofe.toString());
48
             System.exit(0);
49
        }
50
 
51
        stack2.copyStack(stack2);
52
 
53
        System.out.print("stack2 elements are: ");
54
 
55
        while (!stack2.isEmptyStack())
56
        {
57
             System.out.print(stack2.top() + " ");
58
              stack2.pop();
59
       }
60
        System.out.println();
61
 
62
        if(stack1.equalStack(stack2))
63
        System.out.println("The two Stacks have the same content");
64
        else
65
        System.out.println("The two Stacks have NOT the same content");
66
         
67
    }
68
}
