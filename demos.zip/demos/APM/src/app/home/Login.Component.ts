import { Component } from '@angular/core';

@Component({
    selector:'login_page',
    templateUrl: './Login.html'
})
export class LoginComponent {
    public Login: string = 'Login Page data';
}