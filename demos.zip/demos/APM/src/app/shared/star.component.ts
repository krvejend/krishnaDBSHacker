import { Component, OnChanges, Input, Output,EventEmitter } from "@angular/core";

@Component({
selector:'pm-star',
templateUrl:'./star.component.html',
styleUrls: ['./star.component.css']

})
export class StarComponent implements OnChanges{
    @Input() rating:number;
    starwidth:number;
    @Output() ratingclicked =
    new EventEmitter<string>();

    ngOnChanges():void{
          this.starwidth=this.rating*86/5;
    }

    onClick(): void{
     this.ratingclicked.emit(`the rating ${this.rating} was clicked!`);
    }

}