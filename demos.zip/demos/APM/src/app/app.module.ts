import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import {WelcomeComponent} from './home/welcome.component'
import { LoginComponent } from './home/Login.Component';
import { ProductListComponent } from './product/ProductList.Component';
import { FormsModule } from '@angular/forms';
import { ConvertToSpacesPipe } from './shared/convert-to-spaces.pipe';
import { StarComponent } from './shared/star.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,WelcomeComponent,LoginComponent,ProductListComponent,ConvertToSpacesPipe,StarComponent,
    
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    RouterModule.forRoot([
      {path:'product',component:ProductListComponent},
      {path:'welcome',component:WelcomeComponent},
      {path:'StarComponent',component:StarComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
